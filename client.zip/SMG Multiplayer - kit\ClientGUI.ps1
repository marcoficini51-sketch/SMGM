#
# Pannello di collegamento al server multiplayer di Super Mario Galaxy.
#
# Avvialo con "Connetti al server.bat".
#

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

# Windows marchia i file che arrivano da internet, e aprendo il .ps1 a mano
# esce l'avviso di sicurezza. Il marchio si toglie una volta sola, qui: dal
# secondo avvio non compare piu' nemmeno aprendo lo script direttamente.
try {
    $qui = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
    Get-ChildItem -LiteralPath $qui -Recurse -Force -ErrorAction SilentlyContinue |
        Unblock-File -ErrorAction SilentlyContinue
} catch { }

$here = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }

$riivRoot = Join-Path $env:APPDATA "Dolphin Emulator\Load\Riivolution"
$riivSub  = Join-Path $riivRoot "riivolution"
$connTest = Join-Path $here "ConnTest.exe"
$fetchScript = Join-Path $here "SaveFetch.ps1"
# Il salvataggio dell'host non prende piu' il posto del tuo: va in una NAND
# tutta sua, e a Dolphin si dice di usare quella solo mentre si gioca insieme.
$dolphinUser = Join-Path $env:APPDATA "Dolphin Emulator"
$iniFile     = Join-Path $dolphinUser "Config\Dolphin.ini"
# Niente spazi nel percorso: "Dolphin Emulator" ne ha uno, e basta una
# virgoletta dimenticata da qualche parte perche' Dolphin veda due pezzi e si
# lamenti di una cartella che non esiste. Qui invece non c'e' niente da spezzare.
$nandMulti   = Join-Path $env:LOCALAPPDATA "SMGserver"
$saveMulti   = Join-Path $nandMulti "title\00010000\524d4745\data"
$langFile = Join-Path $here "lingua-client.txt"
$devFile  = Join-Path $here "devmode-client.txt"
$dolphinFile = Join-Path $here "dolphin.txt"
$hideFile = Join-Path $here "nascondi-ip-client.txt"   # 1 = indirizzi nascosti a schermo   # il percorso scelto a mano, se serve
# riivo_USA.xml rimanda a TitleLogo.arc: se manca, la patch non parte
$modFiles = @("riivo_USA.xml", "CustomCode_USA.bin", "TitleLogo.arc", "servers.txt", "WiiRemoteStrapReplace.arc")

$script:dolphinProc = $null

# ---------------------------------------------------------------- lingua
$S = @{}
$S["it"] = @{
    titolo     = "Super Mario Galaxy - Connessione"
    testata    = "Connessione al server"
    sottotesta = "Super Mario Galaxy multiplayer"
    dev        = "Dev mode"
    secServer  = "INDIRIZZO DEL SERVER"
    hideIp     = "Hide IP"
    incolla    = "Incolla"
    prova      = "Prova"
    provaNota  = "Premi Prova per verificare se il server risponde."
    provando   = "Provo..."
    raggiung   = "Server raggiungibile - latenza {0} ms"
    raggNota   = "Il server ti ha assegnato il posto numero {0}. Puoi avviare il gioco."
    nonRagg    = "Server NON raggiungibile"
    nonRaggA   = "Il server e' spento, l'indirizzo e' sbagliato, oppure un firewall blocca la porta UDP {0}."
    nonRaggB   = "L'indirizzo non e' un IPv4 valido. Serve un numero, il mod non risolve i nomi a dominio."
    senzaConn  = "Impossibile provare: manca ConnTest.exe"
    secMod     = "INSTALLAZIONE DEL MOD"
    installa   = "Installa / aggiorna"
    cartella   = "Apri cartella"
    avviaDolph = "Avvia Dolphin"
    scegli     = "Scegli Dolphin..."
    scegliT    = "Dov'e' Dolphin.exe?"
    dolphSi    = "Dolphin trovato"
    dolphKit   = "Dolphin incluso nel kit: pronto"
    dolphNo    = "Dolphin non trovato - indicalo col tasto qui accanto"
    dolphScelto = "Dolphin scelto a mano: pronto"
    logScelto  = "Dolphin scelto a mano: {0}"
    fileOk1    = "File del mod in Load\Riivolution"
    fileNo1    = "Mancano in Load\Riivolution: {0}"
    fileOk2    = "File del mod in Load\Riivolution\riivolution"
    fileNo2    = "Mancano in ...\riivolution: {0}"
    adesso     = "Indirizzo configurato adesso: {0}"
    adessoNo   = "serverIP.txt non ancora creato"
    riavvia    = "Dopo aver cambiato l'indirizzo il gioco va riavviato: il mod lo legge una volta sola, all'avvio."
    secSave    = "SALVATAGGIO DELL'HOST"
    auto       = "Automatico: lo scarico quando apri questo pannello e quando avvii il gioco"
    secPers    = "PERSONAGGIO"
    luigiBtn   = "You are playing as Luigi"
    marioBtn   = "You are playing as Mario"
    luigiOn    = "Attivo: giochi con Luigi. Vale dal prossimo avvio del gioco."
    luigiOff   = "Spento: giochi con Mario."
    logLuigiOn = "Play as Luigi attivo: al prossimo avvio del gioco sarai Luigi."
    logLuigiOff = "Play as Luigi spento: al prossimo avvio del gioco sarai Mario."
    prendi     = "Aggiorna il salvataggio del server"
    rimetti    = "Avvia col mio"
    saveNota   = "Vale solo per il gioco avviato da qui: aprendo Dolphin dall'icona trovi il tuo salvataggio."
    secLog     = "REGISTRO"
    pronto     = "Pronto. Inserisci l'indirizzo del server e premi Prova."
    logIncolla = "Incollato: {0}"
    logVuoto   = "Appunti vuoti."
    logNoAddr  = "Negli appunti non c'e' un indirizzo valido (serve tipo 10.0.0.2:5029)."
    logPrima   = "Inserisci prima un indirizzo."
    logPrimaH  = "Inserisci prima l'indirizzo dell'host."
    logNoConn  = "ConnTest.exe non trovato in questa cartella."
    logSalto   = "Attenzione: {0} non e' in questa cartella, lo salto."
    logTex     = "Copiate {0} texture in Load\Textures\RMGE01 (accendi 'Load Custom Textures' in Dolphin)"
    logInst    = "Installati {0} file, indirizzo impostato su {1}"
    mbInst     = "Installazione completata!"
    mbAgg      = "Aggiornamento file completato!"
    logRicorda = "Ricorda: se il gioco e' aperto, riavvialo."
    logErrInst = "Errore durante l'installazione: {0}"
    logNoCart  = "La cartella non esiste ancora: premi prima Installa."
    logDolph   = "Dolphin avviato. Usa 'Start with Riivolution Patches' e carica riivo_USA.xml."
    logCaduto  = "Il server {0} non risponde piu': gli altri Mario spariranno."
    logTornato = "Il server {0} risponde di nuovo."
    mbCadutoT  = "Server caduto"
    mbCaduto   = "Il server non risponde piu'.`n`nChi ospita l'ha fermato, oppure la rete e' caduta. Da qui in avanti giochi da solo: gli altri Mario non si vedranno piu'.`n`nQuando torna acceso ripartono da soli, senza riavviare il gioco."
    logNoShare = "L'host non sta condividendo il salvataggio: si gioca col tuo."
    logScarico = "Scarico il salvataggio del server..."
    logChiuso  = "Gioco chiuso."
    logNandOn  = "Si gioca nel mondo del server, da una cartella sua: il tuo salvataggio non si tocca."
    logMio     = "Dolphin avviato col tuo salvataggio di sempre."
    logIniPulito = "Tolta dalle impostazioni di Dolphin la riga lasciata dalla versione vecchia."
    logNoDolph = "Dolphin non trovato."

    logNoFetch = "Non trovo SaveFetch.ps1 in questa cartella."
    logDolAp   = "Chiudi prima Dolphin: mentre gira tiene aperto il salvataggio."
    logServer  = "Server {0}: {1}"
    srvOn      = "acceso"
    srvOff     = "spento"
    logNessuno = "Nessun server acceso: nel gioco la schermata dei salvataggi restera' vuota."
    logAccesi  = "Server accesi nella lista: {0}"
    logAnnull  = "Avvio annullato: nessun server acceso."
    mbOfflineT = "Server offline"
    mbOffline  = "Nessun server risponde: e' spento, oppure l'indirizzo o il firewall non vanno.`n`nPuoi avviare lo stesso: il gioco resta sulla schermata del titolo con scritto Waiting for a server, ed entra da solo appena il server si accende. Senza server non si entra: il kit serve per giocare insieme.`n`nAvvio Dolphin?"
    mbSaveT    = "Salvataggio dell'host"
    mbSave     = "Prendo il salvataggio dell'host e lo metto al posto del tuo.`n`nIl tuo viene messo da parte e puoi rimetterlo col tasto accanto.`n`nProcedo?"
    mbSaveOkT  = "Salvataggio"
}
$S["en"] = @{
    titolo     = "Super Mario Galaxy - Connection"
    testata    = "Connect to the server"
    sottotesta = "Super Mario Galaxy multiplayer"
    dev        = "Dev mode"
    secServer  = "SERVER ADDRESS"
    hideIp     = "Hide IP"
    incolla    = "Paste"
    prova      = "Test"
    provaNota  = "Press Test to check whether the server answers."
    provando   = "Testing..."
    raggiung   = "Server reachable - {0} ms latency"
    raggNota   = "The server gave you slot number {0}. You can start the game."
    nonRagg    = "Server NOT reachable"
    nonRaggA   = "The server is off, the address is wrong, or a firewall is blocking UDP port {0}."
    nonRaggB   = "That is not a valid IPv4 address. It must be a number: the mod does not resolve domain names."
    senzaConn  = "Can't test: ConnTest.exe is missing"
    secMod     = "MOD INSTALLATION"
    installa   = "Install / update"
    cartella   = "Open folder"
    avviaDolph = "Start Dolphin"
    scegli     = "Choose Dolphin..."
    scegliT    = "Where is Dolphin.exe?"
    dolphSi    = "Dolphin found"
    dolphKit   = "Dolphin bundled with the kit: ready"
    dolphNo    = "Dolphin not found - point at it with the button next to this"
    dolphScelto = "Dolphin chosen by hand: ready"
    logScelto  = "Dolphin chosen by hand: {0}"
    fileOk1    = "Mod files in Load\Riivolution"
    fileNo1    = "Missing in Load\Riivolution: {0}"
    fileOk2    = "Mod files in Load\Riivolution\riivolution"
    fileNo2    = "Missing in ...\riivolution: {0}"
    adesso     = "Address configured right now: {0}"
    adessoNo   = "serverIP.txt not created yet"
    riavvia    = "After changing the address the game must be restarted: the mod reads it once, at startup."
    secSave    = "THE HOST'S SAVE FILE"
    auto       = "Automatic: downloaded when you open this panel and when you start the game"
    secPers    = "CHARACTER"
    luigiBtn   = "You are playing as Luigi"
    marioBtn   = "You are playing as Mario"
    luigiOn    = "On: you play as Luigi. Takes effect the next time you start the game."
    luigiOff   = "Off: you play as Mario."
    logLuigiOn = "Play as Luigi on: next time you start the game you will be Luigi."
    logLuigiOff = "Play as Luigi off: next time you start the game you will be Mario."
    prendi     = "Update the server save file"
    rimetti    = "Start with mine"
    saveNota   = "Only for the game started from here: opening Dolphin from its icon you get your own save."
    secLog     = "LOG"
    pronto     = "Ready. Type the server address and press Test."
    logIncolla = "Pasted: {0}"
    logVuoto   = "The clipboard is empty."
    logNoAddr  = "The clipboard has no valid address (it should look like 10.0.0.2:5029)."
    logPrima   = "Type an address first."
    logPrimaH  = "Type the host's address first."
    logNoConn  = "ConnTest.exe is not in this folder."
    logSalto   = "Careful: {0} is not in this folder, skipping it."
    logTex     = "Copied {0} textures into Load\Textures\RMGE01 (turn on 'Load Custom Textures' in Dolphin)"
    logInst    = "Installed {0} files, address set to {1}"
    mbInst     = "Installation complete!"
    mbAgg      = "Files updated successfully!"
    logRicorda = "Remember: if the game is open, restart it."
    logErrInst = "Error while installing: {0}"
    logNoCart  = "The folder does not exist yet: press Install first."
    logDolph   = "Dolphin started. Use 'Start with Riivolution Patches' and load riivo_USA.xml."
    logCaduto  = "Server {0} stopped answering: the other Marios will disappear."
    logTornato = "Server {0} is answering again."
    mbCadutoT  = "Server down"
    mbCaduto   = "The server stopped answering.`n`nThe host stopped it, or the network went down. From now on you are playing alone: the other Marios will not show up.`n`nWhen it comes back they return on their own, no need to restart the game."
    logNoShare = "The host is not sharing their save file: you play with your own."
    logScarico = "Downloading the server save file..."
    logChiuso  = "Game closed."
    logNandOn  = "Playing in the server world, from a folder of its own: your save is untouched."
    logMio     = "Dolphin started with your usual save file."
    logIniPulito = "Removed the line an older version left in Dolphin settings."
    logNoDolph = "Dolphin not found."

    logNoFetch = "I can't find SaveFetch.ps1 in this folder."
    logDolAp   = "Close Dolphin first: while it runs it keeps the save file open."
    logServer  = "Server {0}: {1}"
    srvOn      = "on"
    srvOff     = "off"
    logNessuno = "No server is on: in game the save file screen will stay empty."
    logAccesi  = "Servers on in the list: {0}"
    logAnnull  = "Start cancelled: no server is on."
    mbOfflineT = "Server offline"
    mbOffline  = "No server answers: it is off, or the address or the firewall are wrong.`n`nYou can start anyway: the game stays on the title screen saying Waiting for a server, and goes in by itself as soon as the server comes up. Without a server you cannot go in: the kit is for playing together.`n`nStart Dolphin?"
    mbSaveT    = "The host's save file"
    mbSave     = "I'll take the host's save file and put it in place of yours.`n`nYours is set aside and you can put it back with the button next to this one.`n`nGo ahead?"
    mbSaveOkT  = "Save file"
}

$script:lang = "it"
if (Test-Path $langFile) {
    $l = (Get-Content $langFile -Raw -ErrorAction SilentlyContinue).Trim().ToLower()
    if ($S.ContainsKey($l)) { $script:lang = $l }
}

function T($chiave) {
    $t = $S[$script:lang][$chiave]
    if ($null -eq $t) { $t = $S["it"][$chiave] }
    return $t
}

$script:testi = New-Object System.Collections.ArrayList

function Reg($ctl, $chiave) {
    [void]$script:testi.Add(@{ C = $ctl; K = $chiave })
    $ctl.Text = T $chiave
    return $ctl
}

# ---------------------------------------------------------------- palette
$cBg     = [System.Drawing.Color]::FromArgb(24, 24, 34)
$cPanel  = [System.Drawing.Color]::FromArgb(36, 36, 52)
$cPanel2 = [System.Drawing.Color]::FromArgb(31, 31, 45)
$cText   = [System.Drawing.Color]::FromArgb(232, 232, 244)
$cMuted  = [System.Drawing.Color]::FromArgb(138, 138, 164)
$cOk     = [System.Drawing.Color]::FromArgb(94, 200, 140)
$cBad    = [System.Drawing.Color]::FromArgb(212, 108, 108)
$cAccent = [System.Drawing.Color]::FromArgb(228, 168, 72)
$cLine   = [System.Drawing.Color]::FromArgb(52, 52, 72)

$fTitle  = New-Object System.Drawing.Font("Segoe UI Semibold", 15)
$fSection= New-Object System.Drawing.Font("Segoe UI Semibold", 8)
$fLabel  = New-Object System.Drawing.Font("Segoe UI", 8.5)
$fBody   = New-Object System.Drawing.Font("Segoe UI", 9.5)
$fBold   = New-Object System.Drawing.Font("Segoe UI Semibold", 10)
$fMono   = New-Object System.Drawing.Font("Consolas", 11)
$fSmall  = New-Object System.Drawing.Font("Consolas", 8.5)

$W = 620
$M = 22
$CW = 556

$form = New-Object System.Windows.Forms.Form
$form.Text = T "titolo"
$form.Size = New-Object System.Drawing.Size($W, 720)
$form.StartPosition = "CenterScreen"
$form.BackColor = $cBg
$form.ForeColor = $cText
$form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox = $false
# doppio buffer, se no crescendo e calando la finestra sfarfalla. La proprieta'
# e' protetta: si arriva solo per riflessione.
try {
    $prop = [System.Windows.Forms.Form].GetProperty("DoubleBuffered", [System.Reflection.BindingFlags]"Instance,NonPublic")
    $prop.SetValue($form, $true, $null)
} catch { }

# ---------------------------------------------------------------- sfondo
# La copertina sfocata sta in sfondo.png. Si carica da memoria, se no il file
# resta bloccato finche' il pannello e' aperto.
$script:bg = $null
$sfondoFile = Join-Path $here "sfondo-client.png"
if (Test-Path $sfondoFile) {
    try {
        $byte = [System.IO.File]::ReadAllBytes($sfondoFile)
        $ms = New-Object System.IO.MemoryStream (,$byte)
        $script:bg = [System.Drawing.Image]::FromStream($ms)
        $form.BackgroundImage = $script:bg
        $form.BackgroundImageLayout = "None"   # ancorato in alto a sinistra:
    } catch { }                                # cosi' i ritagli restano allineati
}

# angoli arrotondati: si ritaglia la forma del controllo
function Round-Ctl($ctl, $r) {
    $pth = New-Object System.Drawing.Drawing2D.GraphicsPath
    $w = $ctl.Width; $h = $ctl.Height; $d = $r * 2
    $pth.AddArc(0, 0, $d, $d, 180, 90)
    $pth.AddArc(($w - $d), 0, $d, $d, 270, 90)
    $pth.AddArc(($w - $d), ($h - $d), $d, $d, 0, 90)
    $pth.AddArc(0, ($h - $d), $d, $d, 90, 90)
    $pth.CloseFigure()
    $ctl.Region = New-Object System.Drawing.Region $pth
}

# "vetro": il pezzo di sfondo che sta sotto la scheda, piu' un velo di colore
function Set-Glass($panel, $alpha) {
    if ($null -eq $script:bg) { return }
    $b = New-Object System.Drawing.Bitmap $panel.Width, $panel.Height
    $g = [System.Drawing.Graphics]::FromImage($b)
    $dest = New-Object System.Drawing.Rectangle 0, 0, $panel.Width, $panel.Height
    $g.DrawImage($script:bg, $dest, $panel.Left, $panel.Top, $panel.Width, $panel.Height, "Pixel")
    $br = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb($alpha, 36, 36, 52))
    $g.FillRectangle($br, 0, 0, $panel.Width, $panel.Height)
    $g.Dispose()
    $panel.BackgroundImage = $b
}

# ---------------------------------------------------------------- pillole
# I pulsanti sono la pillola della schermata d'avvio, ritagliata su misura.
# pillola.png e' quella a riposo, pillola2.png quella col mouse sopra: le
# prepara avvio.ps1 scontornandole dal verde. Se mancano, i pulsanti restano
# quelli piatti di prima.
$script:pillA = $null
$script:pillB = $null
try {
    $fa = Join-Path $here "pillola.png"
    $fb = Join-Path $here "pillola2.png"
    if ((Test-Path $fa) -and (Test-Path $fb)) {
        $ba = [System.IO.File]::ReadAllBytes($fa)
        $script:pillA = [System.Drawing.Image]::FromStream((New-Object System.IO.MemoryStream (,$ba)))
        $bb = [System.IO.File]::ReadAllBytes($fb)
        $script:pillB = [System.Drawing.Image]::FromStream((New-Object System.IO.MemoryStream (,$bb)))
    }
} catch { $script:pillA = $null }

# quanto tirare i tre colori: la pillola e' bianco-azzurra, da li' si ricavano
# le altre. Cosi' un pulsante pericoloso resta rosso anche con la nuova veste.
$TINTE = @{
    chiaro = @(1.00, 1.00, 1.00)
    rosso  = @(1.30, 0.60, 0.58)
    verde  = @(0.70, 1.16, 0.80)
    ambra  = @(1.28, 1.02, 0.60)
}
$INCHIOSTRO = @{
    chiaro = [System.Drawing.Color]::FromArgb(12, 70, 120)
    rosso  = [System.Drawing.Color]::FromArgb(132, 24, 24)
    verde  = [System.Drawing.Color]::FromArgb(16, 84, 42)
    ambra  = [System.Drawing.Color]::FromArgb(112, 64, 6)
}

# I tappi tondi si copiano tali e quali, si stira solo il tratto dritto di
# mezzo: se no su un pulsante largo e basso diventerebbero ovali.
function Taglia-Pillola($img, $dw, $dh, $tinta) {
    $sw = $img.Width; $sh = $img.Height
    $tapS = [int]($sh / 2)
    $tapD = [int]($dh / 2)
    if ($tapD * 2 -gt $dw) { $tapD = [int]($dw / 2) }
    $b = New-Object System.Drawing.Bitmap $dw, $dh, ([System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [System.Drawing.Graphics]::FromImage($b)
    $g.InterpolationMode = "HighQualityBicubic"
    $g.PixelOffsetMode = "HighQuality"
    $t = $TINTE[$tinta]
    $attr = $null
    if ($null -ne $t -and $tinta -ne "chiaro") {
        $m = New-Object System.Drawing.Imaging.ColorMatrix
        $m.Matrix00 = $t[0]; $m.Matrix11 = $t[1]; $m.Matrix22 = $t[2]; $m.Matrix33 = 1
        $attr = New-Object System.Drawing.Imaging.ImageAttributes
        $attr.SetColorMatrix($m)
    }
    $pezzi = @(
        @(0, $tapS, 0, $tapD),                                        # tappo sinistro
        @($tapS, ($sw - 2 * $tapS), $tapD, ($dw - 2 * $tapD)),        # mezzo, stirato
        @(($sw - $tapS), $tapS, ($dw - $tapD), $tapD)                 # tappo destro
    )
    foreach ($p in $pezzi) {
        if ($p[3] -le 0) { continue }
        $dst = New-Object System.Drawing.Rectangle $p[2], 0, $p[3], $dh
        if ($null -ne $attr) {
            $g.DrawImage($img, $dst, $p[0], 0, $p[1], $sh, "Pixel", $attr)
        } else {
            $src = New-Object System.Drawing.Rectangle $p[0], 0, $p[1], $sh
            $g.DrawImage($img, $dst, $src, "Pixel")
        }
    }
    $g.Dispose()
    return $b
}

# il pezzo di sfondo che sta sotto al pulsante: senza, attorno alla pillola
# resterebbe un rettangolo pieno, perche' i pulsanti non sanno essere trasparenti
function Sotto($ctl) {
    $b = New-Object System.Drawing.Bitmap $ctl.Width, $ctl.Height
    $g = [System.Drawing.Graphics]::FromImage($b)
    $padre = $ctl.Parent
    $sorgente = $null
    if ($padre -is [System.Windows.Forms.Form]) { $sorgente = $script:bg }
    elseif ($null -ne $padre) { $sorgente = $padre.BackgroundImage }
    if ($null -ne $sorgente) {
        $dst = New-Object System.Drawing.Rectangle 0, 0, $ctl.Width, $ctl.Height
        $g.DrawImage($sorgente, $dst, $ctl.Left, $ctl.Top, $ctl.Width, $ctl.Height, "Pixel")
    } elseif ($null -ne $padre) {
        $g.Clear($padre.BackColor)
    }
    $g.Dispose()
    return $b
}

function Componi($ctl, $pillola, $tinta) {
    $b = Sotto $ctl
    $g = [System.Drawing.Graphics]::FromImage($b)
    $p = Taglia-Pillola $pillola $ctl.Width $ctl.Height $tinta
    $g.DrawImage($p, 0, 0)
    $g.Dispose(); $p.Dispose()
    return $b
}

function Vesti($btn, $tinta) {
    if ($null -eq $script:pillA) { return $false }
    $a = Componi $btn $script:pillA $tinta
    $b = Componi $btn $script:pillB $tinta
    $btn.BackgroundImage = $a
    $btn.BackgroundImageLayout = "None"
    $btn.FlatAppearance.BorderSize = 0
    $btn.FlatAppearance.MouseOverBackColor = [System.Drawing.Color]::Transparent
    $btn.FlatAppearance.MouseDownBackColor = [System.Drawing.Color]::Transparent
    $btn.ForeColor = $INCHIOSTRO[$tinta]
    $btn.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 8.5)
    $btn.Add_MouseEnter({ $this.BackgroundImage = $this.Tag.Sopra }.GetNewClosure())
    $btn.Add_MouseLeave({ $this.BackgroundImage = $this.Tag.Fermo }.GetNewClosure())
    $btn.Tag = @{ Fermo = $a; Sopra = $b }
    return $true
}

function New-Lbl($text, $x, $y, $w, $h, $font, $color, $parent) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $text
    $l.Location = New-Object System.Drawing.Point($x, $y)
    $l.Size = New-Object System.Drawing.Size($w, $h)
    $l.Font = $font; $l.ForeColor = $color
    $l.BackColor = [System.Drawing.Color]::Transparent
    if ($parent) { $parent.Controls.Add($l) } else { $form.Controls.Add($l) }
    return $l
}

function New-Section($chiave, $y) {
    $l = New-Lbl "" $M $y 300 14 $fSection $cMuted $null
    Reg $l $chiave | Out-Null
    $riga = New-Object System.Windows.Forms.Panel
    $riga.Location = New-Object System.Drawing.Point($M, ($y + 17))
    $riga.Size = New-Object System.Drawing.Size($CW, 1)
    $riga.BackColor = $cLine
    $form.Controls.Add($riga)
    $script:ultimaRiga = $riga
    return $l
}

function New-Btn($chiave, $x, $y, $w, $h, $parent, $tinta = "chiaro") {
    $b = New-Object System.Windows.Forms.Button
    $b.Location = New-Object System.Drawing.Point($x, $y)
    $b.Size = New-Object System.Drawing.Size($w, $h)
    $b.FlatStyle = "Flat"
    $b.FlatAppearance.BorderSize = 1
    $b.FlatAppearance.BorderColor = $cMuted
    $b.FlatAppearance.MouseOverBackColor = $cPanel2
    $b.BackColor = $cPanel; $b.ForeColor = $cText
    $b.Font = $fBody
    if ($parent) { $parent.Controls.Add($b) } else { $form.Controls.Add($b) }
    if (-not (Vesti $b $tinta)) { Round-Ctl $b 6 }
    if ($chiave) { Reg $b $chiave | Out-Null }
    return $b
}

# ---------------------------------------------------------------- testata
Reg (New-Lbl "" 22 16 360 26 $fTitle $cText $null) "testata" | Out-Null
Reg (New-Lbl "" 24 42 360 18 $fLabel $cMuted $null) "sottotesta" | Out-Null

$cmbLang = New-Object System.Windows.Forms.ComboBox
$cmbLang.Location = New-Object System.Drawing.Point(398, 18)
$cmbLang.Size = New-Object System.Drawing.Size(100, 24)
$cmbLang.DropDownStyle = "DropDownList"
$cmbLang.Font = $fLabel
$cmbLang.BackColor = $cPanel; $cmbLang.ForeColor = $cText
$cmbLang.FlatStyle = "Flat"
[void]$cmbLang.Items.Add("Italiano")
[void]$cmbLang.Items.Add("English")
$cmbLang.SelectedIndex = $(if ($script:lang -eq "en") { 1 } else { 0 })
$form.Controls.Add($cmbLang)

$btnDev = New-Btn "dev" 506 18 72 24 $null
$btnDev.Font = $fLabel

# ---------------------------------------------------------------- volume dei suoni
# Il volume del pannello (solo i suoi suoni, non quello di Windows): Windows
# tiene un volume per ogni programma, e waveOutSetVolume cambia il nostro.
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class VolumePannello {
    [DllImport("winmm.dll")] static extern int waveOutSetVolume(IntPtr h, uint v);
    public static void Imposta(int percento) {
        if (percento < 0) percento = 0;
        if (percento > 100) percento = 100;
        uint x = (uint)(percento * 0xFFFF / 100);
        waveOutSetVolume(IntPtr.Zero, x | (x << 16));
    }
}
"@
$volFile = Join-Path $here "volume-client.txt"
$script:volume = 80
if (Test-Path $volFile) {
    $v = 0
    if ([int]::TryParse((Get-Content $volFile -Raw).Trim(), [ref]$v)) { $script:volume = [Math]::Max(0, [Math]::Min(100, $v)) }
}
try { [VolumePannello]::Imposta($script:volume) } catch { }

$volCtl = New-Object System.Windows.Forms.Label
$volCtl.Location = New-Object System.Drawing.Point(398, 50)
$volCtl.Size = New-Object System.Drawing.Size(180, 18)
$volCtl.BackColor = [System.Drawing.Color]::Transparent
$volCtl.Cursor = [System.Windows.Forms.Cursors]::Hand
$form.Controls.Add($volCtl)
$script:volTrascina = $false
$script:volIcona = New-Object System.Drawing.Font("Segoe MDL2 Assets", 9)
$script:volTesto = New-Object System.Drawing.Font("Segoe UI", 8)

function Vol-DaMouse($x) {
    $x0 = 22; $x1 = $volCtl.Width - 36
    $p = [int][Math]::Round(($x - $x0) * 100.0 / ($x1 - $x0))
    $script:volume = [Math]::Max(0, [Math]::Min(100, $p))
    try { [VolumePannello]::Imposta($script:volume) } catch { }
    $volCtl.Invalidate()
}

$volCtl.Add_Paint({
    param($s, $e)
    $g = $e.Graphics
    $g.SmoothingMode = "AntiAlias"
    $g.TextRenderingHint = "ClearTypeGridFit"
    $cy = [single]($s.Height / 2)
    $v = $script:volume
    $glifo = if ($v -eq 0) { 0xE74F } elseif ($v -lt 34) { 0xE993 } elseif ($v -lt 67) { 0xE994 } else { 0xE995 }
    $grigio = [System.Drawing.Color]::FromArgb(200, 190, 196, 214)
    $br = New-Object System.Drawing.SolidBrush $grigio
    $g.DrawString([string][char]$glifo, $script:volIcona, $br, [single]0, [single]2)
    $x0 = [single]22; $x1 = [single]($s.Width - 36)
    $pen = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(70, 255, 255, 255)), 4
    $pen.StartCap = "Round"; $pen.EndCap = "Round"
    $g.DrawLine($pen, $x0, $cy, $x1, $cy)
    $xv = [single]($x0 + ($x1 - $x0) * $v / 100.0)
    if ($v -gt 0) {
        $pen2 = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(255, 255, 214, 90)), 4
        $pen2.StartCap = "Round"; $pen2.EndCap = "Round"
        $g.DrawLine($pen2, $x0, $cy, $xv, $cy)
        $pen2.Dispose()
    }
    $pomo = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::White)
    $g.FillEllipse($pomo, [single]($xv - 6), [single]($cy - 6), [single]12, [single]12)
    $g.DrawString("$v%", $script:volTesto, $br, [single]($x1 + 9), [single]1)
    $pen.Dispose(); $br.Dispose(); $pomo.Dispose()
})
$volCtl.Add_MouseDown({ param($s, $e) $script:volTrascina = $true; Vol-DaMouse $e.X })
$volCtl.Add_MouseMove({ param($s, $e) if ($script:volTrascina) { Vol-DaMouse $e.X } })
$volCtl.Add_MouseUp({
    param($s, $e)
    $script:volTrascina = $false
    Vol-DaMouse $e.X
    try { Set-Content -Path $volFile -Value "$($script:volume)" -NoNewline -Encoding ascii } catch { }
    Suona $script:sndOk               # per sentire subito com'e'
})
$volCtl.Add_MouseWheel({
    param($s, $e)
    $script:volume = [Math]::Max(0, [Math]::Min(100, $script:volume + [Math]::Sign($e.Delta) * 5))
    try { [VolumePannello]::Imposta($script:volume) } catch { }
    try { Set-Content -Path $volFile -Value "$($script:volume)" -NoNewline -Encoding ascii } catch { }
    $volCtl.Invalidate()
})

# ---------------------------------------------------------------- server
New-Section "secServer" 74 | Out-Null
$script:nascondiIp = $false
if (Test-Path $hideFile) { $script:nascondiIp = ((Get-Content $hideFile -Raw).Trim() -eq "1") }
$chkHide = New-Object System.Windows.Forms.CheckBox
$chkHide.Location = New-Object System.Drawing.Point(470, 71)
$chkHide.Size = New-Object System.Drawing.Size(108, 20)
$chkHide.Font = $fLabel
$chkHide.ForeColor = $cText
$chkHide.BackColor = [System.Drawing.Color]::Transparent
$chkHide.Checked = $script:nascondiIp
$form.Controls.Add($chkHide)
$chkHide.BringToFront()
Reg $chkHide "hideIp" | Out-Null

$pServer = New-Object System.Windows.Forms.Panel
$pServer.Location = New-Object System.Drawing.Point($M, 100)
$pServer.Size = New-Object System.Drawing.Size($CW, 112)
$pServer.BackColor = $cPanel
$form.Controls.Add($pServer)
Set-Glass $pServer 140
Round-Ctl $pServer 10

$txtHost = New-Object System.Windows.Forms.TextBox
$txtHost.Location = New-Object System.Drawing.Point(14, 14)
$txtHost.Size = New-Object System.Drawing.Size(250, 30)
$txtHost.Font = $fMono
$txtHost.BackColor = [System.Drawing.Color]::FromArgb(22, 22, 32); $txtHost.ForeColor = $cAccent
$txtHost.BorderStyle = "FixedSingle"
$txtHost.UseSystemPasswordChar = $script:nascondiIp   # nascosto: pallini al posto dei numeri
$pServer.Controls.Add($txtHost)

New-Lbl ":" 270 18 10 24 $fMono $cMuted $pServer | Out-Null

$txtPort = New-Object System.Windows.Forms.TextBox
$txtPort.Text = "5029"
$txtPort.Location = New-Object System.Drawing.Point(284, 14)
$txtPort.Size = New-Object System.Drawing.Size(78, 30)
$txtPort.Font = $fMono
$txtPort.BackColor = [System.Drawing.Color]::FromArgb(22, 22, 32); $txtPort.ForeColor = $cAccent
$txtPort.BorderStyle = "FixedSingle"
$pServer.Controls.Add($txtPort)

$btnPaste = New-Btn "incolla" 374 13 74 30 $pServer
$btnTest  = New-Btn "prova" 458 13 74 30 $pServer "verde"

$lblTest = Reg (New-Lbl "" 16 56 516 22 $fBody $cMuted $pServer) "provaNota"
$lblTestHint = New-Lbl "" 16 78 516 30 $fLabel $cMuted $pServer

# ---------------------------------------------------------------- mod
New-Section "secMod" 226 | Out-Null

$pMod = New-Object System.Windows.Forms.Panel
$pMod.Location = New-Object System.Drawing.Point($M, 252)
$pMod.Size = New-Object System.Drawing.Size($CW, 146)
$pMod.BackColor = $cPanel
$form.Controls.Add($pMod)
Set-Glass $pMod 140
Round-Ctl $pMod 10

$lblDolphin = New-Lbl "" 16 12 516 20 $fBody $cMuted $pMod
$lblFiles1  = New-Lbl "" 16 36 516 20 $fBody $cMuted $pMod
$lblFiles2  = New-Lbl "" 16 60 516 20 $fBody $cMuted $pMod
$lblCurrent = New-Lbl "" 16 84 516 20 $fBody $cMuted $pMod

$btnInstall = New-Btn "installa" 16 108 180 30 $pMod "ambra"

$btnScegli  = New-Btn "scegli" 206 108 140 30 $pMod
$btnDolphin = New-Btn "avviaDolph" 356 108 176 30 $pMod

Reg (New-Lbl "" $M 406 $CW 32 $fLabel $cMuted $null) "riavvia" | Out-Null

# ---------------------------------------------------------------- salvataggio
New-Section "secSave" 444 | Out-Null

$chkAutoSave = New-Object System.Windows.Forms.CheckBox
$chkAutoSave.Location = New-Object System.Drawing.Point($M, 470)
$chkAutoSave.Size = New-Object System.Drawing.Size($CW, 24)
$chkAutoSave.Font = $fLabel
$chkAutoSave.ForeColor = $cText
$chkAutoSave.BackColor = [System.Drawing.Color]::Transparent
$chkAutoSave.Checked = $true
$form.Controls.Add($chkAutoSave)
Reg $chkAutoSave "auto" | Out-Null

Reg (New-Lbl "" $M 496 $CW 32 $fLabel $cMuted $null) "saveNota" | Out-Null

# ---------------------------------------------------------------- personaggio
# Il gioco legge la scelta da servers.txt (riga @luigi) quando parte: gli
# altri giocatori ti vedono col personaggio giusto, e tu vedi loro col loro.
New-Section "secPers" 540 | Out-Null
$luigiFile = Join-Path $here "luigi-client.txt"
$script:luigi = $false
if (Test-Path $luigiFile) { $script:luigi = ((Get-Content $luigiFile -Raw).Trim() -eq "1") }
$btnLuigi = New-Btn "marioBtn" ($M + [int](($CW - 290) / 2)) 566 290 38 $null $(if ($script:luigi) { "verde" } else { "rosso" })
$btnLuigi.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 10)
$btnLuigi.Padding = New-Object System.Windows.Forms.Padding(30, 0, 0, 0)   # a sinistra la faccia
function Carica-Icona($nome) {
    $f = Join-Path $here $nome
    if (-not (Test-Path $f)) { return $null }
    try {
        $byte = [System.IO.File]::ReadAllBytes($f)
        return [System.Drawing.Image]::FromStream((New-Object System.IO.MemoryStream (,$byte)))
    } catch { return $null }
}
$script:icoLuigi = Carica-Icona "icona-luigi.png"
$script:icoMario = Carica-Icona "icona-mario.png"
$lblLuigi = New-Lbl "" ($M + 226) 566 ($CW - 226) 38 $fLabel $cMuted $null
$lblLuigi.TextAlign = "MiddleLeft"
$lblLuigi.Visible = $false      # il tasto stesso dice con chi stai giocando
$script:regLuigi = @{ C = $lblLuigi; K = $(if ($script:luigi) { "luigiOn" } else { "luigiOff" }) }
[void]$script:testi.Add($script:regLuigi)
$lblLuigi.Text = T $script:regLuigi.K

# ---------------------------------------------------------------- strumenti
$lblDevSec = New-Section "secLog" 620
$lblDevLine = $script:ultimaRiga

$devPanel = New-Object System.Windows.Forms.Panel
$devPanel.Location = New-Object System.Drawing.Point($M, 646)
$devPanel.Size = New-Object System.Drawing.Size($CW, 216)
$devPanel.BackColor = $cPanel2
$form.Controls.Add($devPanel)
Set-Glass $devPanel 170
Round-Ctl $devPanel 10

$txtLog = New-Object System.Windows.Forms.TextBox
$txtLog.Location = New-Object System.Drawing.Point(12, 12)
$txtLog.Size = New-Object System.Drawing.Size(532, 158)
$txtLog.Multiline = $true
$txtLog.ScrollBars = "Vertical"
$txtLog.ReadOnly = $true
$txtLog.Font = $fSmall
$txtLog.BackColor = [System.Drawing.Color]::FromArgb(18, 18, 27)
$txtLog.ForeColor = [System.Drawing.Color]::FromArgb(150, 210, 180)
$txtLog.BorderStyle = "FixedSingle"
$devPanel.Controls.Add($txtLog)
Round-Ctl $txtLog 6

$btnSaveGet  = New-Btn "prendi" 12 180 220 28 $devPanel
$btnSaveBack = New-Btn "rimetti" 240 180 140 28 $devPanel
$btnFolder   = New-Btn "cartella" 388 180 156 28 $devPanel

# i suoni della pausa del gioco, per accendere e spegnere il dev mode
function Carica-Suono($nome) {
    $f = Join-Path $here $nome
    if (-not (Test-Path $f)) { return $null }
    try {
        $sp = New-Object System.Media.SoundPlayer $f
        $sp.Load()          # in memoria adesso: al primo clic non deve esitare
        return $sp
    } catch { return $null }
}
function Suona($sp) {
    if ($null -eq $sp) { return }
    try { $sp.Play() } catch { }     # Play() non blocca il pannello
}
$script:sndDevOn = Carica-Suono "suono-dev-on.wav"
$script:sndDevOff = Carica-Suono "suono-dev-off.wav"

$script:dev = $false
if (Test-Path $devFile) {
    $script:dev = ((Get-Content $devFile -Raw -ErrorAction SilentlyContinue).Trim() -eq "1")
}

# La finestra non salta da un'altezza all'altra: ci arriva in dieci passi da
# 16 millesimi, svelta all'inizio e morbida alla fine. La sezione degli
# strumenti si accende prima di crescere e si spegne dopo essersi ritirata,
# cosi' si vede scorrere invece di comparire di colpo.
$ALTO = 920
$BASSO = 670

$script:dvA = 0
$script:dvB = 0
$script:dvI = 0
$script:dvN = 10
$devTime = New-Object System.Windows.Forms.Timer
$devTime.Interval = 16
$devTime.Add_Tick({
    $script:dvI++
    $q = $script:dvI / $script:dvN
    if ($q -ge 1) {
        $devTime.Stop()
        $form.Height = $script:dvB
        if (-not $script:dev) {
            $lblDevSec.Visible = $false
            $lblDevLine.Visible = $false
            $devPanel.Visible = $false
        }
        return
    }
    $e = 1 - [Math]::Pow(1 - $q, 3)
    $form.Height = [int]($script:dvA + ($script:dvB - $script:dvA) * $e)
})

function Apply-Dev($animato = $false) {
    $meta = $(if ($script:dev) { $ALTO } else { $BASSO })

    if ($animato) {
        if ($script:dev) {
            # in salita si accende subito: deve gia' esserci mentre si scopre
            $lblDevSec.Visible = $true
            $lblDevLine.Visible = $true
            $devPanel.Visible = $true
        }
        $devTime.Stop()
        $script:dvA = $form.Height
        $script:dvB = $meta
        $script:dvI = 0
        $devTime.Start()
    } else {
        $devTime.Stop()
        $lblDevSec.Visible = $script:dev
        $lblDevLine.Visible = $script:dev
        $devPanel.Visible = $script:dev
        $form.Size = New-Object System.Drawing.Size($W, $meta)
    }

    if ($null -ne $script:pillA) {
        $t = $(if ($script:dev) { "ambra" } else { "chiaro" })
        $btnDev.Tag = @{ Fermo = (Componi $btnDev $script:pillA $t); Sopra = (Componi $btnDev $script:pillB $t) }
        $btnDev.BackgroundImage = $btnDev.Tag.Fermo
        $btnDev.ForeColor = $INCHIOSTRO[$t]
    } elseif ($script:dev) {
        $btnDev.ForeColor = $cAccent
        $btnDev.FlatAppearance.BorderColor = $cAccent
    } else {
        $btnDev.ForeColor = $cMuted
        $btnDev.FlatAppearance.BorderColor = $cMuted
    }
    Set-Content -Path $devFile -Value $(if ($script:dev) { "1" } else { "0" }) -NoNewline -Encoding ascii
}

$btnDev.Add_Click({
    $script:dev = -not $script:dev
    Suona $(if ($script:dev) { $script:sndDevOn } else { $script:sndDevOff })
    Apply-Dev $true
})


# ---------------------------------------------------------------- nascondi IP
# Per i video: gli indirizzi si vedono come ***.***.***.***. Il registro si
# tiene anche "in chiaro" da parte, cosi' spegnendo l'opzione torna leggibile.
$script:logRaw = New-Object System.Text.StringBuilder
function Maschera($t) {
    if ($null -eq $t) { return $t }
    if (-not $script:nascondiIp) { return $t }
    return [regex]::Replace([string]$t, '\b\d{1,3}(\.\d{1,3}){3}\b', '***.***.***.***')
}

function Log($msg) {
    $riga = "$(Get-Date -Format 'HH:mm:ss')  $msg`r`n"
    [void]$script:logRaw.Append($riga)
    $txtLog.AppendText((Maschera $riga))
    $txtLog.SelectionStart = $txtLog.TextLength
    $txtLog.ScrollToCaret()
}

# ---------------------------------------------------------------- Dolphin
function Find-Dolphin {
    # se qualcuno l'ha indicato a mano, quello vince su tutto
    if (Test-Path $dolphinFile) {
        $scelto = (Get-Content $dolphinFile -Raw).Trim()
        if ($scelto -ne "" -and (Test-Path $scelto)) { return $scelto }
    }
    $candidates = @(
        # poi quello che viaggia col kit: cosi' non serve installare niente
        (Join-Path $here "Dolphin\Dolphin.exe"),
        (Join-Path $env:USERPROFILE "Desktop\Dolphin-x64\Dolphin.exe"),
        (Join-Path $env:ProgramFiles "Dolphin\Dolphin.exe"),
        (Join-Path ${env:ProgramFiles(x86)} "Dolphin\Dolphin.exe")
    )
    foreach ($c in $candidates) { if ($c -and (Test-Path $c)) { return $c } }
    $lnk = Join-Path $env:USERPROFILE "Desktop\Dolphin - collegamento.lnk"
    if (Test-Path $lnk) {
        try {
            $sh = New-Object -ComObject WScript.Shell
            $t = $sh.CreateShortcut($lnk).TargetPath
            if ($t -and (Test-Path $t)) { return $t }
        } catch { }
    }
    return $null
}
$script:dolphinPath = Find-Dolphin

# ---------------------------------------------------------------- stato
function Refresh-Status {
    if ($script:dolphinPath) {
        $lblDolphin.Text = T "dolphSi"
        if ($script:dolphinPath -like (Join-Path $here "Dolphin\*")) { $lblDolphin.Text = T "dolphKit" }
        elseif (Test-Path $dolphinFile) { $lblDolphin.Text = T "dolphScelto" }
        $lblDolphin.ForeColor = $cOk
        $btnDolphin.Enabled = $true
    } else {
        $lblDolphin.Text = T "dolphNo"
        $lblDolphin.ForeColor = $cBad
        $btnDolphin.Enabled = $false
    }

    $miss1 = @(); $miss2 = @()
    foreach ($f in $modFiles) {
        if (-not (Test-Path (Join-Path $riivRoot $f))) { $miss1 += $f }
        if (-not (Test-Path (Join-Path $riivSub  $f))) { $miss2 += $f }
    }

    if ($miss1.Count -eq 0) {
        $lblFiles1.Text = T "fileOk1"; $lblFiles1.ForeColor = $cOk
    } else {
        $lblFiles1.Text = (T "fileNo1") -f ($miss1 -join ', '); $lblFiles1.ForeColor = $cBad
    }

    if ($miss2.Count -eq 0) {
        $lblFiles2.Text = T "fileOk2"; $lblFiles2.ForeColor = $cOk
    } else {
        $lblFiles2.Text = (T "fileNo2") -f ($miss2 -join ', '); $lblFiles2.ForeColor = $cBad
    }

    $cur = Join-Path $riivRoot "serverIP.txt"
    if (Test-Path $cur) {
        $val = (Get-Content $cur -Raw).Trim()
        $lblCurrent.Text = Maschera ((T "adesso") -f $val)
        $lblCurrent.ForeColor = $cText
    } else {
        $lblCurrent.Text = T "adessoNo"
        $lblCurrent.ForeColor = $cBad
    }
}

function Apply-Language {
    foreach ($e in $script:testi) { $e.C.Text = T $e.K }
    $form.Text = T "titolo"
    Refresh-Status
    Set-Content -Path $langFile -Value $script:lang -NoNewline -Encoding ascii
}

$cmbLang.Add_SelectedIndexChanged({
    $script:lang = $(if ($cmbLang.SelectedIndex -eq 1) { "en" } else { "it" })
    Apply-Language
})

# ---------------------------------------------------------------- azioni
$btnPaste.Add_Click({
    $clip = ""
    try { $clip = (Get-Clipboard -Raw) } catch { }
    if ([string]::IsNullOrWhiteSpace($clip)) { Log (T "logVuoto"); return }
    $clip = $clip.Trim()
    if ($clip -match '^\s*(\d{1,3}(?:\.\d{1,3}){3})\s*(?::\s*(\d{1,5}))?\s*$') {
        $txtHost.Text = $matches[1]
        if ($matches[2]) { $txtPort.Text = $matches[2] }
        Log ((T "logIncolla") -f "$($txtHost.Text):$($txtPort.Text)")
    } else {
        Log (T "logNoAddr")
    }
})

$btnTest.Add_Click({
    $h = $txtHost.Text.Trim()
    $p = $txtPort.Text.Trim()
    if ([string]::IsNullOrWhiteSpace($h)) { Log (T "logPrima"); return }
    if (-not (Test-Path $connTest)) {
        Log (T "logNoConn")
        $lblTest.Text = T "senzaConn"
        $lblTest.ForeColor = $cBad
        return
    }
    $lblTest.Text = T "provando"; $lblTest.ForeColor = $cMuted
    $lblTestHint.Text = ""
    $form.Refresh()

    $out = & $connTest $h $p 2>&1 | Out-String
    $out = $out.Trim()
    Log "ConnTest: $out"

    if ($out -match '^OK id=(\d+) rtt=(\d+)') {
        $lblTest.Text = (T "raggiung") -f $matches[2]
        $lblTest.ForeColor = $cOk
        $lblTestHint.Text = (T "raggNota") -f $matches[1]
        $lblTestHint.ForeColor = $cMuted
    } else {
        $lblTest.Text = T "nonRagg"
        $lblTest.ForeColor = $cBad
        if ($out -match 'nessuna risposta') {
            $lblTestHint.Text = (T "nonRaggA") -f $p
        } elseif ($out -match 'non valido') {
            $lblTestHint.Text = T "nonRaggB"
        } else {
            $lblTestHint.Text = $out
        }
        $lblTestHint.ForeColor = $cBad
    }
})

# I server accesi. Il gioco legge servers.txt all'avvio e mostra la ruota dei
# salvataggi solo se c'e' almeno un server: quindi qui ci scrivo solo quelli
# che rispondono davvero, cosi' con tutti i server spenti la ruota resta vuota.
function Write-ServersChecked {
    $candidati = @()
    $auto = $false
    $nomeKit = ""

    # 1. quello che sta nella casella: e' l'indirizzo che si sta usando adesso
    $hBox = $txtHost.Text.Trim()
    $pBox = $txtPort.Text.Trim()
    if ($pBox -eq "") { $pBox = "5029" }

    # 2. poi quelli scritti nel kit
    $src = Join-Path $here "servers.txt"
    if (Test-Path $src) {
        foreach ($riga in (Get-Content $src)) {
            $t = $riga.Trim()
            # la riga @auto dice al gioco di entrare da solo nel salvataggio 1:
            # va conservata, se no rigenerando la lista si perderebbe
            if ($t.StartsWith("@")) { if ($t -ne "@luigi") { $auto = $true }; continue }
            if ($t -eq "" -or $t.StartsWith("#")) { continue }
            $nome = ""
            $indirizzo = $t
            if ($t.Contains("|")) {
                $parti = $t.Split("|", 2)
                $nome = $parti[0].Trim()
                $indirizzo = $parti[1].Trim()
            }
            $ip = $indirizzo
            $porta = "5029"
            if ($indirizzo.Contains(":")) {
                $parti = $indirizzo.Split(":", 2)
                $ip = $parti[0].Trim()
                $porta = $parti[1].Trim()
            }
            if ($nomeKit -eq "" -and $nome -ne "") { $nomeKit = $nome }
            $candidati += @{ Nome = $nome; Ip = $ip; Porta = $porta }
        }
    }

    if ($hBox -ne "") {
        # stesso server, altra strada (rete di casa invece della VPN): gli si
        # da' il nome del kit, cosi' in gioco si legge quello di sempre
        $gia = $false
        foreach ($c in $candidati) { if ($c.Ip -eq $hBox -and $c.Porta -eq $pBox) { $gia = $true } }
        if (-not $gia) {
            $nome = $nomeKit
            if ($nome -eq "") { $nome = "Server" }
            $candidati = @(@{ Nome = $nome; Ip = $hBox; Porta = $pBox }) + $candidati
        }
    }

    $righe = @()
    $vivi = @()
    foreach ($c in $candidati) {
        $ok = $false
        if (Test-Path $connTest) {
            $out = & $connTest $c.Ip $c.Porta 2>&1 | Out-String
            $ok = $out -match '^OK id=(\d+)'
        }
        if ($ok) {
            $vivi += $(if ($c.Nome -ne "") { $c.Nome } else { $c.Ip })
            if ($c.Nome -ne "") { $righe += ($c.Nome + "|" + $c.Ip + ":" + $c.Porta) }
            else { $righe += ($c.Ip + ":" + $c.Porta) }
        }
        Log ((T "logServer") -f ($c.Ip + ":" + $c.Porta), $(if ($ok) { T "srvOn" } else { T "srvOff" }))
    }

    $testo = ""
    if ($script:luigi) { $testo += "@luigi`r`n" }
    if ($auto) { $testo += "@auto`r`n" }
    $testo += "# Generato dal pannello: solo i server che rispondevano.`r`n"
    foreach ($r in $righe) { $testo += "$r`r`n" }
    foreach ($dir in @($riivRoot, $riivSub)) {
        if (Test-Path $dir) { Set-Content -Path (Join-Path $dir "servers.txt") -Value $testo -NoNewline -Encoding ascii }
    }
    if ($vivi.Count -eq 0) { Log (T "logNessuno") } else { Log ((T "logAccesi") -f ($vivi -join ", ")) }
}

# Accende o spegne Luigi: colore del tasto, scritta accanto, e la riga @luigi
# nelle liste gia' scritte (senza rifare le prove dei server: e' immediato).
# Il tasto dice con chi stai giocando: Mario (rosso, "You are playing as Mario")
# o Luigi (verde, "You are playing as Luigi"). Premendolo si cambia.
function Con-Faccia($img) {
    $ico = $(if ($script:luigi) { $script:icoLuigi } else { $script:icoMario })
    if ($null -eq $ico) { return $img }
    $g = [System.Drawing.Graphics]::FromImage($img)
    $g.InterpolationMode = "HighQualityBicubic"
    $h = $btnLuigi.Height - 8
    $w = [int]($ico.Width * $h / $ico.Height)
    $g.DrawImage($ico, 14, 4, $w, $h)
    $g.Dispose()
    return $img
}

function Aggiorna-Luigi {
    $tinta = $(if ($script:luigi) { "verde" } else { "rosso" })
    if ($null -ne $script:pillA) {
        $btnLuigi.Tag = @{ Fermo = (Con-Faccia (Componi $btnLuigi $script:pillA $tinta)); Sopra = (Con-Faccia (Componi $btnLuigi $script:pillB $tinta)) }
        $btnLuigi.BackgroundImage = $btnLuigi.Tag.Fermo
        $btnLuigi.ForeColor = $INCHIOSTRO[$tinta]
    }
    foreach ($e in $script:testi) {
        if ($e.C -eq $btnLuigi) { $e.K = $(if ($script:luigi) { "luigiBtn" } else { "marioBtn" }) }
    }
    $btnLuigi.Text = T $(if ($script:luigi) { "luigiBtn" } else { "marioBtn" })
    $script:regLuigi.K = $(if ($script:luigi) { "luigiOn" } else { "luigiOff" })
    $lblLuigi.Text = T $script:regLuigi.K
}

function Scrivi-RigaLuigi {
    foreach ($dir in @($riivRoot, $riivSub)) {
        $f = Join-Path $dir "servers.txt"
        if (-not (Test-Path $f)) { continue }
        $righe = @(Get-Content $f | Where-Object { $_.Trim() -ne "@luigi" })
        if ($script:luigi) { $righe = @("@luigi") + $righe }
        Set-Content -Path $f -Value (($righe -join "`r`n") + "`r`n") -NoNewline -Encoding ascii
    }
}

Aggiorna-Luigi                 # all'apertura: faccia e scritta giuste da subito

$btnLuigi.Add_Click({
    $script:luigi = -not $script:luigi
    try { Set-Content -Path $luigiFile -Value $(if ($script:luigi) { "1" } else { "0" }) -NoNewline -Encoding ascii } catch { }
    Aggiorna-Luigi
    Scrivi-RigaLuigi
    Log (T $(if ($script:luigi) { "logLuigiOn" } else { "logLuigiOff" }))
    Suona $script:sndOk
})

$btnInstall.Add_Click({
    $h = $txtHost.Text.Trim()
    $p = $txtPort.Text.Trim()
    if ([string]::IsNullOrWhiteSpace($h)) { Log (T "logPrima"); return }

    try {
        $gia = Test-Path (Join-Path $riivRoot "CustomCode_USA.bin")
        New-Item -ItemType Directory -Force -Path $riivRoot | Out-Null
        New-Item -ItemType Directory -Force -Path $riivSub  | Out-Null

        $copied = 0
        foreach ($f in $modFiles) {
            $src = Join-Path $here $f
            if (Test-Path $src) {
                Copy-Item $src -Destination (Join-Path $riivRoot $f) -Force
                Copy-Item $src -Destination (Join-Path $riivSub  $f) -Force
                $copied++
            } else {
                Log ((T "logSalto") -f $f)
            }
        }

        # Le texture scure (schermata del laccetto) non sono file del mod: vanno
        # nella cartella delle texture di Dolphin, e vanno accese nelle
        # impostazioni grafiche con "Load Custom Textures".
        $texDir = Join-Path $env:APPDATA "Dolphin Emulator\Load\Textures\RMGE01"
        $tex = @(Get-ChildItem (Join-Path $here "efb1_*.png") -ErrorAction SilentlyContinue)
        if ($tex.Count -gt 0) {
            New-Item -ItemType Directory -Force -Path $texDir | Out-Null
            foreach ($t in $tex) { Copy-Item $t.FullName -Destination $texDir -Force }
            Log ((T "logTex") -f $tex.Count)
        }

        foreach ($dir in @($riivRoot, $riivSub)) {
            Set-Content -Path (Join-Path $dir "serverIP.txt") -Value "${h}:${p}" -NoNewline -Encoding ascii
            Set-Content -Path (Join-Path $dir "debugIP.txt")  -Value "${h}:5001" -NoNewline -Encoding ascii
        }

        Write-ServersChecked
        Log ((T "logInst") -f $copied, "${h}:${p}")
        Log (T "logRicorda")
        Refresh-Status
        Suona $script:sndOk
        [System.Windows.Forms.MessageBox]::Show((T $(if ($gia) { "mbAgg" } else { "mbInst" })), "SMG Multiplayer", "OK", "Information") | Out-Null
    } catch {
        Log ((T "logErrInst") -f $_)
    }
})

# Quando Dolphin non si trova da solo (installato in un posto strano, portatile
# su un'altra unita', rinominato) lo si indica una volta e il pannello se lo
# ricorda in dolphin.txt.
$btnScegli.Add_Click({
    $f = New-Object System.Windows.Forms.OpenFileDialog
    $f.Title = T "scegliT"
    $f.Filter = "Dolphin.exe|Dolphin.exe|Programmi (*.exe)|*.exe"
    if (Test-Path $dolphinFile) {
        $vecchio = (Get-Content $dolphinFile -Raw).Trim()
        if ($vecchio -ne "" -and (Test-Path $vecchio)) { $f.InitialDirectory = Split-Path $vecchio -Parent }
    }
    if ($f.ShowDialog() -ne "OK") { return }
    Set-Content -Path $dolphinFile -Value $f.FileName -NoNewline -Encoding ascii
    $script:dolphinPath = Find-Dolphin
    Refresh-Status
    Log ((T "logScelto") -f $f.FileName)
})

$chkHide.Add_CheckedChanged({
    $script:nascondiIp = $chkHide.Checked
    Set-Content -Path $hideFile -Value $(if ($script:nascondiIp) { "1" } else { "0" }) -NoNewline -Encoding ascii
    $txtHost.UseSystemPasswordChar = $script:nascondiIp
    Refresh-Status
    $txtLog.Text = (Maschera $script:logRaw.ToString())
    $txtLog.SelectionStart = $txtLog.TextLength
    $txtLog.ScrollToCaret()
})

$btnFolder.Add_Click({
    if (Test-Path $riivRoot) { Start-Process explorer.exe $riivRoot }
    else { Log (T "logNoCart") }
})

$btnDolphin.Add_Click({
    if (-not $script:dolphinPath) { return }
    Write-ServersChecked        # lista fresca: solo i server accesi adesso
    # Se non c'e' nessun server acceso, nel gioco la schermata dei
    # salvataggi resta vuota: meglio dirlo qui che lasciarlo scoprire dopo.
    $listaVuota = $true
    foreach ($dir in @($riivRoot, $riivSub)) {
        $f = Join-Path $dir "servers.txt"
        if (Test-Path $f) {
            foreach ($riga in (Get-Content $f)) {
                $t = $riga.Trim()
                if ($t -ne "" -and -not $t.StartsWith("#")) { $listaVuota = $false }
            }
        }
    }
    if ($listaVuota) {
        $risposta = [System.Windows.Forms.MessageBox]::Show(
            (T "mbOffline"), (T "mbOfflineT"), "YesNo", "Warning")
        if ($risposta -ne "Yes") { Log (T "logAnnull"); return }
    }
    $argomenti = @()
    if ($chkAutoSave.Checked) {
        $h = $txtHost.Text.Trim()
        if ($h -ne "" -and (Test-SaveShare $h)) {
            $out = Aggiorna-Salvataggio $h $true
            if ($out -match '^OK') {
                $argomenti = Argomenti-Nand
                Log (T "logNandOn")
            }
        } else {
            Log (T "logNoShare")
        }
    }
    if ($argomenti.Count -gt 0) {
        $script:dolphinProc = Start-Process $script:dolphinPath -ArgumentList $argomenti -PassThru
    } else {
        $script:dolphinProc = Start-Process $script:dolphinPath -PassThru
    }
    $watch.Start()
    $script:vivo = $true
    $guardia.Start()
    Log (T "logDolph")
})

# Il server puo' spegnersi mentre si gioca: da dentro il gioco non si capisce,
# si vedono solo gli altri Mario sparire. Qui invece si sente subito.
$script:vivo = $true
$guardia = New-Object System.Windows.Forms.Timer
$guardia.Interval = 5000
$guardia.Add_Tick({
    if ($null -eq $script:dolphinProc -or $script:dolphinProc.HasExited) {
        $guardia.Stop()
        return
    }
    $h = $txtHost.Text.Trim()
    $pr = $txtPort.Text.Trim()
    if ($h -eq "" -or -not (Test-Path $connTest)) { return }
    $out = & $connTest $h $pr 2>&1 | Out-String
    $ok = $out -match '^OK id=(\d+)'
    if ($ok -eq $script:vivo) { return }        # niente di nuovo
    $script:vivo = $ok
    # la lista va riscritta in tutti e due i casi: il gioco la rilegge da solo
    # ogni due secondi, e cosi' si accorge del server che va e che torna
    Write-ServersChecked
    if ($ok) {
        Log ((T "logTornato") -f "${h}:${pr}")
    } else {
        Log ((T "logCaduto") -f "${h}:${pr}")
    }
})

# Quando Dolphin si chiude, il salvataggio dell'host va tolto e rimesso il tuo.
$watch = New-Object System.Windows.Forms.Timer
$watch.Interval = 2000
$watch.Add_Tick({
    if ($null -eq $script:dolphinProc) { $watch.Stop(); return }
    if (-not $script:dolphinProc.HasExited) { return }
    $watch.Stop()
    $guardia.Stop()
    $script:dolphinProc = $null
    Log (T "logChiuso")
})

# Salvataggio dell'host: chi ospita puo' condividere il suo, cosi' giocate
# tutti nel suo mondo. Il proprio salvataggio viene messo da parte prima, in
# "backup-salvataggi" accanto alla cartella dei salvataggi di Dolphin.

# Dolphin tiene i salvataggi Wii nella cartella indicata da NANDRootPath, e
# accetta di cambiarla per un avvio solo: --config Dolphin.General.NANDRootPath.
# Cosi' non si scrive niente nelle sue impostazioni e non c'e' niente da
# rimettere a posto dopo: il gioco aperto dall'icona trova il salvataggio di
# sempre, quello aperto da qui trova il mondo del server.
function Argomenti-Nand {
    $slash = $nandMulti.Replace([char]92, [char]47)
    # Le virgolette servono: il percorso contiene uno spazio ("Dolphin Emulator")
    # e senza si spezzerebbe in due, con Dolphin che si lamenta di una cartella
    # di nome "Emulator/Wii-server".
    return @("--config", ('"Dolphin.General.NANDRootPath=' + $slash + '"'))
}

# Le versioni vecchie del pannello quella riga la scrivevano davvero nell'ini.
# Se e' rimasta li' va tolta, se no varrebbe per sempre, anche da sola.
function Pulisci-Ini {
    if (-not (Test-Path $iniFile)) { return }
    try {
        $testo = Get-Content $iniFile -Raw
        if ($testo -match '(?m)^NANDRootPath\s*=\s*(.*)$') {
            $val = $matches[1].Trim().Replace([char]47, [char]92)
            if ($val -eq $nandMulti) {
                $testo = $testo -replace '(?m)^NANDRootPath\s*=.*\r?\n', ""
                $testo = $testo.TrimEnd([char]13, [char]10) + "`r`n"
                [System.IO.File]::WriteAllText($iniFile, $testo, (New-Object System.Text.UTF8Encoding $false))
                Log (T "logIniPulito")
            }
        }
    } catch { }
}

# Scarica il salvataggio dell'host nella NAND del multigiocatore
function Aggiorna-Salvataggio($indirizzo, $zitto) {
    New-Item -ItemType Directory -Force -Path $saveMulti | Out-Null
    return (Invoke-Save @("-Server", $indirizzo, "-SaveDir", $saveMulti, "-Separata") $zitto)
}

# L'host sta condividendo? Basta vedere se la porta 5030 accetta.
function Test-SaveShare($indirizzo) {
    try {
        $c = New-Object System.Net.Sockets.TcpClient
        $a = $c.BeginConnect($indirizzo, 5030, $null, $null)
        $ok = $a.AsyncWaitHandle.WaitOne(1500)
        if ($ok) { $c.EndConnect($a) }
        $c.Close()
        return $ok
    } catch { return $false }
}

function Invoke-Save($argomenti, $zitto = $false) {
    if (-not (Test-Path $fetchScript)) { Log (T "logNoFetch"); return "NO SaveFetch.ps1" }
    $dolphin = @(Get-Process -Name Dolphin -ErrorAction SilentlyContinue)
    if ($dolphin.Count -gt 0) {
        Log (T "logDolAp")
        return "NO Dolphin"
    }
    $tutti = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$fetchScript`"") + $argomenti
    $out = & powershell.exe @tutti 2>&1 | Out-String
    $out = $out.Trim()
    Log $out
    if (-not $zitto) {
        if ($out -match '^OK') {
            [System.Windows.Forms.MessageBox]::Show($out, (T "mbSaveOkT"), "OK", "Information") | Out-Null
        } else {
            [System.Windows.Forms.MessageBox]::Show($out, (T "mbSaveOkT"), "OK", "Warning") | Out-Null
        }
    }
    return $out
}

$btnSaveGet.Add_Click({
    $h = $txtHost.Text.Trim()
    if ([string]::IsNullOrWhiteSpace($h)) { Log (T "logPrimaH"); return }
    $out = Aggiorna-Salvataggio $h $false
})

# Avvia Dolphin senza dirgli niente: il salvataggio e' il suo di sempre.
# Chi arriva dalla versione vecchia, che il salvataggio lo sostituiva davvero,
# ha ancora il suo backup da rimettere: lo si fa solo in quel caso.
$btnSaveBack.Add_Click({
    $segno = Join-Path $env:APPDATA ("Dolphin Emulator" + [char]92 + "Wii" + [char]92 + "title" + [char]92 +
             "00010000" + [char]92 + "524d4745" + [char]92 + "backup-salvataggi" + [char]92 + "salvataggio-host-attivo.txt")
    if (Test-Path $segno) { Invoke-Save @("-Restore") $false | Out-Null }
    if (-not $script:dolphinPath) { Log (T "logNoDolph"); return }
    $script:dolphinProc = Start-Process $script:dolphinPath -PassThru
    $watch.Start()
    Log (T "logMio")
})

# ---------------------------------------------------------------- avvio
$cur = Join-Path $riivRoot "serverIP.txt"
if (Test-Path $cur) {
    $val = (Get-Content $cur -Raw).Trim()
    if ($val -match '^(\d{1,3}(?:\.\d{1,3}){3})(?::(\d{1,5}))?') {
        $txtHost.Text = $matches[1]
        if ($matches[2]) { $txtPort.Text = $matches[2] }
    }
}

# ---------------------------------------------------------------- schermata d'avvio
# Come sul server: prima si vede la copertina con un pulsante solo, che qui
# apre il pannello. Le immagini le prepara avvio.ps1; se mancano si parte
# dritti sul pannello.
$script:splash = $null

function Carica-Img($percorso) {
    if (-not (Test-Path $percorso)) { return $null }
    try {
        $byte = [System.IO.File]::ReadAllBytes($percorso)
        $ms = New-Object System.IO.MemoryStream (,$byte)
        return [System.Drawing.Image]::FromStream($ms)
    } catch { return $null }
}

$script:sndFocus = Carica-Suono "suono-focus.wav"
$script:sndOk = Carica-Suono "suono-ok.wav"

$imgSch = Carica-Img (Join-Path $here "schermata-client.png")
$imgTasto = Carica-Img (Join-Path $here "tasto-client.png")
$imgTasto2 = Carica-Img (Join-Path $here "tasto-client2.png")

if ($null -ne $imgSch -and $null -ne $imgTasto) {
    $splash = New-Object System.Windows.Forms.Panel
    $splash.Dock = "Fill"
    $splash.BackgroundImage = $imgSch
    $splash.BackgroundImageLayout = "None"
    $splash.BackColor = $cBg
    $form.Controls.Add($splash)
    $splash.BringToFront()
    $script:splash = $splash

    $tasto = New-Object System.Windows.Forms.PictureBox
    $tasto.Cursor = "Hand"
    $splash.Controls.Add($tasto)

    # Animazione a 60 fotogrammi al secondo: il pulsante non salta da un disegno
    # all'altro, ci arriva in sei passi da 16 millesimi. Le figure sono pronte
    # prima, tutte della stessa misura e col pulsante centrato: cosi' cambia
    # solo l'immagine e non c'e' sfarfallio.
    $cw = [int]($imgTasto.Width * 1.30)
    $ch = [int]($imgTasto.Height * 2.00)
    $bx = [int]((604 - $cw) / 2)
    $by = [int](770 - $ch / 2)
    $due = $(if ($null -ne $imgTasto2) { $imgTasto2 } else { $imgTasto })

    # Ogni figura si porta dietro il pezzo di copertina che le sta sotto. Senza,
    # il pulsante dovrebbe essere trasparente e Windows ridisegnerebbe anche la
    # copertina a ogni fotogramma: e' li' che si vedeva lo sfarfallio.
    function Fondo-Tasto($cw, $ch) {
        $b = New-Object System.Drawing.Bitmap $cw, $ch
        $g = [System.Drawing.Graphics]::FromImage($b)
        $dst = New-Object System.Drawing.Rectangle 0, 0, $cw, $ch
        $g.DrawImage($imgSch, $dst, $bx, $by, $cw, $ch, "Pixel")
        $g.Dispose()
        return $b
    }

    function Scala-Tasto($img, $sc, $cw, $ch) {
        $b = Fondo-Tasto $cw $ch
        $g = [System.Drawing.Graphics]::FromImage($b)
        $g.InterpolationMode = "HighQualityBicubic"
        $w = [int]($img.Width * $sc); $h = [int]($img.Height * $sc)
        $g.DrawImage($img, [int](($cw - $w) / 2), [int](($ch - $h) / 2), $w, $h)
        $g.Dispose()
        return $b
    }

    $PASSI = 6                      # quanti passi per salire e scendere
    $script:frames = @( (Scala-Tasto $imgTasto 0.94 $cw $ch) )   # 0 = fermo
    for ($i = 1; $i -le $PASSI; $i++) {
        $q = $i / $PASSI
        $sc = 0.94 + 0.06 * (1 - [Math]::Pow(1 - $q, 2))         # rallenta alla fine
        $script:frames += (Scala-Tasto $due $sc $cw $ch)
    }
    $script:frames += (Scala-Tasto $due 0.90 $cw $ch)            # premuto
    $script:fTop = $PASSI
    $script:fGiu = $PASSI + 1

    $tasto.Size = New-Object System.Drawing.Size $cw, $ch
    $tasto.Location = New-Object System.Drawing.Point $bx, $by
    $tasto.Image = $script:frames[0]

    # Lo scoppio di quando si preme, come il logo del titolo: la pillola si
    # schiaccia, rimbalza piu' grande del normale e torna a posto, con un lampo
    # dietro. Diciotto figure a 16 millesimi: circa un terzo di secondo.
    function Lampo($g, $cx, $cy, $rx, $ry, $alpha) {
        if ($alpha -le 0) { return }
        $pth = New-Object System.Drawing.Drawing2D.GraphicsPath
        $pth.AddEllipse(($cx - $rx), ($cy - $ry), (2 * $rx), (2 * $ry))
        $pgb = New-Object System.Drawing.Drawing2D.PathGradientBrush $pth
        $pgb.CenterColor = [System.Drawing.Color]::FromArgb([int]$alpha, 180, 240, 255)
        $pgb.SurroundColors = @([System.Drawing.Color]::FromArgb(0, 120, 200, 255))
        $g.FillPath($pgb, $pth)
        $pgb.Dispose(); $pth.Dispose()
    }

    $script:burst = @()
    $NB = 18
    for ($i = 0; $i -lt $NB; $i++) {
        $t = $i / ($NB - 1)
        if ($t -lt 0.18) {
            $sc = 0.90 + ($t / 0.18) * 0.03                                  # schiacciata
        } else {
            $u = ($t - 0.18) / 0.82
            $sc = 1.0 + 0.15 * [Math]::Sin([Math]::PI * $u) * (1 - $u * 0.45) # rimbalzo
        }
        $bm = Fondo-Tasto $cw $ch
        $gg = [System.Drawing.Graphics]::FromImage($bm)
        $gg.SmoothingMode = "AntiAlias"
        $gg.InterpolationMode = "HighQualityBicubic"
        Lampo $gg ($cw / 2) ($ch / 2) ($imgTasto.Width * 0.58 * (0.85 + 0.35 * $t)) ($imgTasto.Height * 0.62 * (0.85 + 0.35 * $t)) (110 * [Math]::Sin([Math]::PI * $t))
        $w2 = [int]($due.Width * $sc); $h2 = [int]($due.Height * $sc)
        $gg.DrawImage($due, [int](($cw - $w2) / 2), [int](($ch - $h2) / 2), $w2, $h2)
        $gg.Dispose()
        $script:burst += $bm
    }

    $script:fIdx = 0
    $script:fMeta = 0
    $anim = New-Object System.Windows.Forms.Timer
    $anim.Interval = 16             # 60 volte al secondo
    $anim.Add_Tick({
        if ($script:fIdx -eq $script:fMeta) { $anim.Stop(); return }
        if ($script:fIdx -lt $script:fMeta) { $script:fIdx++ } else { $script:fIdx-- }
        $tasto.Image = $script:frames[$script:fIdx]
    })

    # Mentre scorre lo scoppio i due temporizzatori si contenderebbero la figura
    # da mostrare: finche' quello dura, il passaggio del mouse non tocca niente.
    $tasto.Add_MouseEnter({
        if ($null -ne $sco -and $sco.Enabled) { return }
        Suona $script:sndFocus
        $script:fMeta = $script:fTop
        $anim.Start()
    })
    $tasto.Add_MouseLeave({
        if ($null -ne $sco -and $sco.Enabled) { return }
        $script:fMeta = 0
        $anim.Start()
    })
    $tasto.Add_MouseDown({
        if ($null -ne $sco -and $sco.Enabled) { return }
        $anim.Stop()
        $script:fIdx = $script:fGiu      # l'indice segue davvero la figura mostrata
        $tasto.Image = $script:frames[$script:fGiu]
    })
    $tasto.Add_MouseUp({
        if ($null -ne $sco -and $sco.Enabled) { return }
        $script:fIdx = $script:fTop
        $script:fMeta = $script:fTop
        $tasto.Image = $script:frames[$script:fTop]
    })

    # La copertina non sparisce di colpo: resta un attimo sopra al pannello,
    # si allarga e sfuma. Non e' piu' il pannello della schermata: e' una
    # finestrella senza bordi appoggiata sopra, perche' solo una finestra sa
    # essere semitrasparente. Sotto si vede il pannello vero, vivo, non una
    # sua fotografia.
    $script:tra = @()
    $script:tIdx = 0
    $script:ov = $null
    $tratime = New-Object System.Windows.Forms.Timer
    $tratime.Interval = 16
    $tratime.Add_Tick({
        if ($script:tIdx -ge $script:tra.Count) {
            $tratime.Stop()
            if ($null -ne $script:ov) { $script:ov.Close(); $script:ov = $null }
            $form.ActiveControl = $btnTest
            return
        }
        $script:ov.BackgroundImage = $script:tra[$script:tIdx]
        $script:ov.Opacity = [Math]::Max(0, 1 - ($script:tIdx / ($script:tra.Count - 1)))
        $script:tIdx++
    })

    function Chiudi-Splash {
        # prima la finestra prende la misura del pannello: le figure della
        # dissolvenza devono essere grandi quanto lui, se no restano bordi
        # Niente Refresh: finche' non si torna al giro dei messaggi la finestra
        # non si ridipinge, quindi il pannello non fa capolino prima che la
        # copertina gli si rimetta sopra.
        $script:splash.Visible = $false
        Apply-Dev
        $form.PerformLayout()

        $w = $form.ClientSize.Width
        $h = $form.ClientSize.Height
        # le figure: la copertina che si allarga. Lo sbiadire lo fa la finestra
        # con la sua trasparenza, non il disegno.
        $script:tra = @()
        $N = 14
        for ($i = 0; $i -lt $N; $i++) {
            $t = $i / ($N - 1)
            $sc = 1 + 0.30 * $t
            $bmp = New-Object System.Drawing.Bitmap $w, $h
            $g = [System.Drawing.Graphics]::FromImage($bmp)
            $g.Clear([System.Drawing.Color]::FromArgb(10, 12, 30))
            $g.InterpolationMode = "HighQualityBilinear"
            # la copertina riempie sempre tutto, anche quando cresce
            $riempi = [Math]::Max($w / $imgSch.Width, $h / $imgSch.Height) * $sc
            $sw = [int]($imgSch.Width * $riempi); $sh = [int]($imgSch.Height * $riempi)
            $g.DrawImage($imgSch, [int](($w - $sw) / 2), [int](($h - $sh) / 2), $sw, $sh)
            $g.Dispose()
            $script:tra += $bmp
        }

        $ov = New-Object System.Windows.Forms.Form
        $ov.FormBorderStyle = "None"
        $ov.ShowInTaskbar = $false
        $ov.StartPosition = "Manual"
        $ov.Location = $form.PointToScreen((New-Object System.Drawing.Point 0, 0))
        $ov.Size = New-Object System.Drawing.Size $w, $h
        $ov.BackColor = [System.Drawing.Color]::FromArgb(10, 12, 30)
        $ov.BackgroundImage = $script:tra[0]
        $ov.BackgroundImageLayout = "None"
        $ov.Owner = $form
        $script:ov = $ov
        $ov.Show()
        $script:tIdx = 1
        $tratime.Start()
    }

    # Il clic fa partire lo scoppio; il pannello si apre a rimbalzo finito
    $script:bIdx = 0
    $sco = New-Object System.Windows.Forms.Timer
    $sco.Interval = 16
    $sco.Add_Tick({
        if ($script:bIdx -ge $script:burst.Count) {
            $sco.Stop()
            $tasto.Image = $script:frames[$script:fTop]
            $script:fIdx = $script:fTop
            $script:fMeta = $script:fTop
            $tasto.Enabled = $true
            Chiudi-Splash
            return
        }
        $tasto.Image = $script:burst[$script:bIdx]
        $script:bIdx++
    })

    $tasto.Add_Click({
        if (-not $tasto.Enabled) { return }
        Suona $script:sndOk
        $tasto.Enabled = $false
        $anim.Stop()
        $script:bIdx = 0
        $sco.Start()
    })
}

Apply-Language
Apply-Dev
Pulisci-Ini
Log (T "pronto")
if ($null -ne $script:splash) {
    # la finestra prende la misura della copertina finche' la schermata e' li'
    $form.Size = New-Object System.Drawing.Size($W, 945)
}

# Niente da rimettere a posto alla chiusura: il salvataggio di chi gioca non e'
# mai stato toccato, e la cartella del server la si dice a Dolphin solo quando
# lo si avvia da qui.


# ---------------------------------------------------------------- apertura
# La finestra non compare gia' grande: nasce piccola al centro dello schermo e
# si apre in dodici passi da 16 millesimi, svelta e poi morbida. Mentre cresce
# la copertina si allarga con lei (per quel momento e' "stirata", cosi' segue
# la finestra invece di restare inchiodata in alto a sinistra); il pulsante
# resta nascosto finche' non si e' arrivati a misura, se no si vedrebbe fuori
# posto.
$script:apI = 0
$script:apN = 12
$script:apW = 0
$script:apH = 0
$script:apW0 = 0
$script:apH0 = 0

function Centra($w, $h) {
    $sc = [System.Windows.Forms.Screen]::FromControl($form).WorkingArea
    $form.Location = New-Object System.Drawing.Point ([int]($sc.X + ($sc.Width - $w) / 2)), ([int]($sc.Y + ($sc.Height - $h) / 2))
}

$apri = New-Object System.Windows.Forms.Timer
$apri.Interval = 16
$apri.Add_Tick({
    $script:apI++
    $q = $script:apI / $script:apN
    if ($q -ge 1) {
        $apri.Stop()
        $form.Size = New-Object System.Drawing.Size $script:apW, $script:apH
        Centra $script:apW $script:apH
        if ($null -ne $script:splash) {
            $script:splash.BackgroundImageLayout = "None"
            if ($null -ne $tasto) { $tasto.Visible = $true }
            if ($null -ne $lblSenza) { $lblSenza.Visible = $true }
        }
        $form.ActiveControl = $btnTest
        return
    }
    $e = 1 - [Math]::Pow(1 - $q, 3)
    $w = [int]($script:apW0 + ($script:apW - $script:apW0) * $e)
    $h = [int]($script:apH0 + ($script:apH - $script:apH0) * $e)
    $form.Size = New-Object System.Drawing.Size $w, $h
    Centra $w $h
})

# La misura piccola si da' PRIMA di mostrarla: se la si rimpicciolisse dentro
# Add_Shown, per un istante la finestra si vedrebbe gia' grande e sarebbe un
# lampo brutto.
$script:apW = $form.Width
$script:apH = $form.Height
$script:apW0 = [int]($script:apW * 0.30)      # parte da poco meno di un terzo
$script:apH0 = [int]($script:apH * 0.30)
if ($null -ne $script:splash) {
    $script:splash.BackgroundImageLayout = "Stretch"   # la copertina segue la finestra
    if ($null -ne $tasto) { $tasto.Visible = $false }
    if ($null -ne $lblSenza) { $lblSenza.Visible = $false }
}
$form.Size = New-Object System.Drawing.Size $script:apW0, $script:apH0

$form.Add_Shown({
    Centra $script:apW0 $script:apH0
    $script:apI = 0
    $apri.Start()
})

# Appena si apre il pannello si scarica il salvataggio del server nella sua
# cartella, cosi' e' gia' fresco quando si avvia il gioco. Si fa in un processo
# a parte, dopo che la finestra si e' aperta: se l'host non risponde ci vogliono
# alcuni secondi, e il pannello non deve restare bloccato ad aspettare.
$script:scaricoProc = $null
$script:scaricoOut = Join-Path $env:TEMP "smg-scarico-salvataggio.txt"
$scarico = New-Object System.Windows.Forms.Timer
$scarico.Interval = 1200
$scarico.Add_Tick({
    if ($null -eq $script:scaricoProc) {
        $scarico.Stop()
        if (-not $chkAutoSave.Checked) { return }
        $h = $txtHost.Text.Trim()
        if ($h -eq "" -or -not (Test-Path $fetchScript)) { return }
        if (@(Get-Process -Name Dolphin -ErrorAction SilentlyContinue).Count -gt 0) { return }
        New-Item -ItemType Directory -Force -Path $saveMulti | Out-Null
        Remove-Item $script:scaricoOut -ErrorAction SilentlyContinue
        Log (T "logScarico")
        $script:scaricoProc = Start-Process powershell.exe -WindowStyle Hidden -PassThru `
            -RedirectStandardOutput $script:scaricoOut `
            -ArgumentList "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$fetchScript`"",
                          "-Server", $h, "-SaveDir", "`"$saveMulti`"", "-Separata"
        $scarico.Interval = 500
        $scarico.Start()
        return
    }
    if (-not $script:scaricoProc.HasExited) { return }
    $scarico.Stop()
    $esito = ""
    if (Test-Path $script:scaricoOut) { $esito = (Get-Content $script:scaricoOut -Raw).Trim() }
    if ($esito -match '^OK') { Log $esito } else { Log (T "logNoShare") }
    $script:scaricoProc = $null
})
$form.Add_Shown({ $scarico.Start() })

[void]$form.ShowDialog()
