@echo off
rem Apre il pannello di connessione al server.
rem
rem La prima riga toglie il "marchio" che Windows mette ai file scaricati da
rem internet: senza, aprendo il .ps1 a mano esce l'avviso di sicurezza.
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%~dp0' -Recurse -Force -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue" >nul 2>&1
powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0ClientGUI.ps1"
