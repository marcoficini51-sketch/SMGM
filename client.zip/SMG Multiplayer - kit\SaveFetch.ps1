#
# Prende il salvataggio dall'host.
#
# Con -Separata lo scrive in una cartella sua (la NAND che Dolphin usa solo per
# il multigiocatore): il salvataggio vero non viene ne' toccato ne' copiato.
# Senza, si comporta come prima: mette quello dell'host al posto del proprio,
# tenendo da parte una copia di quello che c'era.
#
#   SaveFetch.ps1 -Host 10.0.0.2 [-Port 5030] [-SaveDir <cartella>]
#   SaveFetch.ps1 -Restore              rimette l'ultimo backup
#   SaveFetch.ps1 -Server ... -SaveDir <cartella> -Separata
#                                       scrive in una cartella sua, senza backup
#
# Dolphin deve essere chiuso: sta scrivendo lui in quella cartella.
#

param(
    [string]$Server = "",
    [int]$Port = 5030,
    [string]$SaveDir = "$env:APPDATA\Dolphin Emulator\Wii\title\00010000\524d4745\data",
    [switch]$Restore,
    [switch]$Separata      # cartella tutta sua: niente backup, il salvataggio vero non si tocca
)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.IO.Compression.FileSystem

$backupRoot = Join-Path (Split-Path -Parent $SaveDir) "backup-salvataggi"
# Finche' questo file c'e', nella cartella dei salvataggi c'e' quello dell'host:
# guai a farne un backup, si perderebbe il proprio.
$segnale = Join-Path $backupRoot "salvataggio-host-attivo.txt"

function Backup-Mio {
    if (Test-Path $segnale) { return $null }      # c'e' gia' quello dell'host
    if (-not (Test-Path $SaveDir)) { return $null }
    if (-not (Test-Path $backupRoot)) { New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null }
    $dest = Join-Path $backupRoot ("mio-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
    Copy-Item -Path $SaveDir -Destination $dest -Recurse -Force
    return $dest
}

if ($Restore) {
    if (-not (Test-Path $backupRoot)) { Write-Output "NO nessun backup da rimettere"; exit 1 }
    $ultimo = Get-ChildItem $backupRoot -Directory | Sort-Object Name -Descending | Select-Object -First 1
    if ($null -eq $ultimo) { Write-Output "NO nessun backup da rimettere"; exit 1 }
    if (Test-Path $SaveDir) { Remove-Item (Join-Path $SaveDir "*") -Recurse -Force }
    else { New-Item -ItemType Directory -Force -Path $SaveDir | Out-Null }
    Copy-Item -Path (Join-Path $ultimo.FullName "*") -Destination $SaveDir -Recurse -Force
    Remove-Item $segnale -Force -ErrorAction SilentlyContinue
    Write-Output ("OK rimesso il backup " + $ultimo.Name)
    exit 0
}

if ($Server -eq "") { Write-Output "NO manca l'indirizzo dell'host"; exit 2 }

$client = New-Object System.Net.Sockets.TcpClient
try {
    $conn = $client.BeginConnect($Server, $Port, $null, $null)
    if (-not $conn.AsyncWaitHandle.WaitOne(4000)) { throw "nessuna risposta" }
    $client.EndConnect($conn)
} catch {
    Write-Output "NO l'host non condivide il salvataggio (porta $Port chiusa o pannello spento)"
    exit 1
}

try {
    $flusso = $client.GetStream()
    $flusso.ReadTimeout = 20000
    $testa = New-Object byte[] 4
    $letti = 0
    while ($letti -lt 4) {
        $n = $flusso.Read($testa, $letti, 4 - $letti)
        if ($n -le 0) { throw "connessione chiusa subito" }
        $letti += $n
    }
    if ([System.BitConverter]::IsLittleEndian) { [Array]::Reverse($testa) }
    $quanti = [System.BitConverter]::ToInt32($testa, 0)
    if ($quanti -le 0 -or $quanti -gt 50MB) { throw "dimensione strana: $quanti" }

    $dati = New-Object byte[] $quanti
    $letti = 0
    while ($letti -lt $quanti) {
        $n = $flusso.Read($dati, $letti, $quanti - $letti)
        if ($n -le 0) { throw "connessione interrotta a meta'" }
        $letti += $n
    }
} catch {
    Write-Output "NO errore scaricando il salvataggio: $_"
    exit 1
} finally {
    $client.Close()
}

$zip = Join-Path $env:TEMP "smg-save-host.zip"
[System.IO.File]::WriteAllBytes($zip, $dati)

$copia = $null
if (-not $Separata) { $copia = Backup-Mio }
if (-not (Test-Path $SaveDir)) { New-Item -ItemType Directory -Force -Path $SaveDir | Out-Null }
else { Remove-Item (Join-Path $SaveDir "*") -Recurse -Force }
[System.IO.Compression.ZipFile]::ExtractToDirectory($zip, $SaveDir)
Remove-Item $zip -Force -ErrorAction SilentlyContinue

if (-not $Separata) {
    if (-not (Test-Path $backupRoot)) { New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null }
    Set-Content -Path $segnale -Value (Get-Date -Format "yyyy-MM-dd HH:mm:ss") -Encoding ascii
}

if ($Separata) {
    Write-Output "OK salvataggio del server aggiornato (il tuo non e' stato toccato)"
} elseif ($null -ne $copia) {
    Write-Output ("OK salvataggio dell'host messo; il tuo e' in " + $copia)
} else {
    Write-Output "OK salvataggio dell'host messo (il tuo era gia' da parte)"
}
