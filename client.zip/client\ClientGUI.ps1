#
# Pannello di collegamento al server multiplayer di Super Mario Galaxy.
#
# Avvialo con "Connetti al server.bat".
#

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$here = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }

$riivRoot = Join-Path $env:APPDATA "Dolphin Emulator\Load\Riivolution"
$riivSub  = Join-Path $riivRoot "riivolution"
$connTest = Join-Path $here "ConnTest.exe"
# riivo_USA.xml rimanda a TitleLogo.arc: se manca, la patch non parte
$modFiles = @("riivo_USA.xml", "CustomCode_USA.bin", "TitleLogo.arc")

# ---------------------------------------------------------------- palette
$cBg     = [System.Drawing.Color]::FromArgb(28, 28, 40)
$cPanel  = [System.Drawing.Color]::FromArgb(38, 38, 54)
$cText   = [System.Drawing.Color]::FromArgb(232, 232, 244)
$cMuted  = [System.Drawing.Color]::FromArgb(138, 138, 164)
$cOk     = [System.Drawing.Color]::FromArgb(94, 200, 140)
$cBad    = [System.Drawing.Color]::FromArgb(212, 108, 108)
$cAccent = [System.Drawing.Color]::FromArgb(228, 168, 72)

$fTitle  = New-Object System.Drawing.Font("Segoe UI Semibold", 15)
$fLabel  = New-Object System.Drawing.Font("Segoe UI", 8.5)
$fBody   = New-Object System.Drawing.Font("Segoe UI", 9.5)
$fBold   = New-Object System.Drawing.Font("Segoe UI Semibold", 10)
$fMono   = New-Object System.Drawing.Font("Consolas", 11)
$fSmall  = New-Object System.Drawing.Font("Consolas", 8.5)

$form = New-Object System.Windows.Forms.Form
$form.Text = "Super Mario Galaxy - Connessione"
$form.Size = New-Object System.Drawing.Size(600, 680)
$form.StartPosition = "CenterScreen"
$form.BackColor = $cBg
$form.ForeColor = $cText
$form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox = $false

function New-Lbl($text, $x, $y, $w, $h, $font, $color, $parent) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $text
    $l.Location = New-Object System.Drawing.Point($x, $y)
    $l.Size = New-Object System.Drawing.Size($w, $h)
    $l.Font = $font; $l.ForeColor = $color
    $l.BackColor = [System.Drawing.Color]::Transparent
    if ($parent) { $parent.Controls.Add($l) } else { $form.Controls.Add($l) }
    return $l
}

function New-Btn($text, $x, $y, $w, $h, $parent) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $text
    $b.Location = New-Object System.Drawing.Point($x, $y)
    $b.Size = New-Object System.Drawing.Size($w, $h)
    $b.FlatStyle = "Flat"
    $b.FlatAppearance.BorderSize = 1
    $b.FlatAppearance.BorderColor = $cMuted
    $b.BackColor = $cPanel; $b.ForeColor = $cText
    $b.Font = $fBody
    if ($parent) { $parent.Controls.Add($b) } else { $form.Controls.Add($b) }
    return $b
}

New-Lbl "Connessione al server" 22 16 460 26 $fTitle $cText $null | Out-Null
New-Lbl "Super Mario Galaxy multiplayer" 24 42 460 18 $fLabel $cMuted $null | Out-Null

# ---------------------------------------------------------------- server
New-Lbl "INDIRIZZO DEL SERVER" 22 78 300 16 $fLabel $cMuted $null | Out-Null

$pServer = New-Object System.Windows.Forms.Panel
$pServer.Location = New-Object System.Drawing.Point(22, 98)
$pServer.Size = New-Object System.Drawing.Size(546, 118)
$pServer.BackColor = $cPanel
$form.Controls.Add($pServer)

$txtHost = New-Object System.Windows.Forms.TextBox
$txtHost.Location = New-Object System.Drawing.Point(14, 16)
$txtHost.Size = New-Object System.Drawing.Size(250, 30)
$txtHost.Font = $fMono
$txtHost.BackColor = $cBg; $txtHost.ForeColor = $cAccent
$txtHost.BorderStyle = "FixedSingle"
$pServer.Controls.Add($txtHost)

New-Lbl ":" 270 20 10 24 $fMono $cMuted $pServer | Out-Null

$txtPort = New-Object System.Windows.Forms.TextBox
$txtPort.Text = "5029"
$txtPort.Location = New-Object System.Drawing.Point(284, 16)
$txtPort.Size = New-Object System.Drawing.Size(78, 30)
$txtPort.Font = $fMono
$txtPort.BackColor = $cBg; $txtPort.ForeColor = $cAccent
$txtPort.BorderStyle = "FixedSingle"
$pServer.Controls.Add($txtPort)

$btnPaste = New-Btn "Incolla" 374 15 74 30 $pServer
$btnTest  = New-Btn "Prova" 458 15 74 30 $pServer
$btnTest.BackColor = $cOk
$btnTest.ForeColor = [System.Drawing.Color]::FromArgb(20, 32, 24)
$btnTest.Font = $fBold
$btnTest.FlatAppearance.BorderSize = 0

$lblTest = New-Lbl "Premi Prova per verificare se il server risponde." 16 58 516 22 $fBody $cMuted $pServer
$lblTestHint = New-Lbl "" 16 80 516 30 $fLabel $cMuted $pServer

# ---------------------------------------------------------------- stato mod
New-Lbl "INSTALLAZIONE DEL MOD" 22 232 300 16 $fLabel $cMuted $null | Out-Null

$pMod = New-Object System.Windows.Forms.Panel
$pMod.Location = New-Object System.Drawing.Point(22, 252)
$pMod.Size = New-Object System.Drawing.Size(546, 150)
$pMod.BackColor = $cPanel
$form.Controls.Add($pMod)

$lblDolphin = New-Lbl "" 16 14 516 20 $fBody $cMuted $pMod
$lblFiles1  = New-Lbl "" 16 38 516 20 $fBody $cMuted $pMod
$lblFiles2  = New-Lbl "" 16 62 516 20 $fBody $cMuted $pMod
$lblCurrent = New-Lbl "" 16 86 516 20 $fBody $cMuted $pMod

$btnInstall = New-Btn "Installa / aggiorna" 16 112 180 30 $pMod
$btnInstall.BackColor = $cAccent
$btnInstall.ForeColor = [System.Drawing.Color]::FromArgb(38, 28, 8)
$btnInstall.Font = $fBold
$btnInstall.FlatAppearance.BorderSize = 0

$btnFolder = New-Btn "Apri cartella" 206 112 140 30 $pMod
$btnDolphin = New-Btn "Avvia Dolphin" 356 112 176 30 $pMod

# ---------------------------------------------------------------- note
New-Lbl "REGISTRO" 22 418 300 16 $fLabel $cMuted $null | Out-Null

$txtLog = New-Object System.Windows.Forms.TextBox
$txtLog.Location = New-Object System.Drawing.Point(22, 438)
$txtLog.Size = New-Object System.Drawing.Size(546, 158)
$txtLog.Multiline = $true
$txtLog.ScrollBars = "Vertical"
$txtLog.ReadOnly = $true
$txtLog.Font = $fSmall
$txtLog.BackColor = [System.Drawing.Color]::FromArgb(20, 20, 30)
$txtLog.ForeColor = [System.Drawing.Color]::FromArgb(150, 210, 180)
$txtLog.BorderStyle = "FixedSingle"
$form.Controls.Add($txtLog)

New-Lbl "Dopo aver cambiato l'indirizzo il gioco va riavviato: il mod lo legge una volta sola, all'avvio." 22 604 546 32 $fLabel $cMuted $null | Out-Null

function Log($msg) {
    $txtLog.AppendText("$(Get-Date -Format 'HH:mm:ss')  $msg`r`n")
    $txtLog.SelectionStart = $txtLog.TextLength
    $txtLog.ScrollToCaret()
}

# ---------------------------------------------------------------- Dolphin
function Find-Dolphin {
    $candidates = @(
        (Join-Path $env:USERPROFILE "Desktop\Dolphin-x64\Dolphin.exe"),
        (Join-Path $env:ProgramFiles "Dolphin\Dolphin.exe"),
        (Join-Path ${env:ProgramFiles(x86)} "Dolphin\Dolphin.exe")
    )
    foreach ($c in $candidates) { if ($c -and (Test-Path $c)) { return $c } }
    $lnk = Join-Path $env:USERPROFILE "Desktop\Dolphin - collegamento.lnk"
    if (Test-Path $lnk) {
        try {
            $sh = New-Object -ComObject WScript.Shell
            $t = $sh.CreateShortcut($lnk).TargetPath
            if ($t -and (Test-Path $t)) { return $t }
        } catch { }
    }
    return $null
}
$script:dolphinPath = Find-Dolphin

# ---------------------------------------------------------------- stato
function Refresh-Status {
    if ($script:dolphinPath) {
        $lblDolphin.Text = "Dolphin trovato"
        $lblDolphin.ForeColor = $cOk
        $btnDolphin.Enabled = $true
    } else {
        $lblDolphin.Text = "Dolphin non trovato - avvialo a mano"
        $lblDolphin.ForeColor = $cBad
        $btnDolphin.Enabled = $false
    }

    $miss1 = @(); $miss2 = @()
    foreach ($f in $modFiles) {
        if (-not (Test-Path (Join-Path $riivRoot $f))) { $miss1 += $f }
        if (-not (Test-Path (Join-Path $riivSub  $f))) { $miss2 += $f }
    }

    if ($miss1.Count -eq 0) {
        $lblFiles1.Text = "File del mod in Load\Riivolution"; $lblFiles1.ForeColor = $cOk
    } else {
        $lblFiles1.Text = "Mancano in Load\Riivolution: $($miss1 -join ', ')"; $lblFiles1.ForeColor = $cBad
    }

    if ($miss2.Count -eq 0) {
        $lblFiles2.Text = "File del mod in Load\Riivolution\riivolution"; $lblFiles2.ForeColor = $cOk
    } else {
        $lblFiles2.Text = "Mancano in ...\riivolution: $($miss2 -join ', ')"; $lblFiles2.ForeColor = $cBad
    }

    $cur = Join-Path $riivRoot "serverIP.txt"
    if (Test-Path $cur) {
        $val = (Get-Content $cur -Raw).Trim()
        $lblCurrent.Text = "Indirizzo configurato adesso: $val"
        $lblCurrent.ForeColor = $cText
    } else {
        $lblCurrent.Text = "serverIP.txt non ancora creato"
        $lblCurrent.ForeColor = $cBad
    }
}

# ---------------------------------------------------------------- azioni
$btnPaste.Add_Click({
    $clip = ""
    try { $clip = (Get-Clipboard -Raw) } catch { }
    if ([string]::IsNullOrWhiteSpace($clip)) { Log "Appunti vuoti."; return }
    $clip = $clip.Trim()
    if ($clip -match '^\s*(\d{1,3}(?:\.\d{1,3}){3})\s*(?::\s*(\d{1,5}))?\s*$') {
        $txtHost.Text = $matches[1]
        if ($matches[2]) { $txtPort.Text = $matches[2] }
        Log "Incollato: $($txtHost.Text):$($txtPort.Text)"
    } else {
        Log "Negli appunti non c'e' un indirizzo valido (serve tipo 26.1.2.3:5029)."
    }
})

$btnTest.Add_Click({
    $h = $txtHost.Text.Trim()
    $p = $txtPort.Text.Trim()
    if ([string]::IsNullOrWhiteSpace($h)) { Log "Inserisci prima un indirizzo."; return }
    if (-not (Test-Path $connTest)) {
        Log "ConnTest.exe non trovato in questa cartella."
        $lblTest.Text = "Impossibile provare: manca ConnTest.exe"
        $lblTest.ForeColor = $cBad
        return
    }
    $lblTest.Text = "Provo..."; $lblTest.ForeColor = $cMuted
    $lblTestHint.Text = ""
    $form.Refresh()

    $out = & $connTest $h $p 2>&1 | Out-String
    $out = $out.Trim()
    Log "ConnTest: $out"

    if ($out -match '^OK id=(\d+) rtt=(\d+)') {
        $lblTest.Text = "Server raggiungibile - latenza $($matches[2]) ms"
        $lblTest.ForeColor = $cOk
        $lblTestHint.Text = "Il server ti ha assegnato il posto numero $($matches[1]). Puoi avviare il gioco."
        $lblTestHint.ForeColor = $cMuted
    } else {
        $lblTest.Text = "Server NON raggiungibile"
        $lblTest.ForeColor = $cBad
        if ($out -match 'nessuna risposta') {
            $lblTestHint.Text = "Il server e' spento, l'indirizzo e' sbagliato, oppure un firewall blocca la porta UDP $p."
        } elseif ($out -match 'non valido') {
            $lblTestHint.Text = "L'indirizzo non e' un IPv4 valido. Serve un numero, il mod non risolve i nomi a dominio."
        } else {
            $lblTestHint.Text = $out
        }
        $lblTestHint.ForeColor = $cBad
    }
})

$btnInstall.Add_Click({
    $h = $txtHost.Text.Trim()
    $p = $txtPort.Text.Trim()
    if ([string]::IsNullOrWhiteSpace($h)) { Log "Inserisci prima un indirizzo."; return }

    try {
        New-Item -ItemType Directory -Force -Path $riivRoot | Out-Null
        New-Item -ItemType Directory -Force -Path $riivSub  | Out-Null

        $copied = 0
        foreach ($f in $modFiles) {
            $src = Join-Path $here $f
            if (Test-Path $src) {
                Copy-Item $src -Destination (Join-Path $riivRoot $f) -Force
                Copy-Item $src -Destination (Join-Path $riivSub  $f) -Force
                $copied++
            } else {
                Log "Attenzione: $f non e' in questa cartella, lo salto."
            }
        }

        foreach ($dir in @($riivRoot, $riivSub)) {
            Set-Content -Path (Join-Path $dir "serverIP.txt") -Value "${h}:${p}" -NoNewline -Encoding ascii
            Set-Content -Path (Join-Path $dir "debugIP.txt")  -Value "${h}:5001" -NoNewline -Encoding ascii
        }

        Log "Installati $copied file, indirizzo impostato su ${h}:${p}"
        Log "Ricorda: se il gioco e' aperto, riavvialo."
        Refresh-Status
    } catch {
        Log "Errore durante l'installazione: $_"
    }
})

$btnFolder.Add_Click({
    if (Test-Path $riivRoot) { Start-Process explorer.exe $riivRoot }
    else { Log "La cartella non esiste ancora: premi prima Installa." }
})

$btnDolphin.Add_Click({
    if ($script:dolphinPath) {
        Start-Process $script:dolphinPath
        Log "Dolphin avviato. Usa 'Start with Riivolution Patches' e carica riivo_USA.xml."
    }
})

# ---------------------------------------------------------------- avvio
$cur = Join-Path $riivRoot "serverIP.txt"
if (Test-Path $cur) {
    $val = (Get-Content $cur -Raw).Trim()
    if ($val -match '^(\d{1,3}(?:\.\d{1,3}){3})(?::(\d{1,5}))?') {
        $txtHost.Text = $matches[1]
        if ($matches[2]) { $txtPort.Text = $matches[2] }
    }
}

Refresh-Status
Log "Pronto. Inserisci l'indirizzo del server e premi Prova."

[void]$form.ShowDialog()
