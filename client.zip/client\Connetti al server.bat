@echo off
rem Apre il pannello di connessione al server.
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0ClientGUI.ps1"
