# SMGServer — deploy su VPS

Server relay per il multiplayer online di Super Mario Galaxy
([SMGMultiplayerServer](https://github.com/Headpenguin/SMGMultiplayerServer) di
Headpenguin), con correzioni di sicurezza e stabilità e un servizio systemd
irrigidito.

---

## Installazione

Copia la cartella sulla VPS e lancia:

```bash
scp -r smgserver-vps/ utente@tua-vps:~/
ssh utente@tua-vps
cd ~/smgserver-vps
sudo ./deploy.sh --open-firewall
```

Lo script installa il compilatore se manca, compila, installa il binario in
`/usr/local/bin/SMGServer`, registra il servizio, lo avvia e ti stampa la riga
esatta da mettere nel `serverIP.txt` del client.

Per disinstallare: `sudo ./deploy.sh --uninstall`

### Requisiti

- **g++ 12 o superiore.** Il codice usa `std::is_layout_compatible` e
  `std::bit_cast`. Debian 12, Ubuntu 24.04, Fedora e Arch vanno bene di serie.
  Su Debian 11, Ubuntu 20.04 e 22.04 serve installare `g++-12` a mano.
- systemd.
- Una porta UDP raggiungibile (default 5029) — aperta sia nel firewall della
  macchina sia nel pannello del provider.

---

## Cosa è stato corretto rispetto all'originale

Tutte le modifiche sono in `smgserver-fixes.patch`, applicabile al repo
upstream con `git apply`.

| Gravità | Difetto | Dove |
|---|---|---|
| Critico | `playerId` preso dal pacchetto e usato come indice senza controllo di limite: un singolo UDP da 60 byte con `playerId = 200` scriveva fuori dall'array e uccideva il server | `source/main.cpp` |
| Critico | Il controllo anti-impersonificazione registrava l'anomalia ma non fermava la scrittura, perché mancava il `break` | `source/main.cpp` |
| Alto | `memset` con l'indirizzo di un membro e la dimensione dell'intera struttura: corruzione della heap **a ogni avvio**, senza bisogno di traffico | `source/transmission.cpp` |
| Medio | `errno` (positivo) assegnato a una variabile confrontata con `-EAGAIN`: il ritentativo non scattava mai e gli errori del socket passavano per dati validi | `source/transmission.cpp` |
| Minore | `isCandidateMode` non inizializzato: il primo pacchetto veniva interpretato leggendo memoria casuale | `include/packetFactory.hpp` |

I due difetti critici sono stati verificati con AddressSanitizer confrontando
binario originale e corretto sullo stesso identico pacchetto: l'originale muore
con `SEGV` in scrittura dentro `Player::updateInfo`, il corretto registra
`Rejected packet: player id 200 is out of range (max 7)` e prosegue.

### Aggiunte per l'uso come servizio

- **Porta e indirizzo da riga di comando**: `SMGServer [porta] [indirizzo]`.
  Prima erano fissati a tempo di compilazione.
- **Niente uscita immediata senza terminale.** L'originale usa `poll()` sullo
  stdin per il «premi Invio per chiudere»; senza un tty lo stdin è subito a EOF,
  che `poll()` riporta come leggibile, quindi il server usciva **dopo un solo
  pacchetto**. Sotto systemd sarebbe stato inutilizzabile. Ora la cosa è
  attiva solo con un terminale vero (`isatty`).
- **Log a riga**: senza `setvbuf` lo stdout verso il journal resta bufferizzato
  e non si vede niente per parecchio tempo.
- **Riciclo degli slot**: uno slot silenzioso da oltre 60 secondi può essere
  riusato, ma solo quando non c'è più posto. Chi ha il gioco in pausa non
  perde la sedia, perché il mod non rifà mai l'handshake.
- **Mondo condiviso**: il server riconosce e rilancia i tag `COIN_COLLECTED`
  e `ACTOR_KILLED`. Non li interpreta, ma deve saperli leggere, se no il
  filtro sui tag li scarterebbe come invalidi. La prova automatica è
  `src/source/tests/relaytest.cpp`: due client, uno annuncia, l'altro deve
  ricevere con i campi intatti.

  Attenzione: la parte *client* di monete e nemici è scritta ma non è
  compilata dentro il mod distribuito, perché manca CodeWarrior con licenza
  Gekko. Vedi `sorgenti/LEGGIMI-SORGENTI.md` nel pacchetto completo.

---

## Configurazione

`/etc/smgserver.conf`:

```sh
SMG_PORT=5029
SMG_BIND=0.0.0.0
SMG_FRIENDLY_FIRE=off
```

Dopo una modifica: `sudo systemctl restart smgserver`

### Friendly fire

Acceso, lo schianto a terra addosso a un altro giocatore gli toglie 1 di
vita e la piroetta lo fa cadere senza danno; spento, nessuno fa male agli
altri. Serve il `CustomCode_USA.bin` patchato da entrambe le parti. Il
server, col friendly fire spento, cancella i flag d'attacco dai pacchetti
posizione prima di inoltrarli.

`SMG_FRIENDLY_FIRE` è il valore all'avvio. Per cambiarlo **al volo**, senza
riavviare (un riavvio obbliga tutti i giocatori a riavviare il gioco):

```bash
echo 1 | sudo tee /etc/smgserver-ff
```

Con `0` si rispegne. Il server rilegge il file ogni secondo e lo scrive nel
journal.

Se aggiorni da una versione precedente, `deploy.sh` lascia il tuo
`smgserver.conf` com'è: senza la riga nuova il servizio parte comunque, col
friendly fire spento.

## Lato client

Nella cartella Riivolution di Dolphin (o sulla SD del Wii), in `serverIP.txt`:

```
1.2.3.4:5029
```

Solo indirizzo IP numerico e porta: il parser del mod non risolve nomi a
dominio, legge al massimo 40 byte e si aspetta quattro ottetti separati da
punti. Se ometti `:porta` usa 5029.

## Comandi utili

```bash
journalctl -u smgserver -f          # log in tempo reale
systemctl status smgserver          # stato
systemctl restart smgserver         # riavvio
ss -lunp | grep 5029                # conferma che e' in ascolto
```

---

## Note

**Il server ospita al massimo 8 giocatori**, valore fissato a tempo di
compilazione lato mod (`MAX_PLAYER_COUNT`) e lato server (`maxNumPlayers`).
Cambiarlo su un lato solo rompe il protocollo.

**Non c'è autenticazione.** Chiunque conosca IP e porta può entrare e occupare
uno slot. Il servizio gira sotto `DynamicUser` con capability azzerate,
filesystem in sola lettura e syscall filtrate, quindi il danno resta confinato
al servizio stesso — ma non aspettarti privacy o controllo degli accessi. Se ti
serve, limita l'accesso a IP noti nel firewall.

**Il mod client funziona solo con la copia USA del gioco** (`RMGE01`). Le patch
Riivolution sono indirizzi di memoria assoluti calcolati sull'eseguibile
americano: su una copia PAL (`RMGP01`) non ottieni il multiplayer, ottieni un
crash.
