#!/usr/bin/env bash
#
# Installa il server multiplayer di Super Mario Galaxy come servizio systemd.
#
#   sudo ./deploy.sh                    installa e avvia
#   sudo ./deploy.sh --open-firewall    apre anche la porta UDP
#   sudo ./deploy.sh --uninstall        rimuove tutto
#
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN=/usr/local/bin/SMGServer
CONF=/etc/smgserver.conf
UNIT=/etc/systemd/system/smgserver.service
OPEN_FW=0

for arg in "$@"; do
  case "$arg" in
    --open-firewall) OPEN_FW=1 ;;
    --uninstall)     ACTION=uninstall ;;
    -h|--help)       sed -n '2,8p' "$0" | sed 's/^# \?//'; exit 0 ;;
    *) echo "Argomento sconosciuto: $arg" >&2; exit 2 ;;
  esac
done

say()  { printf '\n\033[1m==> %s\033[0m\n' "$*"; }
warn() { printf '\033[33m !  %s\033[0m\n' "$*"; }
die()  { printf '\033[31m !! %s\033[0m\n' "$*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "Serve root. Rilancia con: sudo $0 $*"
command -v systemctl >/dev/null || die "systemd non presente: questo script non fa per te."

# ---------------------------------------------------------------- uninstall
if [ "${ACTION:-}" = uninstall ]; then
  say "Rimozione"
  systemctl disable --now smgserver.service 2>/dev/null || true
  rm -f "$UNIT" "$BIN"
  systemctl daemon-reload
  echo "Rimossi il servizio e il binario. Lasciato $CONF (cancellalo a mano se vuoi)."
  exit 0
fi

# ---------------------------------------------------------- dipendenze build
say "Dipendenze di compilazione"

install_pkgs() {
  if   command -v apt-get >/dev/null; then apt-get update -qq && apt-get install -y -qq "$@"
  elif command -v dnf     >/dev/null; then dnf install -y -q "$@"
  elif command -v yum     >/dev/null; then yum install -y -q "$@"
  elif command -v zypper  >/dev/null; then zypper -q install -y "$@"
  elif command -v pacman  >/dev/null; then pacman -Sy --noconfirm --needed "$@"
  elif command -v apk     >/dev/null; then apk add --quiet "$@"
  else return 1; fi
}

gcc_major() { "$1" -dumpversion 2>/dev/null | cut -d. -f1; }

CXX=""
for cand in g++-14 g++-13 g++-12 g++; do
  if command -v "$cand" >/dev/null && [ "$(gcc_major "$cand")" -ge 12 ] 2>/dev/null; then
    CXX="$cand"; break
  fi
done

if [ -z "$CXX" ]; then
  echo "Nessun g++ >= 12 trovato, provo a installarlo..."
  if   command -v apt-get >/dev/null; then install_pkgs g++ || true; install_pkgs g++-12 || true
  elif command -v dnf >/dev/null || command -v yum >/dev/null; then install_pkgs gcc-c++ || true
  elif command -v pacman >/dev/null; then install_pkgs gcc || true
  elif command -v apk >/dev/null; then install_pkgs g++ musl-dev || true
  elif command -v zypper >/dev/null; then install_pkgs gcc-c++ || true
  fi
  for cand in g++-14 g++-13 g++-12 g++; do
    if command -v "$cand" >/dev/null && [ "$(gcc_major "$cand")" -ge 12 ] 2>/dev/null; then
      CXX="$cand"; break
    fi
  done
fi

[ -n "$CXX" ] || die "Serve g++ 12 o superiore: il codice usa std::is_layout_compatible e std::bit_cast.
   Su Debian 11 / Ubuntu 20.04 e 22.04 installa g++-12 e rilancia."

echo "Compilatore: $CXX ($($CXX -dumpversion))"

# ------------------------------------------------------------------- build
say "Compilazione"
SRC="$HERE/src"
[ -d "$SRC/source" ] || die "Sorgenti non trovati in $SRC"

TMPBIN="$(mktemp -d)/SMGServer"
"$CXX" -I "$SRC/include" -std=c++20 -O2 -Wall \
  -D_FORTIFY_SOURCE=2 -fstack-protector-strong -fPIE -pie \
  -Wl,-z,relro,-z,now \
  "$SRC/source/packets.cpp" \
  "$SRC/source/packetFactory.cpp" \
  "$SRC/source/transmission.cpp" \
  "$SRC/source/protocol.cpp" \
  "$SRC/source/main.cpp" \
  -o "$TMPBIN"
echo "Binario prodotto: $(stat -c%s "$TMPBIN") byte"

# --------------------------------------------------------------- installazione
say "Installazione"
systemctl stop smgserver.service 2>/dev/null || true
install -m 0755 -o root -g root "$TMPBIN" "$BIN"
echo "  $BIN"

if [ -f "$CONF" ]; then
  echo "  $CONF (gia' presente, lasciato com'e')"
else
  install -m 0644 -o root -g root "$HERE/smgserver.conf" "$CONF"
  echo "  $CONF"
fi

install -m 0644 -o root -g root "$HERE/smgserver.service" "$UNIT"
echo "  $UNIT"

systemctl daemon-reload
systemctl enable --now smgserver.service

sleep 1
if systemctl is-active --quiet smgserver.service; then
  say "Servizio attivo"
  systemctl --no-pager --lines=6 status smgserver.service || true
else
  warn "Il servizio non risulta attivo. Log:"
  journalctl -u smgserver.service --no-pager --lines=30 || true
  die "Avvio fallito."
fi

# ------------------------------------------------------------------ firewall
# shellcheck disable=SC1090
PORT="$(. "$CONF"; echo "${SMG_PORT:-5029}")"

say "Firewall"
if [ "$OPEN_FW" -eq 1 ]; then
  if   command -v ufw >/dev/null;        then ufw allow "$PORT"/udp && echo "aperta con ufw"
  elif command -v firewall-cmd >/dev/null; then firewall-cmd --permanent --add-port="$PORT"/udp && firewall-cmd --reload && echo "aperta con firewalld"
  else warn "Ne' ufw ne' firewalld: apri la porta $PORT/udp a mano (e nel pannello del provider)."
  fi
else
  echo "Non ho toccato il firewall. Per aprire la porta:"
  command -v ufw >/dev/null          && echo "    ufw allow $PORT/udp"
  command -v firewall-cmd >/dev/null && echo "    firewall-cmd --permanent --add-port=$PORT/udp && firewall-cmd --reload"
  echo "  Ricorda anche il security group / firewall del provider (Hetzner, OVH, AWS...)."
fi

IP="$(curl -4 -s --max-time 5 ifconfig.me 2>/dev/null || true)"
say "Fatto"
echo "Nel file serverIP.txt della cartella Riivolution scrivi:"
echo
echo "    ${IP:-<IP-della-VPS>}:$PORT"
echo
echo "Log in tempo reale:  journalctl -u smgserver -f"
echo "Riavvio:             systemctl restart smgserver"
