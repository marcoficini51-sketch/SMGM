#ifndef PACKETFACTORY_HPP
#define PACKETFACTORY_HPP

#include "packets.hpp"
#include "packets/connect.hpp"
#include "packets/ack.hpp"
#include "packets/serverInitialResponse.hpp"
#include "packets/playerPosition.hpp"
#include "packets/timeSync.hpp"
#include "packets/starPiece.hpp"
#include "packets/coin.hpp"
#include "packets/actorKill.hpp"

namespace Packets {

class PacketFactory {
    bool isCandidateMode = false;
public:

    struct PacketUnion {
        Tag tag;
        union {
            Connect connect;
            Ack ack;
            ServerInitialResponse sip;
            PlayerPosition playerPos;
            TimeQuery timeQuery;
            TimeResponse timeResponse;
            StarPiece starPiece;
            CoinCollected coinCollected;
            ActorKilled actorKilled;
        };
        PacketUnion() {}
    };

    NetReturn constructPacket(Tag tag, PacketUnion *pu, const void *buffer, uint32_t len) const;
    inline void setCandidate() {isCandidateMode = true;}
    inline void resetCandidate() {isCandidateMode = false;}
};

}

#endif
