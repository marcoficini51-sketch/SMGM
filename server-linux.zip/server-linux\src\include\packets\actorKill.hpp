#ifndef PACKETS_ACTORKILL_HPP
#define PACKETS_ACTORKILL_HPP

#include "packets.hpp"

namespace Packets {

// Come per le monete: il server lo rilancia soltanto, ma deve saperlo leggere.
class _ActorKilled {
public:
    uint8_t playerId;
    uint16_t actorIndex;
    uint32_t nameHash;

    inline _ActorKilled() : playerId(0), actorIndex(0), nameHash(0) {}

    NetReturn netWriteToBuffer(void *buffer, uint32_t len) const;
    static NetReturn netReadFromBuffer(Packet<_ActorKilled> *out, const void *buffer, uint32_t len);

    uint32_t getSize() const;

    static constexpr Tag tag = Tag::ACTOR_KILLED;
};

typedef Packet<_ActorKilled> ActorKilled;

}

#endif
