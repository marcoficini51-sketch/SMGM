#ifndef PACKETS_COIN_HPP
#define PACKETS_COIN_HPP

#include "packets.hpp"

namespace Packets {

// Il server non interpreta questo pacchetto: lo rilancia e basta. Deve pero'
// saperlo leggere, se no il filtro sui tag lo scarterebbe come invalido.
class _CoinCollected {
public:
    uint8_t playerId;
    uint16_t coinIndex;

    inline _CoinCollected() : playerId(0), coinIndex(0) {}

    NetReturn netWriteToBuffer(void *buffer, uint32_t len) const;
    static NetReturn netReadFromBuffer(Packet<_CoinCollected> *out, const void *buffer, uint32_t len);

    uint32_t getSize() const;

    static constexpr Tag tag = Tag::COIN_COLLECTED;
};

typedef Packet<_CoinCollected> CoinCollected;

}

#endif
