#ifndef PLATFORM_NET_HPP
#define PLATFORM_NET_HPP

//
// Strato di compatibilita' fra i socket POSIX e Winsock.
//
// Il server nasce POSIX. Per farlo girare nativo su Windows servono poche
// cose: inizializzare Winsock, chiudere i socket con closesocket, leggere
// gli errori con WSAGetLastError invece che da errno, e rinunciare a poll()
// sullo stdin (su Windows WSAPoll funziona solo sui socket).
//
// Tutto il resto del codice resta invariato.
//

#include <cstddef>
#include <cstdlib>

#ifdef _WIN32

#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0601   // Windows 7: serve per inet_pton
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#include <winsock2.h>
#include <ws2tcpip.h>
#include <sys/types.h>
#include <malloc.h>
#include <io.h>
#include <conio.h>
#include <cstdio>

namespace platform {

inline bool netInit() {
    WSADATA data;
    return WSAStartup(MAKEWORD(2, 2), &data) == 0;
}

inline void netShutdown() { WSACleanup(); }

inline int netErrno() { return WSAGetLastError(); }

inline bool wouldBlock(int e) { return e == WSAEWOULDBLOCK; }

inline void closeSocket(int s) { closesocket(static_cast<SOCKET>(s)); }

// Serve che ENTRAMBI siano un terminale. Con la finestra nascosta e lo
// stdout su file, _isatty(stdin) puo' rispondere di si' pur non essendoci
// nessuna console: _kbhit() restituisce allora valori arbitrari e il server
// si chiude da solo su un tasto che nessuno ha premuto.
inline bool stdinIsTerminal() {
    return _isatty(_fileno(stdin)) != 0 && _isatty(_fileno(stdout)) != 0;
}

// Su Windows poll() non accetta handle di console, quindi si guarda la
// tastiera direttamente.
inline bool stdinHasInput() { return _kbhit() != 0; }

inline void *alignedAlloc(std::size_t alignment, std::size_t size) {
    return _aligned_malloc(size, alignment);
}

inline void alignedFree(void *p) { _aligned_free(p); }

inline const char *platformName() { return "Windows"; }

#ifndef SIO_UDP_CONNRESET
#define SIO_UDP_CONNRESET _WSAIOW(IOC_VENDOR, 12)
#endif

// Su Windows, se un sendto provoca un ICMP "port unreachable" (cioe' ogni
// volta che un client sparisce), la recvfrom SUCCESSIVA fallisce con
// WSAECONNRESET. Su un server UDP che parla con molti client e' un
// comportamento inutile: fa fallire letture valide e riempie il log di
// errori. Su POSIX non succede affatto.
inline void configureUdpSocket(int s) {
    BOOL enable = FALSE;
    DWORD returned = 0;
    WSAIoctl(static_cast<SOCKET>(s), SIO_UDP_CONNRESET,
             &enable, sizeof enable, nullptr, 0, &returned, nullptr, nullptr);
}

// La CRT di Windows tratta _IOLBF come _IOFBF, e non lascia stderr senza
// buffer quando e' rediretto su file: senza questo il log delle connessioni
// resta invisibile finche' il buffer non si riempie.
inline void setupLogging() {
    setvbuf(stdout, nullptr, _IONBF, 0);
    setvbuf(stderr, nullptr, _IONBF, 0);
}

} // namespace platform

#else // ---------------------------------------------------------------- POSIX

extern "C" {
#include <sys/socket.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <poll.h>
}

#include <cerrno>

namespace platform {

inline bool netInit() { return true; }

inline void netShutdown() {}

inline int netErrno() { return errno; }

inline bool wouldBlock(int e) { return e == EAGAIN || e == EWOULDBLOCK; }

inline void closeSocket(int s) { ::close(s); }

// Anche qui servono entrambi: sotto systemd lo stdout e' una pipe, e il
// "premi Invio per chiudere" non ha senso.
inline bool stdinIsTerminal() {
    return isatty(STDIN_FILENO) != 0 && isatty(STDOUT_FILENO) != 0;
}

inline bool stdinHasInput() {
    pollfd pfd = {STDIN_FILENO, POLLIN, 0};
    return ::poll(&pfd, 1, 0) > 0 && (pfd.revents & POLLIN);
}

inline void *alignedAlloc(std::size_t alignment, std::size_t size) {
    return ::aligned_alloc(alignment, size);
}

inline void alignedFree(void *p) { ::free(p); }

inline const char *platformName() { return "POSIX"; }

// Su POSIX non serve: gli ICMP di destinazione irraggiungibile non fanno
// fallire le letture di un socket UDP non connesso.
inline void configureUdpSocket(int) {}

// Verso il journal di systemd lo stdout e' una pipe, quindi pienamente
// bufferizzato: senza questo il log resta vuoto a lungo.
inline void setupLogging() {
    setvbuf(stdout, nullptr, _IOLBF, 0);
    setvbuf(stderr, nullptr, _IONBF, 0);
}

} // namespace platform

#endif

// FD_SET e FD_ISSET vogliono SOCKET su Windows e int su POSIX.
#ifdef _WIN32
typedef SOCKET SOCKET_T;
#else
typedef int SOCKET_T;
#endif

namespace platform {

// inet_aton non esiste su Windows, e comunque restituisce 0/non-zero,
// non un codice negativo: il controllo originale `if(err < 0)` non
// intercettava mai un indirizzo malformato. Qui 0 = ok, -1 = errore.
inline int parseIPv4(const char *text, in_addr *out) {
    return inet_pton(AF_INET, text, out) == 1 ? 0 : -1;
}

} // namespace platform

#endif
