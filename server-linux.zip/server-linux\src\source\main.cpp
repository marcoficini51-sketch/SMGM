#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <chrono>

#include "protocol.hpp"
#include "packets.hpp"
#include "packets/connect.hpp"
#include "packets/ack.hpp"
#include "packetFactory.hpp"
#include "transmission.hpp"
#include "players.hpp"

#include "platform_net.hpp"

#define STRINGIZE(a) #a

static uint16_t port = 
#ifdef DEFAULT_PORT
	DEFAULT_PORT;
#else
	5029;
#endif

static const char *bindInetAddrStr = 
#ifdef DEFAULT_ADDR
	STRINGIZE(DEFAULT_ADDR);
#else
	"0.0.0.0";
#endif

constexpr uint8_t maxNumPlayers =
#ifdef MAX_NUM_PLAYERS
	MAX_NUM_PLAYERS;
#else
	8;
#endif

static uint8_t connectionBufferSize = 
#ifdef CONNECTION_BUFFER_SIZE
	CONNECTION_BUFFER_SIZE;
#else
	maxNumPlayers;
#endif

static size_t packetBufferSize =
#ifdef TRANSMISSION_BUFF_SIZE
	TRANSMISSION_BUFF_SIZE;
#else
	alignUp((Packets::MAX_PACKET_SIZE + 20) * maxNumPlayers, Packets::PACKET_ALIGNMENT);
#endif

Player::Player players[maxNumPlayers];

// Friendly fire. Col mod patchato, chi fa lo schianto a terra addosso a un
// altro giocatore gli toglie 1 di vita, e chi fa la piroetta lo fa cadere
// senza danno. Lo decide la console di chi subisce, guardando i flag
// d'attacco nel pacchetto posizione dell'altro. Col friendly fire spento il
// server cancella quei flag prima di inoltrare: nessun client da configurare.
//
// Si puo' cambiare mentre il server gira: basta scrivere 1 o 0 nel file di
// controllo. Riavviare il server obbligherebbe tutti a riavviare il gioco.
constexpr uint8_t FLAG_HIPDROP = 0x01, FLAG_SPIN = 0x02;
static bool friendlyFire = false;
static const char *ffControlPath = nullptr;

static void pollFriendlyFire() {
	if(!ffControlPath) return;
	static auto next = std::chrono::steady_clock::time_point{};
	const auto now = std::chrono::steady_clock::now();
	if(now < next) return;
	next = now + std::chrono::seconds(1);

	FILE *f = fopen(ffControlPath, "rb");
	if(!f) return;                         // file assente: resta com'e'
	int c = fgetc(f);
	fclose(f);
	if(c != '0' && c != '1') return;
	bool on = c == '1';
	if(on != friendlyFire) {
		friendlyFire = on;
		printf("Friendly fire: %s\n", on ? "ON" : "OFF");
	}
}

// Teletrasporto ("tp" come in Minecraft). Il pannello scrive nel file di
// controllo il numero dello slot da raggiungere; il server lo legge, cancella
// il file e per TP_PACKETS pacchetti accende il bit FLAG_TP nelle posizioni
// di quello slot inoltrate agli altri. Il mod patchato, visto il bit, porta il
// proprio Mario su quella posizione se e' nella stessa galassia.
constexpr uint8_t FLAG_TP = 0x04;
constexpr int TP_PACKETS = 90;
static const char *tpControlPath = nullptr;
static int tpSlot = -1, tpLeft = 0;

static void pollTeleport() {
	if(!tpControlPath) return;
	static auto next = std::chrono::steady_clock::time_point{};
	const auto now = std::chrono::steady_clock::now();
	if(now < next) return;
	next = now + std::chrono::milliseconds(250);

	FILE *f = fopen(tpControlPath, "rb");
	if(!f) return;
	char buf[16] = {0};
	size_t n = fread(buf, 1, sizeof buf - 1, f);
	fclose(f);
	remove(tpControlPath);
	buf[n] = '\0';
	int slot = atoi(buf);
	if(buf[0] < '0' || buf[0] > '9' || slot < 0 || slot >= maxNumPlayers) {
		printf("Teletrasporto: slot non valido (%s)\n", buf);
		return;
	}
	tpSlot = slot;
	tpLeft = TP_PACKETS;
	printf("Teletrasporto: tutti da slot %d\n", slot);
}

static bool parseOnOff(const char *s, bool *out) {
	if(!strcmp(s, "on") || !strcmp(s, "1")) { *out = true; return true; }
	if(!strcmp(s, "off") || !strcmp(s, "0")) { *out = false; return true; }
	return false;
}

int main(int argc, char **argv) {

	int err;

	// Uso: SMGServer [porta] [indirizzo di bind] [--friendly-fire=on|off]
	//                [--controllo FILE] [--tp FILE]
	// Senza argomenti restano i valori impostati a tempo di compilazione e il
	// friendly fire e' spento.
	int positional = 0;
	for(int i = 1; i < argc; i++) {
		const char *a = argv[i];
		if(!strncmp(a, "--friendly-fire", 15)) {
			if(a[15] == '\0') friendlyFire = true;
			else if(a[15] != '=' || !parseOnOff(a + 16, &friendlyFire)) {
				fprintf(stderr, "(main) Invalid option: %s (use --friendly-fire=on|off)\n", a);
				return -1;
			}
		}
		else if(!strncmp(a, "--controllo=", 12)) ffControlPath = a + 12;
		else if(!strcmp(a, "--controllo") && i + 1 < argc) ffControlPath = argv[++i];
		else if(!strncmp(a, "--tp=", 5)) tpControlPath = a + 5;
		else if(!strcmp(a, "--tp") && i + 1 < argc) tpControlPath = argv[++i];
		else if(a[0] == '-' && a[1] == '-') {
			fprintf(stderr, "(main) Unknown option: %s\n", a);
			return -1;
		}
		else if(positional == 0) {
			int p = atoi(a);
			if(p <= 0 || p > 0xFFFF) {
				fprintf(stderr, "(main) Invalid port: %s\n", a);
				return -1;
			}
			port = static_cast<uint16_t>(p);
			positional++;
		}
		else if(positional == 1) { bindInetAddrStr = a; positional++; }
		else {
			fprintf(stderr, "(main) Unexpected argument: %s\n", a);
			return -1;
		}
	}

	platform::setupLogging();

	// Su Windows i socket non esistono finche' non si inizializza Winsock.
	if(!platform::netInit()) {
		fprintf(stderr, "(main) Failed to initialise networking\n");
		return -1;
	}

	int fd = static_cast<int>(socket(AF_INET, SOCK_DGRAM, 0));

	if(fd < 0) {
		fprintf(stderr, "(main) Failed to create socket (%d)\n", platform::netErrno());
		platform::netShutdown();
		return -1;
	}

	platform::configureUdpSocket(fd);

	// NB: non chiamarla `s_addr`. Winsock definisce `#define s_addr S_un.S_addr`,
	// quindi quel nome come identificatore non compila piu' su Windows.
	in_addr bindAddr;
	err = platform::parseIPv4(bindInetAddrStr, &bindAddr);

	if(err < 0) {
		fprintf(stderr, "(main) Invalid host IP address: %s\n", bindInetAddrStr);
		platform::closeSocket(fd);
		platform::netShutdown();
		return -1;
	}

	sockaddr_in addr;

	addr.sin_family = AF_INET;
	addr.sin_port = htons(port);
	addr.sin_addr = bindAddr;

	err = bind(fd, reinterpret_cast<const sockaddr *>(&addr), sizeof addr);

	if(err < 0) {
		fprintf(stderr, "(main) Failed to bind to %s:%u (%d)\n",
			bindInetAddrStr, port, platform::netErrno());
		platform::closeSocket(fd);
		platform::netShutdown();
		return -1;
	}

	void *packetBuffer = platform::alignedAlloc(Packets::PACKET_ALIGNMENT, packetBufferSize);

	if(packetBuffer == nullptr) {
		fprintf(stderr, "(main) Not enough memory available on this system\n");
		platform::closeSocket(fd);
		platform::netShutdown();
		return -1;
	}

	auto *connectionBuffer = new(std::nothrow) 
        Transmission::Connection[connectionBufferSize];

	if(connectionBuffer == nullptr) {
		fprintf(stderr, "(main) Not enough memory available on this system\n");
		platform::alignedFree(packetBuffer);
		platform::closeSocket(fd);
		platform::netShutdown();
		return -1;
	}

	Packets::PacketFactory factory;
	Protocol::PacketProcessor pp(packetBuffer, packetBufferSize, factory);

	Transmission::ConnectionHolder connectionHolder(connectionBuffer, connectionBufferSize);

    Transmission::Reader reader(fd, &connectionHolder);
    Transmission::Writer writer(fd, &connectionHolder);

    const auto initialTime = std::chrono::steady_clock::now();

	// "Hit enter to close" ha senso solo con un terminale. Senza tty lo stdin
	// e' subito a EOF, che poll() riporta come leggibile: il server uscirebbe
	// dopo il primo pacchetto. Sotto systemd e' esattamente il caso.
	const bool watchStdin = platform::stdinIsTerminal();

	if(watchStdin) {
		printf("Listening on port %u (%s). Hit enter to close the server\n",
			port, platform::platformName());
	}
	else {
		printf("Listening on port %u (%s, non-interactive); stop with SIGTERM\n",
			port, platform::platformName());
	}

	if(ffControlPath)
		printf("Friendly fire: %s (file di controllo: %s)\n", friendlyFire ? "ON" : "OFF", ffControlPath);
	else
		printf("Friendly fire: %s\n", friendlyFire ? "ON" : "OFF");
	// Chi manda posizioni senza essersi presentato e' quasi sempre un gioco
	// rimasto aperto mentre il server veniva riavviato. Prima ogni suo
	// pacchetto finiva scartato con una riga "invalid packet received (5)", e
	// bisognava riavviare il gioco. Ora, se lo slot che dichiara e' libero, lo
	// si riadotta e da quel momento e' collegato come prima. Se e' occupato lo
	// si dice una volta sola per indirizzo, non a ogni pacchetto.
	struct Noted { uint32_t ip; uint16_t port; };
	Noted noted[32] = {};
	int notedN = 0;
	auto handleUnknownSender = [&]() {
		NetReturn sid = pp.getSenderId();
		if(sid.errorCode != NetReturn::OK) return;
		const Transmission::Connection *c = connectionHolder.getConnection(sid.bytes);
		if(!c || !c->isCandidate) return;
		Packets::Tag tag;
		uint8_t *payload;
		uint32_t len;
		if(!pp.currentPacket(tag, payload, len)) return;
		if(tag != Packets::Tag::PLAYER_POSITION || len < 1) return;   // aspetto una posizione
		const sockaddr_in addr = c->addr;
		const uint8_t claimed = payload[0];
		const auto *ip = reinterpret_cast<const uint8_t *>(&addr.sin_addr.s_addr);
		if(connectionHolder.adopt(static_cast<uint8_t>(sid.bytes), claimed)) {
			fprintf(stderr, "Connected to %d.%d.%d.%d on port %d (%d) - riadottato: il gioco era aperto da prima del riavvio\n",
				ip[0], ip[1], ip[2], ip[3], ntohs(addr.sin_port), claimed);
			return;
		}
		for(int i = 0; i < notedN; i++)
			if(noted[i].ip == addr.sin_addr.s_addr && noted[i].port == addr.sin_port) return;
		if(notedN < 32) noted[notedN++] = {addr.sin_addr.s_addr, addr.sin_port};
		fprintf(stderr, "Warning: %d.%d.%d.%d:%d dichiara lo slot %d, occupato da un altro: deve riavviare il gioco\n",
			ip[0], ip[1], ip[2], ip[3], ntohs(addr.sin_port), claimed);
	};

	bool quit = false;

    bool full = false;

	while(!quit) {

		if(watchStdin && platform::stdinHasInput()) quit = true;

		pollFriendlyFire();
		pollTeleport();

		NetReturn res;
		res = pp.readPacket(reader);
        bool fail = true;
		switch(res.errorCode) {
			case NetReturn::OK:
                fail = false;
				break;
			case NetReturn::CANDIDATE:
				pp.getPacketFactory().setCandidate();
                fail = false;
				break;
			case NetReturn::NOT_ENOUGH_SPACE:
				fprintf(stderr, "Warning: Not enough memory\n");
				break;
            case NetReturn::FILTERED:
                if(!full) {
                    full = true;
                    fprintf(stderr, "Warning: Attempt made to connect to full server\n");
                }
                break;
			default:
				fprintf(stderr, "Warning: invalid packet received\n");
				break;
		}

        if(!fail) {

            Packets::PacketFactory::PacketUnion pu;
            
            res = pp.processPacket(&pu);
            if(res.errorCode != NetReturn::OK) {
                if(res.errorCode == NetReturn::FILTERED)
                    handleUnknownSender();           // riadozione; niente righe a raffica
                else
                    fprintf(stderr, "Warning: invalid packet received (%u)\n", res.errorCode);
                pp.dropPacket();
                pp.finishProcessing();
                //continue;
            }
            else {
                switch(pu.tag) {
                case Packets::Tag::CONNECT: 
                {
                    NetReturn id = pp.getSenderId();
                    if(id.errorCode != NetReturn::OK) netHandleInvalidState();
                    if(!connectionHolder.addConnection(id.bytes)) {
                        fprintf(stderr, "Failed to add connection %d", id.bytes);
                    }
                    const Transmission::Connection *c 
                        = connectionHolder.getConnection(id.bytes);
                    const auto *ipAddr = reinterpret_cast<const uint8_t *>
                        (&c->addr.sin_addr.s_addr);
                    uint16_t port = ntohs(c->addr.sin_port);
                    fprintf(stderr, "Connected to %d.%d.%d.%d on port %d (%d)\n",
                        ipAddr[0],
                        ipAddr[1],
                        ipAddr[2],
                        ipAddr[3],
                        port,
                        id.bytes
                    );
                    pp.addPacket(Packets::ServerInitialResponse(
                        Protocol::MAJOR, Protocol::MINOR, id.bytes
                    ), 0x80 | id.bytes);
                    pp.dropPacket();
                    pp.finishProcessing();
                    break;
                }

                case Packets::Tag::ACK:
                case Packets::Tag::TIME_RESPONSE:
                case Packets::Tag::SERVER_INITIAL_RESPONSE:
                {
                    pp.dropPacket();
                    pp.finishProcessing();
                    break;
                }
                case Packets::Tag::PLAYER_POSITION:
                {
                    const Packets::PlayerPosition &pos = pu.playerPos;
                    NetReturn id = pp.getSenderId();
                    if(id.errorCode != NetReturn::OK) netHandleInvalidState();

                    if(pos.playerId >= maxNumPlayers) {
                        fprintf(stderr, "Rejected packet: player id %d is out of range (max %d)\n",
                            pos.playerId, maxNumPlayers - 1);
                        pp.dropPacket();
                        pp.finishProcessing();
                        break;
                    }

                    if(id.bytes != pos.playerId) {
                        fprintf(stderr, "Client %d is impersonating %d\n",
                            id.bytes, pu.playerPos.playerId);
                        pp.dropPacket();
                        pp.finishProcessing();
                        break;
                    }

                    // Friendly fire spento: chi riceve non deve vedere i flag
                    // d'attacco, quindi li tolgo dai byte che verranno inoltrati.
                    // Gli altri bit restano come sono.
                    if(!friendlyFire) {
                        uint8_t *raw = pp.currentPayload();
                        if(raw) raw[1] &= static_cast<uint8_t>(~(FLAG_HIPDROP | FLAG_SPIN));
                    }
                    if(tpLeft > 0 && pos.playerId == tpSlot) {
                        uint8_t *raw = pp.currentPayload();
                        if(raw) raw[1] |= FLAG_TP;
                        tpLeft--;
                    }

                    players[pos.playerId].updateInfo(&pos.position, &pos.velocity, &pos.direction);

                    pp.finishProcessing();

                    break;
                }
                case Packets::Tag::STAR_PIECE:
                {
                    // TODO: Maybe do some more validity checking and store the packet?
                    pp.finishProcessing();
                    break;
                }
                case Packets::Tag::ACTOR_KILLED:
                {
                    pp.finishProcessing();
                    break;
                }
                case Packets::Tag::COIN_COLLECTED:
                {
                    // Niente dropPacket: non scartandolo viene rilanciato agli
                    // altri, che e' tutto cio' che deve fare il server.
                    pp.finishProcessing();
                    break;
                }
                case Packets::Tag::TIME_QUERY:
                {
                    NetReturn id = pp.getSenderId();
                    if(id.errorCode != NetReturn::OK) netHandleInvalidState();
                    const Packets::TimeQuery &tqp = pu.timeQuery;
                    uint32_t t = std::chrono::duration_cast<std::chrono::milliseconds>
                        (std::chrono::steady_clock::now() - initialTime).count();
                    pp.addPacket(Packets::TimeResponse(t, tqp.check), 0x80 | id.bytes);
                    pp.dropPacket();
                    pp.finishProcessing();
                    break;
                }
                case Packets::Tag::MAX_TAG: // invalid state
                    break;
            }

        }}
        pp.getPacketFactory().resetCandidate();

		do {
			res = pp.sendPacket(writer);
		} while (res.errorCode == NetReturn::OK && res.bytes > 0);
		

	}

	platform::closeSocket(fd);
	platform::netShutdown();

	delete[] connectionBuffer;
	platform::alignedFree(packetBuffer);

	return 0;
}

