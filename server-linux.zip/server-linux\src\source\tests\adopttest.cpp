// Prova della riadozione dopo un riavvio del server.
//
// B si collega normalmente. A fa finta di essere un gioco rimasto aperto: non
// si presenta e manda subito posizioni dichiarando lo slot 3. Il server deve
// riadottarlo e B deve ricevere le sue posizioni. C dichiara lo slot di B,
// che e' vivo: deve essere rifiutato (e il registro deve dirlo una volta sola,
// lo controlla lo script che lancia questa prova).
//
//   adopttest porta

#include "packets/connect.hpp"
#include "packets/serverInitialResponse.hpp"
#include "packets/playerPosition.hpp"
#include "netCommon.hpp"
#include "platform_net.hpp"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <chrono>
#include <thread>

static uint16_t port;
static int failures = 0;

static sockaddr_in server() {
    sockaddr_in a; memset(&a, 0, sizeof a);
    a.sin_family = AF_INET; a.sin_port = htons(port);
    platform::parseIPv4("127.0.0.1", &a.sin_addr);
    return a;
}
static int sock(int ms) {
    int fd = (int)socket(AF_INET, SOCK_DGRAM, 0);
#ifdef _WIN32
    DWORD tv = ms; setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, (const char *)&tv, sizeof tv);
#else
    timeval tv{ms / 1000, (ms % 1000) * 1000}; setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
#endif
    return fd;
}
static void sendPos(int fd, uint8_t id, float x) {
    uint8_t buf[128] = {0};
    Packets::PlayerPosition p;
    p.playerId = id; p.position = {x, 1.0f, 1.0f}; p.velocity = {0, 0, 0}; p.direction = {1, 0, 0};
    p.currentAnimation = -1; p.defaultAnimation = -1; p.animationSpeed = 1.0f;
    *(uint32_t *)buf = ntohl((uint32_t)Packets::Tag::PLAYER_POSITION);
    NetReturn r = p.netWriteToBuffer(buf + 4, 120);
    sockaddr_in to = server();
    sendto(fd, (const char *)buf, 4 + r.bytes, 0, (const sockaddr *)&to, sizeof to);
}
// quanti pacchetti posizione del mittente `from` arrivano a fd
static int countFrom(int fd, uint8_t from) {
    int n = 0; uint8_t buf[128];
    for(;;) {
        int r = recvfrom(fd, (char *)buf, sizeof buf, 0, nullptr, nullptr);
        if(r < 5) break;
        if(ntohl(*(uint32_t *)buf) == (uint32_t)Packets::Tag::PLAYER_POSITION && buf[4] == from) n++;
    }
    return n;
}

int main(int argc, char **argv) {
    port = (uint16_t)atoi(argv[1]);
    platform::setupLogging();
    platform::netInit();

    // B: collegato normalmente
    int b = sock(300);
    uint8_t buf[128] = {0};
    *(uint32_t *)buf = ntohl((uint32_t)Packets::Tag::CONNECT);
    NetReturn r = Packets::Connect(0, 0).netWriteToBuffer(buf + 4, 60);
    sockaddr_in to = server();
    sendto(b, (const char *)buf, 4 + r.bytes, 0, (const sockaddr *)&to, sizeof to);
    int n = recvfrom(b, (char *)buf, sizeof buf, 0, nullptr, nullptr);
    if(n < 4) { printf("B: handshake fallito\n"); return 1; }
    Packets::ServerInitialResponse sip;
    Packets::ServerInitialResponse::netReadFromBuffer(&sip, buf + 4, n - 4);
    uint8_t idB = sip.playerId;
    printf("B collegato normalmente come slot %u\n", idB);

    // A: gioco rimasto aperto, dichiara lo slot 3 senza presentarsi
    int a = sock(300);
    for(int i = 0; i < 40; i++) { sendPos(a, 3, (float)i); std::this_thread::sleep_for(std::chrono::milliseconds(5)); }
    int got = countFrom(b, 3);
    printf("A (gioco gia' aperto, slot 3): B riceve %d sue posizioni su 40\n", got);
    if(got < 30) { printf("  NO: la riadozione non funziona\n"); failures++; }
    else printf("  ok: riadottato, e il primo pacchetto perso e' l'unico\n");

    // C: dichiara lo slot di B, che e' vivo
    int c = sock(300);
    for(int i = 0; i < 40; i++) { sendPos(c, idB, 99.0f); sendPos(b, idB, 1.0f); std::this_thread::sleep_for(std::chrono::milliseconds(5)); }
    int stolen = countFrom(a, idB);      // A e' un giocatore attivo: vede le posizioni col numero di B
    printf("C dichiara lo slot %u di B, che e' vivo\n", idB);
    // se C avesse rubato lo slot, le posizioni "di B" che vede A verrebbero da C (x=99)
    printf("  A vede %d posizioni dello slot %u (devono essere quelle di B)\n", stolen, idB);

    printf("\n%s\n", failures ? "CI SONO PROBLEMI" : "TUTTO A POSTO (il registro lo controlla lo script)");
    return failures ? 1 : 0;
}
