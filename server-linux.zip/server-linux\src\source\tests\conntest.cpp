// Verifica che un server SMG sia raggiungibile e risponda all'handshake.
//
// Stampa una riga sola, leggibile da uno script:
//   OK id=<n> rtt=<ms>
//   FAIL <motivo>
//
//   conntest <indirizzo> [porta]

#include "packets/connect.hpp"
#include "packets/serverInitialResponse.hpp"
#include "netCommon.hpp"
#include "platform_net.hpp"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <chrono>

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("FAIL nessun indirizzo specificato\n");
        return 1;
    }

    const char *host = argv[1];
    uint16_t port = (argc > 2) ? (uint16_t)atoi(argv[2]) : 5029;

    platform::setupLogging();

    if (!platform::netInit()) {
        printf("FAIL impossibile inizializzare la rete\n");
        return 1;
    }

    in_addr target;
    if (platform::parseIPv4(host, &target) < 0) {
        printf("FAIL indirizzo non valido: %s\n", host);
        platform::netShutdown();
        return 1;
    }

    int fd = static_cast<int>(socket(AF_INET, SOCK_DGRAM, 0));
    if (fd < 0) {
        printf("FAIL impossibile creare il socket\n");
        platform::netShutdown();
        return 1;
    }

    sockaddr_in addr;
    memset(&addr, 0, sizeof addr);
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr = target;

    // timeout di ricezione: 2 secondi
#ifdef _WIN32
    DWORD tv = 2000;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char *>(&tv), sizeof tv);
#else
    timeval tv;
    tv.tv_sec = 2;
    tv.tv_usec = 0;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
#endif

    uint8_t *buffer = static_cast<uint8_t *>(platform::alignedAlloc(4, 128));
    if (!buffer) {
        printf("FAIL memoria insufficiente\n");
        platform::closeSocket(fd);
        platform::netShutdown();
        return 1;
    }
    memset(buffer, 0, 128);

    Packets::Connect connect(0, 0);
    *reinterpret_cast<uint32_t *>(buffer) = ntohl((uint32_t)Packets::Tag::CONNECT);
    NetReturn res = connect.netWriteToBuffer(buffer + 4, 28);
    if (res.errorCode != NetReturn::OK) {
        printf("FAIL impossibile costruire il pacchetto di connessione\n");
        platform::alignedFree(buffer);
        platform::closeSocket(fd);
        platform::netShutdown();
        return 1;
    }

    const auto start = std::chrono::steady_clock::now();

    if (sendto(fd, reinterpret_cast<const char *>(buffer), 4 + res.bytes, 0,
               reinterpret_cast<const sockaddr *>(&addr), sizeof addr) < 0) {
        printf("FAIL invio non riuscito (errore %d)\n", platform::netErrno());
        platform::alignedFree(buffer);
        platform::closeSocket(fd);
        platform::netShutdown();
        return 1;
    }

    int n = recvfrom(fd, reinterpret_cast<char *>(buffer), 128, 0, nullptr, nullptr);

    const auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now() - start).count();

    int exitCode = 1;

    if (n < 0) {
        printf("FAIL nessuna risposta entro 2 secondi\n");
    }
    else if (n < 4 ||
             ntohl(*reinterpret_cast<const uint32_t *>(buffer)) !=
                 (uint32_t)Packets::Tag::SERVER_INITIAL_RESPONSE) {
        printf("FAIL risposta inattesa: sulla porta c'e' qualcosa, ma non questo server\n");
    }
    else {
        Packets::ServerInitialResponse sip;
        if (Packets::ServerInitialResponse::netReadFromBuffer(&sip, buffer + 4, n - 4).errorCode
                != NetReturn::OK) {
            printf("FAIL risposta illeggibile\n");
        }
        else {
            printf("OK id=%u rtt=%lld\n", sip.playerId, (long long)elapsed);
            exitCode = 0;
        }
    }

    platform::alignedFree(buffer);
    platform::closeSocket(fd);
    platform::netShutdown();
    return exitCode;
}
