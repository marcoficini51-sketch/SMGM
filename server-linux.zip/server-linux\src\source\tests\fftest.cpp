// Prova del friendly fire lato server.
//
// A manda una posizione con i flag di schianto e piroetta accesi; B deve
// vederli cancellati col friendly fire spento, intatti con quello acceso. Il
// cambio avviene mentre il server gira, scrivendo nel file di controllo: e'
// cosi' che lo usa il pannello.
//
//   fftest porta file_di_controllo

#include "packets/connect.hpp"
#include "packets/serverInitialResponse.hpp"
#include "packets/playerPosition.hpp"
#include "netCommon.hpp"
#include "platform_net.hpp"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <chrono>
#include <thread>

static uint16_t port;
static int failures = 0;

static sockaddr_in serverAddr() {
    sockaddr_in a;
    memset(&a, 0, sizeof a);
    a.sin_family = AF_INET;
    a.sin_port = htons(port);
    platform::parseIPv4("127.0.0.1", &a.sin_addr);
    return a;
}

static int connectClient(uint8_t *id) {
    int fd = (int)socket(AF_INET, SOCK_DGRAM, 0);
#ifdef _WIN32
    DWORD tv = 1000;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, (const char *)&tv, sizeof tv);
#else
    timeval tv{1, 0};
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
#endif
    uint8_t buf[128] = {0};
    *(uint32_t *)buf = ntohl((uint32_t)Packets::Tag::CONNECT);
    NetReturn r = Packets::Connect(0, 0).netWriteToBuffer(buf + 4, 60);
    sockaddr_in to = serverAddr();
    sendto(fd, (const char *)buf, 4 + r.bytes, 0, (const sockaddr *)&to, sizeof to);
    int n = recvfrom(fd, (char *)buf, sizeof buf, 0, nullptr, nullptr);
    if(n < 4) return -1;
    Packets::ServerInitialResponse sip;
    Packets::ServerInitialResponse::netReadFromBuffer(&sip, buf + 4, n - 4);
    *id = sip.playerId;
    return fd;
}

// manda una posizione con i flag dati e ritorna i flag che arrivano a B
static int roundTrip(int a, uint8_t idA, int b, uint8_t flags) {
    uint8_t buf[128] = {0};
    Packets::PlayerPosition p;
    p.playerId = idA;
    p.position = {1.0f, 2.0f, 3.0f};
    p.velocity = {0, 0, 0};
    p.direction = {1, 0, 0};
    p.currentAnimation = 0; p.defaultAnimation = 0; p.animationSpeed = 1.0f;
    p.stateFlags = flags;
    *(uint32_t *)buf = ntohl((uint32_t)Packets::Tag::PLAYER_POSITION);
    NetReturn r = p.netWriteToBuffer(buf + 4, 120);
    sockaddr_in to = serverAddr();
    sendto(a, (const char *)buf, 4 + r.bytes, 0, (const sockaddr *)&to, sizeof to);
    for(int i = 0; i < 20; i++) {
        int n = recvfrom(b, (char *)buf, sizeof buf, 0, nullptr, nullptr);
        if(n < 6) return -1;
        if(ntohl(*(uint32_t *)buf) != (uint32_t)Packets::Tag::PLAYER_POSITION) continue;
        if(buf[4] != idA) continue;
        return buf[5];
    }
    return -1;
}

static void setControl(const char *path, char c) {
    FILE *f = fopen(path, "wb");
    fputc(c, f);
    fclose(f);
    // il server rilegge il file al massimo una volta al secondo
    std::this_thread::sleep_for(std::chrono::milliseconds(1300));
}

static void expect(const char *what, int got, int want) {
    printf("  %-44s arrivano 0x%02X (attesi 0x%02X)  %s\n", what, got & 0xFF, want,
           got == want ? "ok" : "NO");
    if(got != want) failures++;
}

int main(int argc, char **argv) {
    if(argc < 3) { printf("uso: fftest porta file_di_controllo\n"); return 2; }
    port = (uint16_t)atoi(argv[1]);
    const char *ctl = argv[2];
    platform::setupLogging();
    platform::netInit();

    uint8_t idA, idB;
    int a = connectClient(&idA), b = connectClient(&idB);
    if(a < 0 || b < 0) { printf("handshake fallito\n"); return 1; }

    printf("=== all'avvio (file non ancora scritto: vale l'opzione) ===\n");
    expect("schianto+piroetta, friendly fire spento", roundTrip(a, idA, b, 0x03), 0x00);

    printf("\n=== acceso scrivendo 1 nel file ===\n");
    setControl(ctl, '1');
    // il primo pacchetto dopo l'attesa fa scattare la rilettura
    roundTrip(a, idA, b, 0x00);
    expect("schianto+piroetta, friendly fire acceso", roundTrip(a, idA, b, 0x03), 0x03);
    expect("solo piroetta", roundTrip(a, idA, b, 0x02), 0x02);

    printf("\n=== spento scrivendo 0 ===\n");
    setControl(ctl, '0');
    roundTrip(a, idA, b, 0x00);
    expect("schianto+piroetta, friendly fire spento", roundTrip(a, idA, b, 0x03), 0x00);
    expect("altri bit restano (0x80)", roundTrip(a, idA, b, 0x83), 0x80);

    platform::closeSocket(a);
    platform::closeSocket(b);
    platform::netShutdown();
    printf("\n%s\n", failures ? "CI SONO PROBLEMI" : "TUTTO A POSTO");
    return failures ? 1 : 0;
}
