// Test mode: spawna un Mario che ripete i tuoi movimenti con un ritardo.
//
// Tiene una linea di ritardo delle posizioni ricevute dal giocatore vero e
// ritrasmette quella di N millisecondi fa. Il risultato in gioco e' un
// secondo Mario che ti segue rifacendo il tuo percorso.
//
//   follow [porta] [ritardo_ms] [dx] [dy] [dz]
//
// Nota: il timestamp inviato e' sempre quello corrente, non quello del
// campione ritardato. Serve perche' il mod scarta i pacchetti il cui
// timestamp non e' successivo all'ultimo ricevuto - se rispedissimo il
// timestamp vecchio, il puppet non si muoverebbe affatto.

#include "packets/connect.hpp"
#include "packets/serverInitialResponse.hpp"
#include "packets/playerPosition.hpp"
#include "netCommon.hpp"
#include "platform_net.hpp"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <csignal>
#include <chrono>

using Clock = std::chrono::steady_clock;

struct Sample {
    Clock::time_point t;
    Vec pos, vel, dir;
    int32_t anm, defAnm;
    float anmSpeed;
    // i 16 byte dopo i 56 del pacchetto: i pesi della camminata, se il mod
    // li manda. Vanno ripetuti tali e quali, se no il Mario finto scivola.
    uint8_t weights[16];
    bool hasWeights;
    uint8_t flags;
    bool valid = false;
};

static const int BUFFER = 512;   // ~8 secondi a 60 Hz
static Sample ring[BUFFER];
static int head = 0;

static volatile sig_atomic_t running = 1;
static void onSignal(int) { running = 0; }

// Campione piu' vicino all'istante voluto.
static const Sample *findAt(Clock::time_point want) {
    const Sample *best = nullptr;
    long long bestDiff = 0;
    for (int i = 0; i < BUFFER; i++) {
        if (!ring[i].valid) continue;
        long long diff = std::chrono::duration_cast<std::chrono::milliseconds>(
            ring[i].t - want).count();
        if (diff < 0) diff = -diff;
        if (!best || diff < bestDiff) { best = &ring[i]; bestDiff = diff; }
    }
    return best;
}

int main(int argc, char **argv) {
    uint16_t port  = (argc > 1) ? (uint16_t)atoi(argv[1]) : 5029;
    int delayMs    = (argc > 2) ? atoi(argv[2]) : 10;
    float dx       = (argc > 3) ? (float)atof(argv[3]) : 0.0f;
    float dy       = (argc > 4) ? (float)atof(argv[4]) : 0.0f;
    float dz       = (argc > 5) ? (float)atof(argv[5]) : 0.0f;

    if (delayMs < 0) delayMs = 0;
    if (delayMs > 8000) delayMs = 8000;

    signal(SIGINT, onSignal);
    signal(SIGTERM, onSignal);
    platform::setupLogging();

    if (!platform::netInit()) { printf("rete non inizializzabile\n"); return 1; }

    in_addr target;
    platform::parseIPv4("127.0.0.1", &target);

    int fd = static_cast<int>(socket(AF_INET, SOCK_DGRAM, 0));
    if (fd < 0) { printf("socket non creabile\n"); return 1; }
    platform::configureUdpSocket(fd);

    sockaddr_in addr;
    memset(&addr, 0, sizeof addr);
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr = target;

#ifdef _WIN32
    DWORD tv = 2000;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char *>(&tv), sizeof tv);
#else
    timeval tv; tv.tv_sec = 2; tv.tv_usec = 0;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
#endif

    uint8_t *buf = static_cast<uint8_t *>(platform::alignedAlloc(4, 128));
    memset(buf, 0, 128);

    Packets::Connect connect(0, 0);
    *reinterpret_cast<uint32_t *>(buf) = ntohl((uint32_t)Packets::Tag::CONNECT);
    NetReturn res = connect.netWriteToBuffer(buf + 4, 28);
    sendto(fd, reinterpret_cast<const char *>(buf), 4 + res.bytes, 0,
           reinterpret_cast<const sockaddr *>(&addr), sizeof addr);

    int n = recvfrom(fd, reinterpret_cast<char *>(buf), 128, 0, nullptr, nullptr);
    if (n < 4 || ntohl(*reinterpret_cast<const uint32_t *>(buf)) !=
            (uint32_t)Packets::Tag::SERVER_INITIAL_RESPONSE) {
        printf("handshake fallito: il server e' acceso sulla porta %u?\n", port);
        return 1;
    }
    Packets::ServerInitialResponse sip;
    Packets::ServerInitialResponse::netReadFromBuffer(&sip, buf + 4, n - 4);
    uint8_t myId = sip.playerId;

    printf("collegato come giocatore %u\n", myId);
    printf("ritardo: %d ms   offset: (%.0f, %.0f, %.0f)\n\n", delayMs, dx, dy, dz);
    if (delayMs < 50 && dx == 0.0f && dy == 0.0f && dz == 0.0f) {
        printf("ATTENZIONE: con %d ms e nessun offset il Mario finisce dentro di te\n", delayMs);
        printf("            e non lo vedrai. Prova 500 ms, o un offset di 200.\n\n");
    }
    printf("Muoviti in gioco. Ctrl+C per fermare.\n\n");

    unsigned long got = 0, sent = 0;

    while (running) {
        n = recvfrom(fd, reinterpret_cast<char *>(buf), 128, 0, nullptr, nullptr);
        if (n < 4) continue;
        if (ntohl(*reinterpret_cast<const uint32_t *>(buf)) !=
                (uint32_t)Packets::Tag::PLAYER_POSITION) continue;

        Packets::PlayerPosition in;
        if (Packets::PlayerPosition::netReadFromBuffer(&in, buf + 4, n - 4).errorCode
                != NetReturn::OK) continue;
        if (in.playerId == myId) continue;

        // scarto i frame di caricamento
        if (in.position.x == 0.0f && in.position.y == 0.0f && in.position.z == 0.0f) continue;

        got++;

        Sample &s = ring[head];
        s.t = Clock::now();
        s.pos = in.position; s.vel = in.velocity; s.dir = in.direction;
        s.anm = in.currentAnimation; s.defAnm = in.defaultAnimation;
        s.anmSpeed = in.animationSpeed; s.flags = in.stateFlags;
        s.hasWeights = (n - 4) >= 72;
        if (s.hasWeights) memcpy(s.weights, buf + 4 + 56, 16);
        s.valid = true;
        head = (head + 1) % BUFFER;

        const Sample *old = findAt(Clock::now() - std::chrono::milliseconds(delayMs));
        if (!old) continue;

        Packets::PlayerPosition out;
        out.playerId = myId;
        out.timestamp = in.timestamp;          // sempre il piu' recente
        out.position = old->pos;
        out.position.x += dx; out.position.y += dy; out.position.z += dz;
        out.velocity = old->vel;
        out.direction = old->dir;
        out.currentAnimation = old->anm;
        out.defaultAnimation = old->defAnm;
        out.animationSpeed = old->anmSpeed;
        out.stateFlags = old->flags;

        *reinterpret_cast<uint32_t *>(buf) = ntohl((uint32_t)Packets::Tag::PLAYER_POSITION);
        res = out.netWriteToBuffer(buf + 4, 60);
        if (res.errorCode != NetReturn::OK) continue;
        int len = 4 + static_cast<int>(res.bytes);
        if (old->hasWeights) {
            memcpy(buf + len, old->weights, 16);
            len += 16;
        }
        sendto(fd, reinterpret_cast<const char *>(buf), len, 0,
               reinterpret_cast<const sockaddr *>(&addr), sizeof addr);
        sent++;

        if (sent % 300 == 0) {
            long long age = std::chrono::duration_cast<std::chrono::milliseconds>(
                Clock::now() - old->t).count();
            double d = (in.position.x - old->pos.x) * (in.position.x - old->pos.x)
                     + (in.position.y - old->pos.y) * (in.position.y - old->pos.y)
                     + (in.position.z - old->pos.z) * (in.position.z - old->pos.z);
            printf("[%lu ricevuti / %lu inviati] scia %lld ms dietro, %.0f unita' di distanza\n",
                   got, sent, age, (double)__builtin_sqrt(d));
        }
    }

    printf("\nfermato. ricevuti %lu, inviati %lu\n", got, sent);
    platform::alignedFree(buf);
    platform::closeSocket(fd);
    platform::netShutdown();
    return 0;
}
