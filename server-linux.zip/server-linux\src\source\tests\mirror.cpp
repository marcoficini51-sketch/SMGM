// Client "specchio": si finge un secondo giocatore.
//
// Legge la posizione reale del giocatore vero dai pacchetti che il server
// rilancia, e ritrasmette la propria spostata di un offset fisso, copiando
// orientamento e animazioni. In gioco si vede un secondo Mario che segue il
// primo come un'ombra.
//
//   mirror [porta] [dx] [dy] [dz]

#include "packets/connect.hpp"
#include "packets/serverInitialResponse.hpp"
#include "packets/playerPosition.hpp"
#include "netCommon.hpp"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <csignal>

extern "C" {
#include <poll.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/socket.h>
}

static volatile sig_atomic_t running = 1;
static void onSignal(int) { running = 0; }

int main(int argc, char **argv) {
    uint16_t serverPort = (argc > 1) ? (uint16_t)atoi(argv[1]) : 5029;
    float dx = (argc > 2) ? atof(argv[2]) : 200.0f;
    float dy = (argc > 3) ? atof(argv[3]) : 0.0f;
    float dz = (argc > 4) ? atof(argv[4]) : 0.0f;

    signal(SIGINT, onSignal);
    signal(SIGTERM, onSignal);
    setvbuf(stdout, nullptr, _IOLBF, 0);

    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) { perror("socket"); return 1; }

    in_addr saddr;
    inet_aton("127.0.0.1", &saddr);
    sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(serverPort);
    addr.sin_addr = saddr;

    uint8_t *buffer = (uint8_t *)aligned_alloc(4, 128);
    memset(buffer, 0, 128);

    // ---- handshake ----
    Packets::Connect connect(0, 0);
    *(uint32_t *)buffer = ntohl((uint32_t)Packets::Tag::CONNECT);
    NetReturn res = connect.netWriteToBuffer(buffer + 4, 28);
    if (res.errorCode != NetReturn::OK) { fprintf(stderr, "CONNECT non serializzabile\n"); return 1; }
    sendto(fd, buffer, 4 + res.bytes, 0, (sockaddr *)&addr, sizeof addr);

    pollfd pfd = {fd, POLLIN, 0};
    poll(&pfd, 1, 3000);
    if (!(pfd.revents & POLLIN)) { fprintf(stderr, "il server non risponde sulla porta %u\n", serverPort); return 1; }

    ssize_t n = read(fd, buffer, 128);
    if (n < 4 || ntohl(*(const uint32_t *)buffer) != (uint32_t)Packets::Tag::SERVER_INITIAL_RESPONSE) {
        fprintf(stderr, "handshake fallito\n"); return 1;
    }
    Packets::ServerInitialResponse sip;
    if (Packets::ServerInitialResponse::netReadFromBuffer(&sip, buffer + 4, n - 4).errorCode != NetReturn::OK) {
        fprintf(stderr, "risposta illeggibile\n"); return 1;
    }
    uint8_t myId = sip.playerId;
    printf("connesso come playerId=%u · offset (%.0f, %.0f, %.0f)\n", myId, dx, dy, dz);
    printf("in attesa di pacchetti dal giocatore vero...\n");

    unsigned long received = 0, mirrored = 0;
    bool seenPlayer = false;

    while (running) {
        pfd.events = POLLIN;
        pfd.revents = 0;
        if (poll(&pfd, 1, 1000) <= 0) {
            if (!seenPlayer) printf("...nessun pacchetto: il gioco e' connesso e in una galassia?\n");
            continue;
        }

        n = read(fd, buffer, 128);
        if (n < 4) continue;
        if (ntohl(*(const uint32_t *)buffer) != (uint32_t)Packets::Tag::PLAYER_POSITION) continue;

        Packets::PlayerPosition in;
        if (Packets::PlayerPosition::netReadFromBuffer(&in, buffer + 4, n - 4).errorCode != NetReturn::OK) continue;
        if (in.playerId == myId) continue;

        received++;
        if (!seenPlayer) {
            seenPlayer = true;
            printf("trovato il giocatore %u a [%.0f %.0f %.0f]\n",
                   in.playerId, in.position.x, in.position.y, in.position.z);
        }

        // Rispedisco tutto identico tranne la posizione: stesso orientamento,
        // stessa animazione, stessa velocita' per l'estrapolazione.
        Packets::PlayerPosition out;
        out.playerId = myId;
        out.timestamp = in.timestamp;
        out.position = in.position;
        out.position.x += dx;
        out.position.y += dy;
        out.position.z += dz;
        out.velocity = in.velocity;
        out.direction = in.direction;
        out.currentAnimation = in.currentAnimation;
        out.defaultAnimation = in.defaultAnimation;
        out.animationSpeed = in.animationSpeed;
        out.stateFlags = in.stateFlags;

        *(uint32_t *)buffer = ntohl((uint32_t)Packets::Tag::PLAYER_POSITION);
        res = out.netWriteToBuffer(buffer + 4, 60);
        if (res.errorCode != NetReturn::OK) continue;
        sendto(fd, buffer, 4 + res.bytes, 0, (sockaddr *)&addr, sizeof addr);
        mirrored++;

        if (mirrored % 120 == 0) {
            printf("[%lu ricevuti / %lu rispecchiati] Mario a [%.0f %.0f %.0f]\n",
                   received, mirrored, in.position.x, in.position.y, in.position.z);
        }
    }

    printf("\nchiuso. ricevuti %lu, rispecchiati %lu\n", received, mirrored);
    close(fd);
    return 0;
}
