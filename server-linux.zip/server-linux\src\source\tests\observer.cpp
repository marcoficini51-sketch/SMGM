// Osservatore passivo: si collega al server e guarda chi trasmette e dove,
// senza inviare mai una propria posizione (quindi non compare in gioco).
//
// Serve a capire perche' due giocatori collegati non si vedono.
//
//   observer <indirizzo> [porta] [secondi]

#include "packets/connect.hpp"
#include "packets/serverInitialResponse.hpp"
#include "packets/playerPosition.hpp"
#include "netCommon.hpp"
#include "platform_net.hpp"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <chrono>

struct Seen {
    bool active = false;
    unsigned long count = 0;
    Vec pos{};
    int32_t anm = -1;
};

int main(int argc, char **argv) {
    const char *host = (argc > 1) ? argv[1] : "127.0.0.1";
    uint16_t port    = (argc > 2) ? (uint16_t)atoi(argv[2]) : 5029;
    int secs         = (argc > 3) ? atoi(argv[3]) : 10;

    platform::setupLogging();
    if (!platform::netInit()) { printf("rete non inizializzabile\n"); return 1; }

    in_addr target;
    if (platform::parseIPv4(host, &target) < 0) { printf("indirizzo non valido\n"); return 1; }

    int fd = static_cast<int>(socket(AF_INET, SOCK_DGRAM, 0));
    if (fd < 0) { printf("socket non creabile\n"); return 1; }

    sockaddr_in addr;
    memset(&addr, 0, sizeof addr);
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr = target;

#ifdef _WIN32
    DWORD tv = 1000;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char *>(&tv), sizeof tv);
#else
    timeval tv; tv.tv_sec = 1; tv.tv_usec = 0;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
#endif

    uint8_t *buf = static_cast<uint8_t *>(platform::alignedAlloc(4, 128));
    memset(buf, 0, 128);

    Packets::Connect connect(0, 0);
    *reinterpret_cast<uint32_t *>(buf) = ntohl((uint32_t)Packets::Tag::CONNECT);
    NetReturn res = connect.netWriteToBuffer(buf + 4, 28);
    sendto(fd, reinterpret_cast<const char *>(buf), 4 + res.bytes, 0,
           reinterpret_cast<const sockaddr *>(&addr), sizeof addr);

    int n = recvfrom(fd, reinterpret_cast<char *>(buf), 128, 0, nullptr, nullptr);
    if (n < 4 || ntohl(*reinterpret_cast<const uint32_t *>(buf)) !=
            (uint32_t)Packets::Tag::SERVER_INITIAL_RESPONSE) {
        printf("handshake fallito\n");
        return 1;
    }
    Packets::ServerInitialResponse sip;
    Packets::ServerInitialResponse::netReadFromBuffer(&sip, buf + 4, n - 4);
    printf("osservatore collegato (io sono lo slot %u), ascolto %d secondi...\n\n",
           sip.playerId, secs);

    Seen seen[16];
    const auto end = std::chrono::steady_clock::now() + std::chrono::seconds(secs);

    while (std::chrono::steady_clock::now() < end) {
        n = recvfrom(fd, reinterpret_cast<char *>(buf), 128, 0, nullptr, nullptr);
        if (n < 4) continue;
        if (ntohl(*reinterpret_cast<const uint32_t *>(buf)) !=
                (uint32_t)Packets::Tag::PLAYER_POSITION) continue;

        Packets::PlayerPosition p;
        if (Packets::PlayerPosition::netReadFromBuffer(&p, buf + 4, n - 4).errorCode
                != NetReturn::OK) continue;
        if (p.playerId >= 16) continue;

        seen[p.playerId].active = true;
        seen[p.playerId].count++;
        seen[p.playerId].pos = p.position;
        seen[p.playerId].anm = p.currentAnimation;
    }

    printf("=== chi sta trasmettendo ===\n");
    int n_active = 0;
    int ids[16];
    for (int i = 0; i < 16; i++) {
        if (!seen[i].active) continue;
        ids[n_active++] = i;
        printf("  slot %-2d  %6lu pacchetti  posizione [%9.0f %9.0f %9.0f]  anim %d\n",
               i, seen[i].count, seen[i].pos.x, seen[i].pos.y, seen[i].pos.z, seen[i].anm);
    }

    if (n_active == 0) {
        printf("  NESSUNO. I giocatori sono collegati ma non trasmettono:\n");
        printf("  probabilmente non sono dentro una galassia.\n");
    }
    else if (n_active == 1) {
        printf("\n  Solo UNO dei due trasmette. L'altro e' collegato ma fermo\n");
        printf("  fuori da una galassia, oppure il suo mod non sta inviando.\n");
    }
    else {
        printf("\n=== distanze fra i giocatori ===\n");
        for (int a = 0; a < n_active; a++) {
            for (int b = a + 1; b < n_active; b++) {
                const Vec &pa = seen[ids[a]].pos;
                const Vec &pb = seen[ids[b]].pos;
                double dx = pa.x - pb.x, dy = pa.y - pb.y, dz = pa.z - pb.z;
                double d = std::sqrt(dx * dx + dy * dy + dz * dz);
                printf("  slot %d <-> slot %d : %.0f unita'\n", ids[a], ids[b], d);
                if (d > 50000.0) {
                    printf("     -> enorme: quasi certamente scene diverse (stelle diverse)\n");
                } else if (d > 3000.0) {
                    printf("     -> lontani: stessa scena ma fuori dal campo visivo\n");
                } else {
                    printf("     -> vicini: dovreste vedervi\n");
                }
            }
        }
    }

    platform::alignedFree(buf);
    platform::closeSocket(fd);
    platform::netShutdown();
    return 0;
}
