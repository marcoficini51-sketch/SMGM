// Sonda di collaudo: verifica che il server rifiuti un playerId fuori range
// invece di usarlo come indice nell'array players[].
//
// Usa il serializzatore del progetto, quindi i pacchetti sono identici a
// quelli di un client vero: l'unica variabile e' il campo playerId.

#include "packets/connect.hpp"
#include "packets/serverInitialResponse.hpp"
#include "packets/playerPosition.hpp"
#include "netCommon.hpp"

#include <cstdio>
#include <cstdlib>
#include <cstring>

extern "C" {
#include <poll.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/socket.h>
}

static const char *SERVER_ADDR = "127.0.0.1";  // sovrascrivibile da argv[2]
static uint16_t serverPort = 5029;

static int fd;
static sockaddr_in addr;
static uint8_t *buffer;

static bool sendPosition(uint8_t playerId, const char *what) {
    Packets::PlayerPosition pos;
    pos.playerId = playerId;
    pos.stateFlags = 0;
    pos.position  = {100.0f, 200.0f, 300.0f};
    pos.velocity  = {0.0f, 0.0f, 0.0f};
    pos.direction = {1.0f, 0.0f, 0.0f};
    pos.currentAnimation = -1;
    pos.defaultAnimation = -1;
    pos.animationSpeed = 1.0f;
    pos.timestamp = {0};

    *(uint32_t *)buffer = ntohl((uint32_t)Packets::Tag::PLAYER_POSITION);
    NetReturn res = pos.netWriteToBuffer(buffer + 4, 60);
    if (res.errorCode != NetReturn::OK) {
        fprintf(stderr, "[sonda] serializzazione fallita (%d)\n", res.errorCode);
        return false;
    }

    ssize_t sent = sendto(fd, buffer, 4 + res.bytes, 0, (sockaddr *)&addr, sizeof addr);
    printf("[sonda] inviato %s: playerId=%u, %zd byte\n", what, playerId, sent);
    return sent > 0;
}

int main(int argc, char **argv) {
    if (argc > 1) serverPort = (uint16_t)atoi(argv[1]);
    if (argc > 2) SERVER_ADDR = argv[2];

    fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) { perror("socket"); return 1; }

    in_addr saddr;
    inet_aton(SERVER_ADDR, &saddr);
    addr.sin_port = htons(serverPort);
    addr.sin_family = AF_INET;
    addr.sin_addr = saddr;

    buffer = (uint8_t *)aligned_alloc(4, 128);
    memset(buffer, 0, 128);

    // --- handshake ---
    Packets::Connect connect(0, 0);
    *(uint32_t *)buffer = ntohl((uint32_t)Packets::Tag::CONNECT);
    NetReturn res = connect.netWriteToBuffer(buffer + 4, 28);
    if (res.errorCode != NetReturn::OK) {
        fprintf(stderr, "[sonda] impossibile costruire CONNECT (%d)\n", res.errorCode);
        return 1;
    }
    sendto(fd, buffer, 4 + res.bytes, 0, (sockaddr *)&addr, sizeof addr);

    pollfd pfd = {fd, POLLIN, 0};
    poll(&pfd, 1, 2000);
    if (!(pfd.revents & POLLIN)) {
        fprintf(stderr, "[sonda] nessuna risposta dal server sulla porta %u\n", serverPort);
        return 1;
    }

    ssize_t amtRead = read(fd, buffer, 128);
    if (amtRead < 4 ||
        ntohl(*(const uint32_t *)buffer) != (uint32_t)Packets::Tag::SERVER_INITIAL_RESPONSE) {
        fprintf(stderr, "[sonda] risposta inattesa all'handshake\n");
        return 1;
    }

    Packets::ServerInitialResponse sip;
    res = Packets::ServerInitialResponse::netReadFromBuffer(&sip, buffer + 4, amtRead - 4);
    if (res.errorCode != NetReturn::OK) {
        fprintf(stderr, "[sonda] risposta illeggibile (%d)\n", res.errorCode);
        return 1;
    }

    uint8_t myId = sip.playerId;
    printf("[sonda] connesso, il server mi ha assegnato playerId=%u\n\n", myId);

    // --- caso 1: id fuori range (l'attacco) ---
    printf("--- caso 1: playerId fuori range ---\n");
    sendPosition(200, "posizione con id 200");
    usleep(300000);

    // --- caso 2: id legittimo (controllo di non-regressione) ---
    printf("\n--- caso 2: playerId legittimo ---\n");
    sendPosition(myId, "posizione con id corretto");
    usleep(300000);

    printf("\n[sonda] fatta. Controlla l'output del server qui sopra.\n");

    close(fd);
    return 0;
}
