// Verifica che il server rilanci davvero i pacchetti del mondo condiviso.
//
// Due client si collegano; il primo annuncia una moneta raccolta e un nemico
// ucciso, il secondo deve ricevere entrambi con i campi intatti. E' la prova
// che serve dopo aver fuso i due rami del server: che compili non basta.
//
//   relaytest [porta]

#include "packets/connect.hpp"
#include "packets/serverInitialResponse.hpp"
#include "packets/coin.hpp"
#include "packets/actorKill.hpp"
#include "netCommon.hpp"
#include "platform_net.hpp"

#include <cstdio>
#include <cstdlib>
#include <cstring>

static uint16_t port = 5029;
static int failures = 0;

static void setTimeout(int fd, int ms) {
#ifdef _WIN32
    DWORD tv = ms;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char *>(&tv), sizeof tv);
#else
    timeval tv;
    tv.tv_sec = ms / 1000;
    tv.tv_usec = (ms % 1000) * 1000;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
#endif
}

static sockaddr_in serverAddr() {
    sockaddr_in a;
    memset(&a, 0, sizeof a);
    a.sin_family = AF_INET;
    a.sin_port = htons(port);
    platform::parseIPv4("127.0.0.1", &a.sin_addr);
    return a;
}

template<typename T>
static int sendPacket(int fd, const T &packet, Packets::Tag tag) {
    uint8_t buf[128];
    memset(buf, 0, sizeof buf);
    *reinterpret_cast<uint32_t *>(buf) = ntohl(static_cast<uint32_t>(tag));
    NetReturn r = packet.netWriteToBuffer(buf + 4, sizeof buf - 4);
    if(r.errorCode != NetReturn::OK) return -1;
    sockaddr_in to = serverAddr();
    return static_cast<int>(sendto(fd, reinterpret_cast<const char *>(buf), 4 + r.bytes, 0,
                                   reinterpret_cast<const sockaddr *>(&to), sizeof to));
}

// Legge finche' non arriva il tag cercato, scartando il resto (il server
// manda anche posizioni e risposte di tempo).
static int recvTag(int fd, Packets::Tag want, uint8_t *out, int outLen) {
    for(int attempt = 0; attempt < 12; attempt++) {
        uint8_t buf[256];
        int n = recvfrom(fd, reinterpret_cast<char *>(buf), sizeof buf, 0, nullptr, nullptr);
        if(n < 4) return -1;
        uint32_t tag = ntohl(*reinterpret_cast<const uint32_t *>(buf));
        if(tag == static_cast<uint32_t>(want)) {
            int payload = n - 4;
            if(payload > outLen) payload = outLen;
            memcpy(out, buf + 4, payload);
            return payload;
        }
    }
    return -1;
}

static int connectClient(const char *label) {
    int fd = static_cast<int>(socket(AF_INET, SOCK_DGRAM, 0));
    if(fd < 0) { printf("  %s: socket non creato\n", label); failures++; return -1; }
    setTimeout(fd, 2000);

    if(sendPacket(fd, Packets::Connect(0, 0), Packets::Tag::CONNECT) < 0) {
        printf("  %s: invio della connessione fallito\n", label); failures++; return -1;
    }

    uint8_t payload[64];
    if(recvTag(fd, Packets::Tag::SERVER_INITIAL_RESPONSE, payload, sizeof payload) < 0) {
        printf("  %s: il server non ha risposto\n", label); failures++; return -1;
    }
    Packets::ServerInitialResponse sip;
    Packets::ServerInitialResponse::netReadFromBuffer(&sip, payload, sizeof payload);
    printf("  %s: collegato, id %u\n", label, sip.playerId);
    return (fd << 8) | sip.playerId;
}

int main(int argc, char **argv) {
    if(argc > 1) port = static_cast<uint16_t>(atoi(argv[1]));
    platform::setupLogging();
    if(!platform::netInit()) { printf("rete non inizializzata\n"); return 1; }

    printf("=== due client sulla porta %u ===\n", port);
    int a = connectClient("client A");
    int b = connectClient("client B");
    if(a < 0 || b < 0) return 1;
    int fdA = a >> 8, idA = a & 0xFF;
    int fdB = b >> 8;

    printf("\n=== moneta ===\n");
    Packets::CoinCollected coin;
    coin.playerId = static_cast<uint8_t>(idA);
    coin.coinIndex = 4242;
    sendPacket(fdA, coin, Packets::Tag::COIN_COLLECTED);

    uint8_t payload[64];
    int n = recvTag(fdB, Packets::Tag::COIN_COLLECTED, payload, sizeof payload);
    if(n < 0) {
        printf("  B non ha ricevuto niente: il rilancio non funziona\n"); failures++;
    } else {
        Packets::CoinCollected got;
        Packets::CoinCollected::netReadFromBuffer(&got, payload, n);
        printf("  B riceve: giocatore %u, moneta %u\n", got.playerId, got.coinIndex);
        if(got.playerId != idA || got.coinIndex != 4242) {
            printf("  campi alterati: atteso giocatore %d, moneta 4242\n", idA); failures++;
        }
    }

    printf("\n=== nemico ===\n");
    Packets::ActorKilled kill;
    kill.playerId = static_cast<uint8_t>(idA);
    kill.actorIndex = 77;
    kill.nameHash = 0xDEADBEEF;
    sendPacket(fdA, kill, Packets::Tag::ACTOR_KILLED);

    n = recvTag(fdB, Packets::Tag::ACTOR_KILLED, payload, sizeof payload);
    if(n < 0) {
        printf("  B non ha ricevuto niente: il rilancio non funziona\n"); failures++;
    } else {
        Packets::ActorKilled got;
        Packets::ActorKilled::netReadFromBuffer(&got, payload, n);
        printf("  B riceve: giocatore %u, attore %u, nome %08X\n",
               got.playerId, got.actorIndex, got.nameHash);
        if(got.playerId != idA || got.actorIndex != 77 || got.nameHash != 0xDEADBEEFu) {
            printf("  campi alterati\n"); failures++;
        }
    }

    printf("\n=== chi manda non deve ricevere il proprio eco ===\n");
    setTimeout(fdA, 400);
    n = recvTag(fdA, Packets::Tag::COIN_COLLECTED, payload, sizeof payload);
    printf(n < 0 ? "  A non riceve la propria moneta: giusto\n"
                 : "  A riceve la propria moneta: la contera' due volte\n");
    if(n >= 0) failures++;

    platform::closeSocket(fdA);
    platform::closeSocket(fdB);
    platform::netShutdown();

    printf("\n%s\n", failures == 0 ? "TUTTO A POSTO" : "CI SONO PROBLEMI");
    return failures == 0 ? 0 : 1;
}
