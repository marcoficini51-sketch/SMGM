// Ascolta il server e, per ogni giocatore, dice quanto sono lunghi i suoi
// pacchetti posizione, che pesi della camminata e che flag porta, e quanti
// pacchetti manda in ogni secondo.
//
// La cronologia serve a vedere se un giocatore continua a trasmettere in un
// momento preciso (per esempio durante il filmato di una stella): i secondi a
// zero sono secondi in cui la sua console non ha mandato niente.
//
//   sniff [indirizzo] [porta] [secondi]

#include "packets/connect.hpp"
#include "packets/serverInitialResponse.hpp"
#include "netCommon.hpp"
#include "platform_net.hpp"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <chrono>

constexpr int MAX_SECS = 600;

struct Seen {
    unsigned long n56 = 0, n72 = 0, other = 0;
    int32_t anm = -1;
    float w[4] = {0, 0, 0, 0};
    float wmin[4] = {9, 9, 9, 9}, wmax[4] = {-9, -9, -9, -9};
    unsigned long changes = 0;
    unsigned long hip = 0, spin = 0;   // pacchetti col flag schianto / piroetta
    unsigned short perSec[MAX_SECS] = {0};
    unsigned long star = 0; int starId = 0; unsigned starHash = 0;
    int vt = -1;                        // spia della vtable di PowerStar (byte 73)
    int dg[4] = {-1, -1, -1, -1};       // diagnosi della stella (byte 76..79)
    int envt = -1, enres = -1;           // nemici: vtable agganciate, esito (byte 90, 91)
    unsigned lastSeq = 0; unsigned long kills = 0, hits = 0;   // annunci di morte distinti
    unsigned long n124 = 0, pkSent = 0, nvSent = 0; int boss = -1; unsigned stage = 0;   // posizioni dei nemici
};

static float be32f(const uint8_t *p) {
    uint32_t v = (uint32_t)p[0] << 24 | (uint32_t)p[1] << 16 | (uint32_t)p[2] << 8 | p[3];
    float f;
    memcpy(&f, &v, 4);
    return f;
}

int main(int argc, char **argv) {
    const char *host = argc > 1 ? argv[1] : "127.0.0.1";
    uint16_t port = argc > 2 ? (uint16_t)atoi(argv[2]) : 5029;
    int secs = argc > 3 ? atoi(argv[3]) : 10;
    if (secs > MAX_SECS) secs = MAX_SECS;

    platform::setupLogging();
    platform::netInit();
    int fd = (int)socket(AF_INET, SOCK_DGRAM, 0);
    sockaddr_in addr;
    memset(&addr, 0, sizeof addr);
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    platform::parseIPv4(host, &addr.sin_addr);
#ifdef _WIN32
    DWORD tv = 500;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, (const char *)&tv, sizeof tv);
#else
    timeval tv{0, 500000};
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
#endif

    uint8_t buf[256];
    memset(buf, 0, sizeof buf);
    *(uint32_t *)buf = ntohl((uint32_t)Packets::Tag::CONNECT);
    NetReturn r = Packets::Connect(0, 0).netWriteToBuffer(buf + 4, 60);
    sendto(fd, (const char *)buf, 4 + r.bytes, 0, (const sockaddr *)&addr, sizeof addr);
    int n = recvfrom(fd, (char *)buf, sizeof buf, 0, nullptr, nullptr);
    if (n < 4) { printf("il server non risponde su %s:%u\n", host, port); return 1; }
    Packets::ServerInitialResponse sip;
    Packets::ServerInitialResponse::netReadFromBuffer(&sip, buf + 4, n - 4);
    printf("in ascolto come slot %u per %d secondi\n\n", sip.playerId, secs);

    static Seen seen[8];
    const auto start = std::chrono::steady_clock::now();
    const auto end = start + std::chrono::seconds(secs);
    while (std::chrono::steady_clock::now() < end) {
        n = recvfrom(fd, (char *)buf, sizeof buf, 0, nullptr, nullptr);
        if (n < 5) continue;
        if (ntohl(*(uint32_t *)buf) != (uint32_t)Packets::Tag::PLAYER_POSITION) continue;
        uint8_t id = buf[4];
        if (id >= 8) continue;
        Seen &s = seen[id];
        int sec = (int)std::chrono::duration_cast<std::chrono::seconds>(
            std::chrono::steady_clock::now() - start).count();
        if (sec >= 0 && sec < secs) s.perSec[sec]++;
        int len = n - 4;
        if (len == 56) s.n56++;
        else if (len >= 72) s.n72++;          // 72: pesi; 76: pesi + annuncio stella
        else s.other++;
        if (len >= 76) s.vt = buf[4 + 73];
        if (len >= 80) for (int k = 0; k < 4; k++) s.dg[k] = buf[4 + 76 + k];
        if (len >= 92) {
            if (len >= 124) { s.envt = 0; s.enres = buf[4 + 77]; }     // 90..91 = tipo e sensore
            else { s.envt = buf[4 + 90]; s.enres = buf[4 + 91]; }
            unsigned seq = (unsigned)(buf[4 + 88] << 8 | buf[4 + 89]);
            if (seq && seq != s.lastSeq) {
                s.lastSeq = seq;
                if (len >= 124 && buf[4 + 90] != 0) s.hits++; else s.kills++;
            }
        }
        if (len >= 124) {
            s.n124++; s.boss = buf[4 + 76];
            s.stage = (unsigned)(buf[4 + 78] << 8 | buf[4 + 79]);
            if (ntohl(*(uint32_t *)(buf + 4 + 92)) != 0xFFFFFFFFu) s.pkSent++;
            if (ntohl(*(uint32_t *)(buf + 4 + 112)) != 0xFFFFFFFFu) s.nvSent++;
        }
        if (len >= 76 && buf[4 + 72] != 0) {
            s.star++;
            s.starId = buf[4 + 72];
            s.starHash = (uint16_t)(buf[4 + 74] << 8 | buf[4 + 75]);
        }
        s.anm = (int32_t)ntohl(*(uint32_t *)(buf + 4 + 44));
        if (buf[5] & 0x01) s.hip++;
        if (buf[5] & 0x02) s.spin++;
        if (len >= 72) {
            float w[4];
            for (int i = 0; i < 4; i++) {
                w[i] = be32f(buf + 4 + 56 + 4 * i);
                if (w[i] < s.wmin[i]) s.wmin[i] = w[i];
                if (w[i] > s.wmax[i]) s.wmax[i] = w[i];
            }
            if (memcmp(w, s.w, sizeof w) != 0) s.changes++;
            memcpy(s.w, w, sizeof w);
        }
    }

    bool any = false;
    for (int i = 0; i < 8; i++) {
        Seen &s = seen[i];
        if (s.n56 + s.n72 + s.other == 0) continue;
        any = true;
        printf("slot %d: %lu pacchetti da 56 byte, %lu da 72, %lu d'altra lunghezza; animazione %d\n",
               i, s.n56, s.n72, s.other, s.anm);
        printf("        flag: %lu pacchetti con lo schianto, %lu con la piroetta\n", s.hip, s.spin);
        if (s.vt >= 0)
            printf("        vtable PowerStar: %s\n", s.vt == 2 ? "trovata e agganciata" :
                   s.vt == 1 ? "CERCATA E NON TROVATA" : "non ancora cercata");
        if (s.n124) {
            printf("        posizioni nemici: %lu pacchetti da 124, galassia %04X, cutscene viste %d, %lu posizioni e %lu stati mandati\n",
                   s.n124, s.stage, s.boss, s.pkSent, s.nvSent);
        } else if (s.dg[3] >= 0) {
            static const char *esito[] = {"nessuno ancora", "altra galassia", "niente PowerStarHolder",
                "stella non presente nella scena", "stella vuota", "COMPARSA E SPOSTATA ADDOSSO"};
            printf("        diagnosi stella: ricevuta %d, esaminata %d, esito %d (%s), giri di StarTick %d\n",
                   s.dg[2], s.dg[0], s.dg[1], s.dg[1] >= 0 && s.dg[1] <= 5 ? esito[s.dg[1]] : "?", s.dg[3]);
        }
        if (s.envt >= 0) {
            static const char *en[] = {"nessuno ancora", "altra galassia", "nemico non trovato",
                "gia' morto o non valido", "UCCISO", "COLPO RIPETUTO", "colpo non ripetuto (non comanda o sensore assente)"};
            printf("        nemici: %lu morti e %lu colpi annunciati, esito ultimo ricevuto %d (%s)\n",
                   s.kills, s.hits, s.enres, s.enres >= 0 && s.enres <= 6 ? en[s.enres] : "?");
        }
        if (s.star) printf("        stella: %lu pacchetti annunciano la stella %d (galassia %04X)\n", s.star, s.starId, s.starHash);
        if (s.n72) {
            printf("        pesi ultimi  [%.3f %.3f %.3f %.3f]\n", s.w[0], s.w[1], s.w[2], s.w[3]);
            printf("        cambiati %lu volte\n", s.changes);
        }
        printf("        pacchetti al secondo:");
        for (int t = 0; t < secs; t++) {
            if (t % 10 == 0) printf("\n          %3ds:", t);
            printf(" %3u", s.perSec[t]);
        }
        printf("\n");
    }
    if (!any) printf("nessuno sta trasmettendo posizioni\n");
    platform::closeSocket(fd);
    platform::netShutdown();
    return 0;
}
