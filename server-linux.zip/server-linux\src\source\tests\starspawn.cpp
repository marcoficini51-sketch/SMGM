// Annuncia a tutti i giocatori una stella, come se qualcuno l'avesse appena
// presa: a chi ce l'ha nella propria scena la stella compare addosso e la
// prende. Serve a provare la stella condivisa senza finire un livello.
//
// Si collega come un giocatore qualsiasi e manda per qualche secondo pacchetti
// posizione da 76 byte con [numero, 0, 0xFF, 0xFF] in coda: 0xFFFF e'
// l'impronta "jolly", accettata in qualsiasi galassia. Poi manda qualche
// pacchetto senza stella, cosi' chi riceve considera l'evento finito e il
// prossimo tasto funziona di nuovo. Il giocatore finto sta molto sotto la
// mappa, per non vedersi e non toccare nessuno.
//
//   starspawn porta numero [secondi]

#include "packets/connect.hpp"
#include "packets/serverInitialResponse.hpp"
#include "packets/playerPosition.hpp"
#include "netCommon.hpp"
#include "platform_net.hpp"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <chrono>
#include <thread>

int main(int argc, char **argv) {
    if (argc < 3) { printf("uso: starspawn porta numero [secondi]\n"); return 2; }
    uint16_t port = (uint16_t)atoi(argv[1]);
    int star = atoi(argv[2]);
    int secs = argc > 3 ? atoi(argv[3]) : 2;
    if (star < 0 || star > 255) { printf("il numero della stella va da 1 a 255 (0 = dalla 1 alla 7)\n"); return 2; }

    platform::setupLogging();
    platform::netInit();
    int fd = (int)socket(AF_INET, SOCK_DGRAM, 0);
    sockaddr_in addr;
    memset(&addr, 0, sizeof addr);
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    platform::parseIPv4("127.0.0.1", &addr.sin_addr);
#ifdef _WIN32
    DWORD tv = 2000;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, (const char *)&tv, sizeof tv);
#else
    timeval tv{2, 0};
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
#endif

    uint8_t buf[128];
    memset(buf, 0, sizeof buf);
    *(uint32_t *)buf = ntohl((uint32_t)Packets::Tag::CONNECT);
    NetReturn r = Packets::Connect(0, 0).netWriteToBuffer(buf + 4, 60);
    sendto(fd, (const char *)buf, 4 + r.bytes, 0, (const sockaddr *)&addr, sizeof addr);
    int n = recvfrom(fd, (char *)buf, sizeof buf, 0, nullptr, nullptr);
    if (n < 4 || ntohl(*(uint32_t *)buf) != (uint32_t)Packets::Tag::SERVER_INITIAL_RESPONSE) {
        printf("il server non risponde sulla porta %u (acceso? pieno?)\n", port);
        return 1;
    }
    Packets::ServerInitialResponse sip;
    Packets::ServerInitialResponse::netReadFromBuffer(&sip, buf + 4, n - 4);

    auto send = [&](int id) {
        uint8_t out[128];
        memset(out, 0, sizeof out);
        Packets::PlayerPosition p;
        p.playerId = sip.playerId;
        p.position = {0.0f, -100000.0f, 0.0f};
        p.velocity = {0.0f, 0.0f, 0.0f};
        p.direction = {1.0f, 0.0f, 0.0f};
        p.currentAnimation = -1;
        p.defaultAnimation = -1;
        p.animationSpeed = 1.0f;
        *(uint32_t *)out = ntohl((uint32_t)Packets::Tag::PLAYER_POSITION);
        NetReturn w = p.netWriteToBuffer(out + 4, 120);
        int len = 4 + (int)w.bytes;          // 56 di posizione
        len += 16;                           // pesi a zero
        out[len + 0] = (uint8_t)id;          // numero della stella (0 = nessuna)
        out[len + 1] = 0;
        out[len + 2] = id ? 0xFF : 0;        // impronta jolly
        out[len + 3] = id ? 0xFF : 0;
        len += 4;
        sendto(fd, (const char *)out, len, 0, (const sockaddr *)&addr, sizeof addr);
    };

    // 0 = prova le stelle da 1 a 7, mezzo secondo ciascuna: a chi ha nella
    // scena la stella della propria missione, quella compare e la prende.
    int sent = 0;
    int first = star ? star : 1, last = star ? star : 7;
    for (int s = first; s <= last; s++) {
        auto end = std::chrono::steady_clock::now() +
                   (star ? std::chrono::milliseconds(secs * 1000) : std::chrono::milliseconds(500));
        while (std::chrono::steady_clock::now() < end) {
            send(s);
            sent++;
            std::this_thread::sleep_for(std::chrono::milliseconds(16));
        }
    }
    for (int i = 0; i < 30; i++) {           // evento finito
        send(0);
        std::this_thread::sleep_for(std::chrono::milliseconds(16));
    }
    if (star) printf("stella %d annunciata a tutti (%d pacchetti, come giocatore %u)\n", star, sent, sip.playerId);
    else printf("stelle da 1 a 7 annunciate a tutti (%d pacchetti, come giocatore %u)\n", sent, sip.playerId);
    platform::closeSocket(fd);
    platform::netShutdown();
    return 0;
}
