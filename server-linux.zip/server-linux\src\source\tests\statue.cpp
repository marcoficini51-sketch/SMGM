// Puppet fermo: si piazza accanto al giocatore vero e non si muove piu'.
//
// Serve a collaudare il calpestamento fra giocatori. Tre accortezze:
//
//  - velocita' ZERO: il mod confronta velocita'*gravita' fra i due giocatori
//    per decidere chi schiaccia chi. Se copiassimo la velocita' del giocatore
//    vero il confronto darebbe sempre pari e non succederebbe niente.
//  - timestamp CRESCENTE: il mod scarta i pacchetti con timestamp non
//    successivo all'ultimo ricevuto, quindi va copiato quello in arrivo.
//  - orientamento congelato: cosi' il puppet resta in piedi rispetto alla
//    gravita' locale del punto in cui l'abbiamo parcheggiato.
//
//   statue [porta] [dx] [dy] [dz] [secondi_prima_di_fermarsi]

#include "packets/connect.hpp"
#include "packets/serverInitialResponse.hpp"
#include "packets/playerPosition.hpp"
#include "netCommon.hpp"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <csignal>

extern "C" {
#include <poll.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/socket.h>
}

static volatile sig_atomic_t running = 1;
static void onSignal(int) { running = 0; }

int main(int argc, char **argv) {
    uint16_t serverPort = (argc > 1) ? (uint16_t)atoi(argv[1]) : 5029;
    float dx = (argc > 2) ? atof(argv[2]) : 250.0f;
    float dy = (argc > 3) ? atof(argv[3]) : 0.0f;
    float dz = (argc > 4) ? atof(argv[4]) : 0.0f;
    int waitSec = (argc > 5) ? atoi(argv[5]) : 3;

    signal(SIGINT, onSignal);
    signal(SIGTERM, onSignal);
    setvbuf(stdout, nullptr, _IOLBF, 0);

    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) { perror("socket"); return 1; }

    in_addr saddr;
    inet_aton("127.0.0.1", &saddr);
    sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(serverPort);
    addr.sin_addr = saddr;

    uint8_t *buffer = (uint8_t *)aligned_alloc(4, 128);
    memset(buffer, 0, 128);

    Packets::Connect connect(0, 0);
    *(uint32_t *)buffer = ntohl((uint32_t)Packets::Tag::CONNECT);
    NetReturn res = connect.netWriteToBuffer(buffer + 4, 28);
    if (res.errorCode != NetReturn::OK) { fprintf(stderr, "CONNECT ko\n"); return 1; }
    sendto(fd, buffer, 4 + res.bytes, 0, (sockaddr *)&addr, sizeof addr);

    pollfd pfd = {fd, POLLIN, 0};
    poll(&pfd, 1, 3000);
    if (!(pfd.revents & POLLIN)) { fprintf(stderr, "server muto sulla porta %u\n", serverPort); return 1; }

    ssize_t n = read(fd, buffer, 128);
    if (n < 4 || ntohl(*(const uint32_t *)buffer) != (uint32_t)Packets::Tag::SERVER_INITIAL_RESPONSE) {
        fprintf(stderr, "handshake fallito\n"); return 1;
    }
    Packets::ServerInitialResponse sip;
    Packets::ServerInitialResponse::netReadFromBuffer(&sip, buffer + 4, n - 4);
    uint8_t myId = sip.playerId;
    printf("connesso come playerId=%u\n", myId);
    printf("mi piazzo fra %d secondi a offset (%.0f, %.0f, %.0f) dal punto in cui sarai\n\n",
           waitSec, dx, dy, dz);

    bool frozen = false;
    unsigned long pkts = 0, sent = 0;
    const unsigned long freezeAt = (unsigned long)waitSec * 60;

    Vec parkPos{}, parkDir{};
    int32_t parkAnm = -1, parkDefAnm = -1;

    while (running) {
        pfd.events = POLLIN;
        pfd.revents = 0;
        if (poll(&pfd, 1, 1000) <= 0) {
            if (pkts == 0) printf("...in attesa del giocatore vero\n");
            continue;
        }

        n = read(fd, buffer, 128);
        if (n < 4) continue;
        if (ntohl(*(const uint32_t *)buffer) != (uint32_t)Packets::Tag::PLAYER_POSITION) continue;

        Packets::PlayerPosition in;
        if (Packets::PlayerPosition::netReadFromBuffer(&in, buffer + 4, n - 4).errorCode != NetReturn::OK) continue;
        if (in.playerId == myId) continue;

        pkts++;

        if (!frozen) {
            // ignoro le posizioni a zero: sono i frame di caricamento
            bool atOrigin = in.position.x == 0.0f && in.position.y == 0.0f && in.position.z == 0.0f;
            if (!atOrigin && pkts >= freezeAt) {
                parkPos = in.position;
                parkPos.x += dx; parkPos.y += dy; parkPos.z += dz;
                parkDir = in.direction;
                parkAnm = in.currentAnimation;
                parkDefAnm = in.defaultAnimation;
                frozen = true;
                printf("PIAZZATO a [%.0f %.0f %.0f]\n", parkPos.x, parkPos.y, parkPos.z);
                printf("(tu eri a [%.0f %.0f %.0f])\n", in.position.x, in.position.y, in.position.z);
                printf("\nOra saltagli sopra: dovresti rimbalzare.\n\n");
            }
        }

        Packets::PlayerPosition out;
        out.playerId = myId;
        out.timestamp = in.timestamp;          // deve avanzare, se no viene scartato
        out.stateFlags = 0;                    // niente sedere a terra
        if (frozen) {
            out.position = parkPos;
            out.velocity = {0.0f, 0.0f, 0.0f}; // fermo: e' questo che fa vincere te
            out.direction = parkDir;
            out.currentAnimation = parkAnm;
            out.defaultAnimation = parkDefAnm;
            out.animationSpeed = 0.0f;
        } else {
            out.position = in.position;
            out.position.x += dx; out.position.y += dy; out.position.z += dz;
            out.velocity = in.velocity;
            out.direction = in.direction;
            out.currentAnimation = in.currentAnimation;
            out.defaultAnimation = in.defaultAnimation;
            out.animationSpeed = in.animationSpeed;
        }

        *(uint32_t *)buffer = ntohl((uint32_t)Packets::Tag::PLAYER_POSITION);
        res = out.netWriteToBuffer(buffer + 4, 60);
        if (res.errorCode != NetReturn::OK) continue;
        sendto(fd, buffer, 4 + res.bytes, 0, (sockaddr *)&addr, sizeof addr);
        sent++;

        if (frozen && sent % 600 == 0) {
            printf("[fermo · %lu inviati] tu sei a [%.0f %.0f %.0f], distanza %.0f\n",
                   sent, in.position.x, in.position.y, in.position.z,
                   __builtin_sqrtf((in.position.x - parkPos.x) * (in.position.x - parkPos.x) +
                                   (in.position.y - parkPos.y) * (in.position.y - parkPos.y) +
                                   (in.position.z - parkPos.z) * (in.position.z - parkPos.z)));
        }
    }

    printf("\nchiuso. ricevuti %lu, inviati %lu\n", pkts, sent);
    close(fd);
    return 0;
}
