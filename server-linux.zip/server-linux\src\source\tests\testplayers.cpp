// Test mode: una fila di Mario che ti seguono a distanza di tempo.
//
// Un solo processo apre N connessioni al server, riconosce il giocatore
// vero (l'unico id che non e' suo) e ritrasmette la sua posizione ritardata
// di 120 ms, 240 ms, 360 ms... una per copia.
//
// I ritardi sono cumulativi rispetto al giocatore vero, non a catena fra le
// copie: il risultato a schermo e' lo stesso, ma senza accumulo di errore.
//
//   testplayers [porta] [numero_copie] [passo_ms]

#include "packets/connect.hpp"
#include "packets/serverInitialResponse.hpp"
#include "packets/playerPosition.hpp"
#include "netCommon.hpp"
#include "platform_net.hpp"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <csignal>
#include <chrono>

using Clock = std::chrono::steady_clock;

static const int MAX_COPIES = 7;   // 8 slot totali, uno e' del giocatore vero
static const int RING = 1024;      // ~17 secondi a 60 Hz

struct Sample {
    Clock::time_point t;
    Vec pos, vel, dir;
    int32_t anm, defAnm;
    float anmSpeed;
    // i 16 byte dopo i 56 del pacchetto: i pesi della camminata, se il mod
    // li manda. Vanno ripetuti tali e quali, se no i Mario finti scivolano.
    uint8_t weights[16];
    bool hasWeights;
    uint8_t flags;
    bool valid;
};


static Sample ring[RING];
static int head = 0;

static volatile sig_atomic_t running = 1;
static void onSignal(int) { running = 0; }

// Risale il percorso realmente compiuto accumulando la distanza fra campioni
// consecutivi, e restituisce il punto che dista `want` unita' CAMMINANDO
// all'indietro lungo quella traiettoria.
//
// E' il motivo per cui le copie inseguono invece di essere piazzate: seguono
// la strada fatta, curve comprese, e su un pianeta sferico restano aderenti
// al terreno invece di tagliare in linea retta dentro la collina.
static const Sample *findAtPathDistance(float want) {
    int idx = (head - 1 + RING) % RING;
    if (!ring[idx].valid) return nullptr;

    const Sample *last = &ring[idx];
    float walked = 0.0f;

    for (int n = 0; n < RING - 1; n++) {
        int prev = (idx - 1 + RING) % RING;
        if (!ring[prev].valid) break;

        float dx = ring[idx].pos.x - ring[prev].pos.x;
        float dy = ring[idx].pos.y - ring[prev].pos.y;
        float dz = ring[idx].pos.z - ring[prev].pos.z;
        float seg = __builtin_sqrtf(dx * dx + dy * dy + dz * dz);

        // Un salto enorme fra due campioni consecutivi non e' cammino: e' un
        // teletrasporto (cambio di stella, warp, respawn). Fermo qui, se no
        // la fila si sparpaglia attraverso mezza galassia.
        if (seg > 800.0f) break;

        walked += seg;
        last = &ring[prev];
        if (walked >= want) return last;

        idx = prev;
    }
    return last;   // percorso ancora troppo corto: sto sul piu' vecchio noto
}

int main(int argc, char **argv) {
    uint16_t port      = (argc > 1) ? (uint16_t)atoi(argv[1]) : 5029;
    float spacing      = (argc > 2) ? (float)atof(argv[2]) : 140.0f;
    const char *ctlPath = (argc > 3) ? argv[3] : nullptr;

    if (spacing < 20.0f) spacing = 20.0f;
    if (spacing > 2000.0f) spacing = 2000.0f;

    // Le connessioni si aprono UNA VOLTA SOLA, tutte subito. Prima ne
    // riaprivo un gruppo nuovo a ogni cambio di numero, abbandonando le
    // precedenti: gli otto slot del server si esaurivano in quattro giri.
    int copies = MAX_COPIES;
    int active = 1;

    signal(SIGINT, onSignal);
    signal(SIGTERM, onSignal);
    platform::setupLogging();

    if (!platform::netInit()) { printf("rete non inizializzabile\n"); return 1; }

    in_addr target;
    platform::parseIPv4("127.0.0.1", &target);
    sockaddr_in addr;
    memset(&addr, 0, sizeof addr);
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr = target;

    int   fds[MAX_COPIES];
    uint8_t ids[MAX_COPIES];
    int   opened = 0;

    uint8_t *buf = static_cast<uint8_t *>(platform::alignedAlloc(4, 128));

    for (int k = 0; k < copies; k++) {
        int fd = static_cast<int>(socket(AF_INET, SOCK_DGRAM, 0));
        if (fd < 0) break;
        platform::configureUdpSocket(fd);

#ifdef _WIN32
        DWORD tv = 2000;
        setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char *>(&tv), sizeof tv);
#else
        timeval tv; tv.tv_sec = 2; tv.tv_usec = 0;
        setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
#endif
        memset(buf, 0, 128);
        Packets::Connect connect(0, 0);
        *reinterpret_cast<uint32_t *>(buf) = ntohl((uint32_t)Packets::Tag::CONNECT);
        NetReturn r = connect.netWriteToBuffer(buf + 4, 28);
        sendto(fd, reinterpret_cast<const char *>(buf), 4 + r.bytes, 0,
               reinterpret_cast<const sockaddr *>(&addr), sizeof addr);

        int n = recvfrom(fd, reinterpret_cast<char *>(buf), 128, 0, nullptr, nullptr);
        if (n < 4 || ntohl(*reinterpret_cast<const uint32_t *>(buf)) !=
                (uint32_t)Packets::Tag::SERVER_INITIAL_RESPONSE) {
            printf("copia %d rifiutata: slot esauriti sul server\n", k + 1);
            platform::closeSocket(fd);
            break;
        }
        Packets::ServerInitialResponse sip;
        Packets::ServerInitialResponse::netReadFromBuffer(&sip, buf + 4, n - 4);
        fds[opened] = fd;
        ids[opened] = sip.playerId;
        opened++;
        printf("connessione %d pronta (slot %u) - seguira' a %.0f unita'\n",
               opened, sip.playerId, opened * spacing);
    }

    if (opened == 0) {
        printf("\nNessuna copia collegata. Il server e' acceso e ha slot liberi?\n");
        return 1;
    }

    printf("\n%d connessioni pronte. Muoviti in gioco. Ctrl+C per fermare.\n\n", opened);

    // Il file contiene "<quanti> [<spaziatura> [<stella> <progressivo>]]". La
    // spaziatura si puo' cambiare mentre gira. Stella e progressivo li scrive
    // il tasto "Stella per tutti": a ogni progressivo nuovo il primo Mario
    // finto annuncia la stella (0 = dalla 1 alla 7, mezzo secondo ciascuna).
    // Lo fa lui perche' ha gia' una connessione aperta: un programma a parte
    // dovrebbe trovare uno slot libero, e coi Test player accesi non c'e'.
    int starSeq = 0;
    bool starBaseline = false;       // il primo valore letto non si esegue
    int sched[8];
    int schedLen = 0, schedPos = 0, schedLeft = 0;
    const int STAR_PKTS = 30;
    auto readControl = [&]() {
        if (!ctlPath) return;
        FILE *f = fopen(ctlPath, "r");
        if (!f) return;
        int v = 0;
        float sp = 0.0f;
        int star = -1, seq = 0;
        int fields = fscanf(f, "%d %f %d %d", &v, &sp, &star, &seq);
        fclose(f);
        if (fields < 1) return;

        if (fields >= 4) {
            if (!starBaseline) {
                starSeq = seq;
            } else if (seq != starSeq && star >= 0 && star <= 255) {
                starSeq = seq;
                schedLen = 0;
                if (star == 0) for (int s = 1; s <= 7; s++) sched[schedLen++] = s;
                else sched[schedLen++] = star;
                schedPos = 0;
                schedLeft = STAR_PKTS;
                printf("--> annuncio stella %s\n", star == 0 ? "da 1 a 7" : std::to_string(star).c_str());
                fflush(stdout);
            }
        }
        starBaseline = true;

        if (v < 0) v = 0;
        if (v > opened) v = opened;
        if (v != active) {
            active = v;
            printf("--> ora ne animo %d\n", active);
        }
        if (fields >= 2 && sp >= 20.0f && sp <= 2000.0f && sp != spacing) {
            spacing = sp;
            printf("--> spaziatura %.0f unita'\n", spacing);
        }
    };
    readControl();
    auto nextCtlCheck = Clock::now();

    auto isMine = [&](uint8_t id) {
        for (int i = 0; i < opened; i++) if (ids[i] == id) return true;
        return false;
    };

    unsigned long got = 0, sent = 0;

    while (running) {
        // il file di controllo si rilegge anche quando non arriva niente: se
        // no una richiesta resterebbe li' finche' qualcuno non si muove
        if (Clock::now() >= nextCtlCheck) {
            readControl();
            nextCtlCheck = Clock::now() + std::chrono::milliseconds(400);
        }

        fd_set rd;
        FD_ZERO(&rd);
        int maxfd = 0;
        for (int i = 0; i < opened; i++) {
            FD_SET((SOCKET_T)fds[i], &rd);
            if (fds[i] > maxfd) maxfd = fds[i];
        }
        timeval to; to.tv_sec = 0; to.tv_usec = 200000;
        if (select(maxfd + 1, &rd, nullptr, nullptr, &to) <= 0) continue;

        bool fresh = false;
        Packets::PlayerPosition latest;

        for (int i = 0; i < opened; i++) {
            if (!FD_ISSET((SOCKET_T)fds[i], &rd)) continue;
            int n = recvfrom(fds[i], reinterpret_cast<char *>(buf), 128, 0, nullptr, nullptr);
            if (n < 4) continue;
            if (ntohl(*reinterpret_cast<const uint32_t *>(buf)) !=
                    (uint32_t)Packets::Tag::PLAYER_POSITION) continue;

            Packets::PlayerPosition in;
            if (Packets::PlayerPosition::netReadFromBuffer(&in, buf + 4, n - 4).errorCode
                    != NetReturn::OK) continue;
            if (isMine(in.playerId)) continue;   // e' una nostra copia
            if (in.position.x == 0.0f && in.position.y == 0.0f && in.position.z == 0.0f) continue;

            // solo dal socket 0, se no lo stesso pacchetto entra N volte
            if (i != 0) continue;

            Sample &s = ring[head];
            s.t = Clock::now();
            s.pos = in.position; s.vel = in.velocity; s.dir = in.direction;
            s.anm = in.currentAnimation; s.defAnm = in.defaultAnimation;
            s.anmSpeed = in.animationSpeed; s.flags = in.stateFlags;
            s.hasWeights = (n - 4) >= 72;
            if (s.hasWeights) memcpy(s.weights, buf + 4 + 56, 16);
            s.valid = true;
            head = (head + 1) % RING;

            latest = in;
            fresh = true;
            got++;
        }

        if (!fresh) continue;

        for (int k = 0; k < active; k++) {
            const Sample *old = findAtPathDistance((k + 1) * spacing);
            if (!old) continue;

            Packets::PlayerPosition out;
            out.playerId = ids[k];
            out.timestamp = latest.timestamp;     // sempre il piu' recente

            // Nessun offset artificiale: la posizione e' un punto in cui sei
            // davvero passato, quindi e' per costruzione sul terreno.
            out.position = old->pos;
            out.velocity = old->vel;
            out.direction = old->dir;
            out.currentAnimation = old->anm;
            out.defaultAnimation = old->defAnm;
            out.animationSpeed = old->anmSpeed;
            out.stateFlags = old->flags;

            *reinterpret_cast<uint32_t *>(buf) = ntohl((uint32_t)Packets::Tag::PLAYER_POSITION);
            NetReturn r = out.netWriteToBuffer(buf + 4, 60);
            if (r.errorCode != NetReturn::OK) continue;
            int len = 4 + static_cast<int>(r.bytes);
            bool announce = (k == 0 && schedPos < schedLen);
            if (old->hasWeights) {
                memcpy(buf + len, old->weights, 16);
                len += 16;
            } else if (announce) {
                memset(buf + len, 0, 16);       // l'annuncio sta ai byte 72..75
                len += 16;
            }
            if (announce) {
                buf[len + 0] = (uint8_t)sched[schedPos];
                buf[len + 1] = 0;
                buf[len + 2] = 0xFF;            // impronta jolly: qualsiasi galassia
                buf[len + 3] = 0xFF;
                len += 4;
                if (--schedLeft == 0) {
                    schedPos++;
                    schedLeft = STAR_PKTS;
                    if (schedPos == schedLen) printf("--> annuncio finito\n");
                }
            }
            sendto(fds[k], reinterpret_cast<const char *>(buf), len, 0,
                   reinterpret_cast<const sockaddr *>(&addr), sizeof addr);
            sent++;
        }

        if (got % 300 == 0) {
            printf("[%lu ricevuti / %lu inviati] %d in fila, l'ultimo a %.0f unita'\n",
                   got, sent, active, active * spacing);
        }
    }

    printf("\nfermato. ricevuti %lu, inviati %lu\n", got, sent);
    for (int i = 0; i < opened; i++) platform::closeSocket(fds[i]);
    platform::alignedFree(buf);
    platform::netShutdown();
    return 0;
}
