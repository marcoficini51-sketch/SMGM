// Prova del teletrasporto lato server.
//
// Si scrive lo slot di A nel file di controllo, come fa il pannello: il file
// deve sparire e i pacchetti di A inoltrati a B devono portare il bit 0x04 per
// un po' (e poi basta), mentre quelli di B ad A no.
//
//   tptest porta file_di_controllo

#include "packets/connect.hpp"
#include "packets/serverInitialResponse.hpp"
#include "packets/playerPosition.hpp"
#include "netCommon.hpp"
#include "platform_net.hpp"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <chrono>
#include <thread>

static uint16_t port;
static int failures = 0;

static sockaddr_in serverAddr() {
    sockaddr_in a;
    memset(&a, 0, sizeof a);
    a.sin_family = AF_INET;
    a.sin_port = htons(port);
    platform::parseIPv4("127.0.0.1", &a.sin_addr);
    return a;
}

static int connectClient(uint8_t *id) {
    int fd = (int)socket(AF_INET, SOCK_DGRAM, 0);
#ifdef _WIN32
    DWORD tv = 1000;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, (const char *)&tv, sizeof tv);
#else
    timeval tv{1, 0};
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
#endif
    uint8_t buf[128] = {0};
    *(uint32_t *)buf = ntohl((uint32_t)Packets::Tag::CONNECT);
    NetReturn r = Packets::Connect(0, 0).netWriteToBuffer(buf + 4, 60);
    sockaddr_in to = serverAddr();
    sendto(fd, (const char *)buf, 4 + r.bytes, 0, (const sockaddr *)&to, sizeof to);
    int n = recvfrom(fd, (char *)buf, sizeof buf, 0, nullptr, nullptr);
    if(n < 4) return -1;
    Packets::ServerInitialResponse sip;
    Packets::ServerInitialResponse::netReadFromBuffer(&sip, buf + 4, n - 4);
    *id = sip.playerId;
    return fd;
}

static int roundTrip(int a, uint8_t idA, int b) {
    uint8_t buf[128] = {0};
    Packets::PlayerPosition p;
    p.playerId = idA;
    p.position = {1.0f, 2.0f, 3.0f};
    p.velocity = {0, 0, 0};
    p.direction = {1, 0, 0};
    p.currentAnimation = 0; p.defaultAnimation = 0; p.animationSpeed = 1.0f;
    p.stateFlags = 0;
    *(uint32_t *)buf = ntohl((uint32_t)Packets::Tag::PLAYER_POSITION);
    NetReturn r = p.netWriteToBuffer(buf + 4, 120);
    sockaddr_in to = serverAddr();
    sendto(a, (const char *)buf, 4 + r.bytes, 0, (const sockaddr *)&to, sizeof to);
    for(int i = 0; i < 20; i++) {
        int n = recvfrom(b, (char *)buf, sizeof buf, 0, nullptr, nullptr);
        if(n < 6) return -1;
        if(ntohl(*(uint32_t *)buf) != (uint32_t)Packets::Tag::PLAYER_POSITION) continue;
        if(buf[4] != idA) continue;
        return buf[5];
    }
    return -1;
}

static void check(const char *what, bool ok) {
    printf("  %-56s %s\n", what, ok ? "ok" : "NO");
    if(!ok) failures++;
}

int main(int argc, char **argv) {
    if(argc < 3) { printf("uso: tptest porta file_di_controllo\n"); return 2; }
    port = (uint16_t)atoi(argv[1]);
    const char *ctl = argv[2];
    platform::setupLogging();
    platform::netInit();

    uint8_t idA, idB;
    int a = connectClient(&idA), b = connectClient(&idB);
    if(a < 0 || b < 0) { printf("handshake fallito\n"); return 1; }

    check("prima: niente bit 0x04", roundTrip(a, idA, b) == 0);

    FILE *f = fopen(ctl, "wb");
    fprintf(f, "%u", idA);
    fclose(f);
    std::this_thread::sleep_for(std::chrono::milliseconds(500));
    roundTrip(a, idA, b);                       // fa scattare la lettura
    std::this_thread::sleep_for(std::chrono::milliseconds(300));
    roundTrip(a, idA, b);
    FILE *g = fopen(ctl, "rb");
    check("il server ha letto e cancellato il file", g == nullptr);
    if(g) fclose(g);

    int with = 0, total = 0;
    for(int i = 0; i < 120; i++) {
        int fl = roundTrip(a, idA, b);
        if(fl < 0) continue;
        total++;
        if(fl & 0x04) with++;
    }
    printf("  %d pacchetti di A arrivati a B, %d col bit 0x04\n", total, with);
    check("il bit c'e' per un po'", with >= 60);
    check("e poi smette", with < total);
    check("i pacchetti di B ad A restano senza bit", roundTrip(b, idB, a) == 0);

    platform::closeSocket(a);
    platform::closeSocket(b);
    platform::netShutdown();
    printf("\n%s\n", failures ? "CI SONO PROBLEMI" : "TUTTO A POSTO");
    return failures ? 1 : 0;
}
