// Verifica che un pacchetto posizione allungato (56 byte + 16 di pesi della
// camminata) attraversi il server intatto, e che quello vecchio da 56 passi
// ancora.
//
// Il server legge solo i primi 56 byte e inoltra la lunghezza ricevuta: e'
// quello che dice il sorgente, qui lo si guarda succedere.
//
//   weighttest [porta]

#include "packets/connect.hpp"
#include "packets/serverInitialResponse.hpp"
#include "packets/playerPosition.hpp"
#include "netCommon.hpp"
#include "platform_net.hpp"

#include <cstdio>
#include <cstdlib>
#include <cstring>

static uint16_t port = 5029;
static int failures = 0;

static sockaddr_in serverAddr() {
    sockaddr_in a;
    memset(&a, 0, sizeof a);
    a.sin_family = AF_INET;
    a.sin_port = htons(port);
    platform::parseIPv4("127.0.0.1", &a.sin_addr);
    return a;
}

static void setTimeout(int fd, int ms) {
#ifdef _WIN32
    DWORD tv = ms;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char *>(&tv), sizeof tv);
#else
    timeval tv;
    tv.tv_sec = ms / 1000;
    tv.tv_usec = (ms % 1000) * 1000;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
#endif
}

static int connectClient(uint8_t *id) {
    int fd = static_cast<int>(socket(AF_INET, SOCK_DGRAM, 0));
    setTimeout(fd, 2000);
    uint8_t buf[128];
    memset(buf, 0, sizeof buf);
    *reinterpret_cast<uint32_t *>(buf) = ntohl(static_cast<uint32_t>(Packets::Tag::CONNECT));
    NetReturn r = Packets::Connect(0, 0).netWriteToBuffer(buf + 4, sizeof buf - 4);
    sockaddr_in to = serverAddr();
    sendto(fd, reinterpret_cast<const char *>(buf), 4 + r.bytes, 0,
           reinterpret_cast<const sockaddr *>(&to), sizeof to);
    int n = recvfrom(fd, reinterpret_cast<char *>(buf), sizeof buf, 0, nullptr, nullptr);
    if(n < 4) return -1;
    Packets::ServerInitialResponse sip;
    Packets::ServerInitialResponse::netReadFromBuffer(&sip, buf + 4, n - 4);
    *id = sip.playerId;
    return fd;
}

// manda una posizione con, se richiesto, i 16 byte dei pesi in coda
static void sendPos(int fd, uint8_t id, const uint8_t *weights) {
    uint8_t buf[128];
    memset(buf, 0, sizeof buf);
    Packets::PlayerPosition p;
    p.playerId = id;
    p.position = {100.0f, 200.0f, 300.0f};
    p.velocity = {0.0f, 0.0f, 0.0f};
    p.direction = {1.0f, 0.0f, 0.0f};
    p.currentAnimation = 0;
    p.defaultAnimation = 0;
    p.animationSpeed = 1.0f;
    *reinterpret_cast<uint32_t *>(buf) = ntohl(static_cast<uint32_t>(Packets::Tag::PLAYER_POSITION));
    NetReturn r = p.netWriteToBuffer(buf + 4, sizeof buf - 4);
    int len = 4 + static_cast<int>(r.bytes);
    if(weights) { memcpy(buf + len, weights, 16); len += 16; }
    sockaddr_in to = serverAddr();
    sendto(fd, reinterpret_cast<const char *>(buf), len, 0,
           reinterpret_cast<const sockaddr *>(&to), sizeof to);
}

// aspetta una posizione del mittente indicato; ritorna la lunghezza del datagramma
static int recvPosFrom(int fd, uint8_t from, uint8_t *out) {
    for(int i = 0; i < 20; i++) {
        int n = recvfrom(fd, reinterpret_cast<char *>(out), 128, 0, nullptr, nullptr);
        if(n < 5) return -1;
        if(ntohl(*reinterpret_cast<const uint32_t *>(out)) !=
                static_cast<uint32_t>(Packets::Tag::PLAYER_POSITION)) continue;
        if(out[4] != from) continue;
        return n;
    }
    return -1;
}

int main(int argc, char **argv) {
    if(argc > 1) port = static_cast<uint16_t>(atoi(argv[1]));
    platform::setupLogging();
    platform::netInit();

    uint8_t idA, idB;
    int a = connectClient(&idA), b = connectClient(&idB);
    if(a < 0 || b < 0) { printf("handshake fallito\n"); return 1; }
    printf("A = id %u, B = id %u\n\n", idA, idB);

    // pesi riconoscibili, in big endian come li scrive il Wii
    const uint8_t W[16] = {0x3E,0x00,0x00,0x00, 0x3E,0x80,0x00,0x00,
                           0x3F,0x00,0x00,0x00, 0x3D,0x80,0x00,0x00};
    uint8_t got[128];

    printf("=== pacchetto nuovo: 56 + 16 byte di pesi ===\n");
    sendPos(a, idA, W);
    int n = recvPosFrom(b, idA, got);
    printf("  B riceve un datagramma di %d byte (atteso 76)\n", n);
    if(n != 76) failures++;
    else if(memcmp(got + 4 + 56, W, 16) != 0) { printf("  pesi alterati\n"); failures++; }
    else printf("  pesi intatti\n");

    printf("\n=== pacchetto vecchio: 56 byte ===\n");
    sendPos(a, idA, nullptr);
    n = recvPosFrom(b, idA, got);
    printf("  B riceve un datagramma di %d byte (atteso 60)\n", n);
    if(n != 60) failures++;

    // Con "follow" c'e' anche Follow collegato: A trasmette per un po', Follow
    // lo ripete come giocatore suo, e B deve ricevere da Follow i pesi di A.
    if(argc > 2 && strcmp(argv[2], "follow") == 0) {
        printf("\n=== attraverso Follow ===\n");
        setTimeout(b, 30);
        int fromFollow = 0, withWeights = 0;
        for(int i = 0; i < 120; i++) {
            sendPos(a, idA, W);
            for(;;) {
                int m = recvfrom(b, reinterpret_cast<char *>(got), 128, 0, nullptr, nullptr);
                if(m < 5) break;
                if(ntohl(*reinterpret_cast<const uint32_t *>(got)) !=
                        static_cast<uint32_t>(Packets::Tag::PLAYER_POSITION)) continue;
                if(got[4] == idA || got[4] == idB) continue;
                fromFollow++;
                if(m == 76 && memcmp(got + 4 + 56, W, 16) == 0) withWeights++;
            }
        }
        printf("  pacchetti dal Mario finto: %d, con i pesi intatti: %d\n", fromFollow, withWeights);
        if(fromFollow == 0 || withWeights != fromFollow) failures++;
    }

    platform::closeSocket(a);
    platform::closeSocket(b);
    platform::netShutdown();
    printf("\n%s\n", failures == 0 ? "TUTTO A POSTO" : "CI SONO PROBLEMI");
    return failures ? 1 : 0;
}
