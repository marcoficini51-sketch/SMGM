#include "transmission.hpp"
#include "platform_net.hpp"

#include <cstring>

namespace Transmission {
ConnectionHolder::ConnectionHolder(Connection *connections, uint8_t len)
    : connections(connections), len(len) 
{
    for(uint8_t i = 0; i < len; i++) {
        connections[i].isActive = false;
        connections[i].isCandidate = false;
        connections[i].lastSeen = std::chrono::steady_clock::time_point{};
        memset(&connections[i].addr, 0, sizeof connections[i].addr);
    }
}

NetReturn ConnectionHolder::getId(sockaddr_in *addr) {
    const auto now = std::chrono::steady_clock::now();

    Connection *i = connections, *firstFree = nullptr, *stalest = nullptr;

    for(; i < cend(); i++) {
        if (
            (i->isActive || i->isCandidate)
            && i->addr.sin_addr.s_addr == addr->sin_addr.s_addr
            && i->addr.sin_port == addr->sin_port
        ) {
            i->lastSeen = now;
            if(i->isActive) {
                return {static_cast<uint32_t>(i - cbegin()), NetReturn::OK};
            }
            else if(i->isCandidate) {
                return {static_cast<uint32_t>(i - cbegin()), NetReturn::CANDIDATE};
            }
        }
        else if(!i->isCandidate && !i->isActive) {
            if(!firstFree) firstFree = i;
        }
        else if(!stalest || i->lastSeen < stalest->lastSeen) {
            stalest = i;
        }
    }

    // Nessuno slot libero: ricicla il piu' silenzioso, ma solo se tace da
    // abbastanza. Cosi' chi ha il gioco in pausa non viene buttato fuori
    // finche' non serve davvero il posto.
    if(!firstFree && stalest && (now - stalest->lastSeen) > RECLAIM_AFTER) {
        firstFree = stalest;
        firstFree->isActive = false;
        firstFree->isCandidate = false;
    }

    if(firstFree != nullptr) {
        firstFree->isCandidate = true;
        firstFree->addr = *addr;
        firstFree->lastSeen = now;
        return {static_cast<uint32_t>(firstFree - cbegin()), NetReturn::CANDIDATE};
    }
    return {0, NetReturn::FILTERED};
}

bool ConnectionHolder::adopt(uint8_t candidateId, uint8_t claimed) {
    if(candidateId >= len || claimed >= len) return false;
    Connection &cand = connections[candidateId];
    Connection &slot = connections[claimed];
    if(!cand.isCandidate) return false;
    const auto now = std::chrono::steady_clock::now();

    if(claimed != candidateId && (slot.isActive || slot.isCandidate)) {
        bool silent = (now - slot.lastSeen) > RECLAIM_AFTER;
        if(!silent) return false;                 // occupato da qualcuno di vivo
    }
    const sockaddr_in addr = cand.addr;
    cand.isCandidate = false;
    slot.addr = addr;
    slot.isCandidate = false;
    slot.isActive = true;
    slot.lastSeen = now;
    return true;
}

NetReturn Writer::write(const void *data, uint32_t size, uint8_t destination) {
    ssize_t written;
    if(destination & 0x80 && destination != 0xFF) {
        const Connection *c = holder->getConnection(destination & 0x7F);
        if(c) {
            do {
                written = sendto(socket, static_cast<const char *>(data),
                    static_cast<int>(size), 0,
                    reinterpret_cast<const sockaddr *>(&c->addr), sizeof c->addr);
            }
            while (written < 0 && platform::wouldBlock(platform::netErrno()));
        }
        return {size, NetReturn::OK};
    }
    for(auto i = holder->cbegin(); i < holder->cend(); i++) {
        
        uint8_t id = holder->getId(i).bytes;

        if(!i->isActive || id == destination) continue;


        written = sendto(socket, static_cast<const char *>(data),
            static_cast<int>(size), 0,
            reinterpret_cast<const sockaddr *>(&i->addr), sizeof i->addr);

        if(written < 0 && platform::wouldBlock(platform::netErrno())) i--;
    }
    return {size, NetReturn::OK};
}

NetReturn Reader::read(void *data, uint32_t size, uint8_t *outputId) {
    ssize_t read;
    sockaddr_in addr;
    socklen_t addrlen = sizeof addr;

    // L'originale assegnava errno (positivo) a `read` e lo confrontava con
    // -EAGAIN: il ritentativo non scattava mai, e il controllo `read < 0`
    // qui sotto lasciava passare un errore come se fossero dati validi.
    do {
        read = recvfrom(socket, static_cast<char *>(data),
            static_cast<int>(size), 0,
            reinterpret_cast<sockaddr *>(&addr), &addrlen);
    } while(read < 0 && platform::wouldBlock(platform::netErrno()));

    if(read < 0) {
        return {static_cast<uint32_t>(platform::netErrno()), NetReturn::SYSTEM_ERROR};
    }

    NetReturn res = holder->getId(&addr);
    switch(res.errorCode) {
        case NetReturn::OK:
            *outputId = 
                static_cast<std::remove_reference<decltype(*outputId)>::type>(res.bytes);
            return {static_cast<uint32_t>(read), NetReturn::OK};
        
        case NetReturn::CANDIDATE:
            *outputId = 
                static_cast<std::remove_reference<decltype(*outputId)>::type>(res.bytes);
            return {static_cast<uint32_t>(read), NetReturn::CANDIDATE};
        
        case NetReturn::FILTERED:
            return {0, NetReturn::FILTERED};
        case NetReturn::NOT_ENOUGH_SPACE:
            return {0, NetReturn::NOT_ENOUGH_SPACE};
        default:
            return netHandleInvalidState();
    }

}

}

