@echo off
rem Apre il pannello di controllo del server.
rem -ExecutionPolicy Bypass vale solo per questo avvio: non cambia
rem nessuna impostazione del sistema.
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0ServerGUI.ps1"
