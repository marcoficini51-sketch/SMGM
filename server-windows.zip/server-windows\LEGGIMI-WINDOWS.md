# Ospitare il server dal tuo PC

`SMGServer.exe` è il server compilato per Windows: nativo, statico, nessuna
DLL da installare. Gira senza WSL.

---

## 1. Avvia il server

Doppio clic su `SMGServer.exe`, oppure da terminale:

```
"SMGServer.exe" 5029 0.0.0.0
```

Deve stampare `Listening on port 5029 (Windows)`. Lascia la finestra aperta:
premendo Invio si chiude.

Il tuo gioco si collega a `127.0.0.1:5029` (già configurato in `serverIP.txt`).
I tuoi amici si collegano al tuo IP pubblico.

## 2. Apri il firewall di Windows

Una volta sola, in un **PowerShell come amministratore**:

```powershell
New-NetFirewallRule -DisplayName "SMGServer" -Direction Inbound -Protocol UDP -LocalPort 5029 -Action Allow
```

Per rimuoverla in futuro:

```powershell
Remove-NetFirewallRule -DisplayName "SMGServer"
```

## 3. Radmin VPN — la strada consigliata

**Con Radmin VPN i punti 4 e 5 non servono: niente router, niente CGNAT.**

Radmin crea una LAN virtuale fra i due PC. Il tuo indirizzo su quella rete è
**10.0.0.2**, ed è quello già scritto nel `kit-amico.zip`.

1. Apri Radmin VPN e crea una rete (*Rete → Crea una rete*): scegli nome e
   password.
2. Passa nome e password al tuo amico, che si unisce dalla stessa voce di menu.
3. Quando lo vedi verde nella lista, siete collegati.

Il server ascolta già su tutte le interfacce, quindi risponde anche lì senza
riconfigurare niente — l'ho verificato. E Windows classifica l'adattatore
Radmin come rete **Privata**, quindi il firewall è molto meno ostile che su
una connessione pubblica.

Due cose da sapere:

- **Tenete Radmin aperto** mentre giocate. Se si chiude, cade tutto.
- Radmin prova prima un collegamento diretto fra i due PC; se non ci riesce
  (NAT ostili da entrambe le parti) passa dai suoi server, e la latenza sale.
  Per questo mod non è drammatico: i puppet vengono estrapolati per dead
  reckoning e riportati sulla posizione vera con una convergenza morbida,
  quindi un centinaio di millisecondi si assorbono senza scatti. Non è un
  picchiaduro.
- I pacchetti sono da 60 byte, quindi nessun problema di MTU nel tunnel.

Il vantaggio in più: l'indirizzo `26.x.x.x` è **stabile**, mentre il tuo IP
pubblico può cambiare a ogni riavvio del router.

---

## 4. In alternativa: apri la porta sul router

Nel pannello del router, sezione *Port forwarding* / *Virtual server*:

| Campo | Valore |
|---|---|
| Protocollo | **UDP** (non TCP) |
| Porta esterna | 5029 |
| Porta interna | 5029 |
| IP di destinazione | **192.168.1.X** |

Conviene anche assegnare a quel PC un IP statico nel DHCP del router, se no
al riavvio cambia e la regola punta a vuoto.

## 5. Verifica di non essere sotto CGNAT (solo se usi il router)

**Questo è il punto che decide se il piano funziona.** Molti operatori
italiani, soprattutto su fibra FWA e mobile, mettono i clienti dietro un NAT
di rete: in quel caso il port forwarding non funziona e non c'è modo di
aggirarlo dal tuo lato.

Come controllare, in un minuto:

1. Entra nel router e cerca l'indirizzo **WAN** (a volte "IP Internet").
2. Confrontalo con il tuo IP pubblico: **31.191.231.92**

- **Coincidono** → sei a posto, il port forwarding funzionerà.
- **Sono diversi**, e la WAN è tipo `100.64.x.x`, `10.x.x.x` o `172.16-31.x.x`
  → sei dietro CGNAT. Chiedi all'operatore un IP pubblico (spesso gratis o
  pochi euro), oppure passa alla VPS: il pacchetto è in questa stessa
  cartella.

## 6. Manda il kit al tuo amico

`kit-amico.zip` contiene tutto quello che gli serve, istruzioni comprese.
È già configurato per **Radmin VPN** (`10.0.0.2`). Se invece scegli la
strada del router, dentro lo zip cambia `serverIP.txt` mettendoci il tuo IP
pubblico seguito da `:5029`.

---

## Friendly fire

Nel pannello, accanto alla porta, c'è la casella **Friendly fire**:

- **accesa**: lo schianto a terra addosso a un altro giocatore gli toglie 1
  di vita, la piroetta lo fa cadere senza danno;
- **spenta**: nessuno può fare male agli altri. Salti in testa e spinte
  restano.

Vale **subito**, anche a partita in corso: il server rilegge ogni secondo il
file `friendlyfire.txt` che la casella scrive, quindi non serve riavviarlo (e
riavviarlo obbligherebbe tutti a riavviare il gioco). Il pannello si ricorda
l'ultima scelta.

Da riga di comando: `SMGServer.exe 5029 0.0.0.0 --friendly-fire=on`, e con
`--controllo percorso\friendlyfire.txt` si può cambiare al volo scrivendoci
`1` o `0`.

Come funziona: la vita la toglie la console di chi subisce, guardando nel
pacchetto posizione dell'altro i flag «sta facendo lo schianto» e «sta
facendo la piroetta». Col friendly fire spento il server cancella quei due
flag prima di inoltrare il pacchetto. Nessun client da configurare.

---

## Note

**Il tuo IP pubblico può cambiare.** Quasi nessun operatore domestico dà un
IP fisso: dopo un riavvio del router potrebbe essere diverso, e il file
`serverIP.txt` del tuo amico va aggiornato. Se diventa una scocciatura,
guarda un servizio di DNS dinamico (DuckDNS, No-IP): gli dai un nome fisso al
posto di un numero. Attenzione però: **il mod non risolve i nomi a dominio**,
accetta solo indirizzi numerici. Il DNS dinamico ti serve per sapere qual è
l'IP del momento, non per scriverlo in `serverIP.txt`.

**Massimo 8 giocatori**, limite fissato a tempo di compilazione da entrambi i
lati.

**Nessuna autenticazione.** Chi conosce IP e porta entra. Per due amici va
benissimo; se ti secca, limita l'accesso agli IP noti nel firewall.

**Riavviare il server (o il pannello) non obbliga a riavviare i giochi.**
Chi era collegato viene riadottato nel suo vecchio slot al primo pacchetto,
e nel registro compare «Connected to … – riadottato». Solo se nel frattempo
quello slot l'ha preso un altro il server lo segnala, una volta sola, e quel
giocatore deve riavviare il gioco.
