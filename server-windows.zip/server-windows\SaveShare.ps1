#
# Condivide il salvataggio di Super Mario Galaxy con chi si collega.
#
# Lo avvia il pannello del server quando accendi "Condividi il mio salvataggio".
# Resta in ascolto su una porta TCP: a ogni richiesta rifa' lo zip della
# cartella del salvataggio (cosi' e' sempre aggiornato) e lo manda.
#
# Protocollo, semplice apposta: 4 byte con la lunghezza (big endian) e poi lo
# zip. Niente comandi, niente scritture: si puo' solo leggere il salvataggio.
#
#   SaveShare.ps1 [-Port 5030] [-SaveDir <cartella>] [-LogFile <file>]
#

param(
    [int]$Port = 5030,
    [string]$SaveDir = "$env:APPDATA\Dolphin Emulator\Wii\title\00010000\524d4745\data",
    [string]$LogFile = ""
)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.IO.Compression.FileSystem

function Say($t) {
    $riga = "{0}  {1}" -f (Get-Date -Format "HH:mm:ss"), $t
    Write-Output $riga
    if ($LogFile -ne "") { Add-Content -Path $LogFile -Value $riga -Encoding utf8 }
}

if (-not (Test-Path $SaveDir)) {
    Say "Non trovo la cartella del salvataggio: $SaveDir"
    Say "Apri il gioco almeno una volta, cosi' Dolphin la crea."
    exit 1
}

$listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Any, $Port)
try { $listener.Start() } catch {
    Say "Non riesco ad ascoltare sulla porta $Port : $_"
    exit 1
}
Say "Condivisione del salvataggio accesa sulla porta $Port"
Say "Cartella: $SaveDir"

while ($true) {
    $client = $listener.AcceptTcpClient()
    $chi = $client.Client.RemoteEndPoint.ToString()
    try {
        $zip = Join-Path $env:TEMP ("smg-save-{0}.zip" -f (Get-Random))
        if (Test-Path $zip) { Remove-Item $zip -Force }
        [System.IO.Compression.ZipFile]::CreateFromDirectory($SaveDir, $zip)
        $dati = [System.IO.File]::ReadAllBytes($zip)
        Remove-Item $zip -Force -ErrorAction SilentlyContinue

        $len = [System.BitConverter]::GetBytes([int]$dati.Length)
        if ([System.BitConverter]::IsLittleEndian) { [Array]::Reverse($len) }

        $flusso = $client.GetStream()
        $flusso.Write($len, 0, 4)
        $flusso.Write($dati, 0, $dati.Length)
        $flusso.Flush()
        Say ("Mandato il salvataggio a {0} ({1:N0} byte)" -f $chi, $dati.Length)
    } catch {
        Say "Errore mandando il salvataggio a $chi : $_"
    } finally {
        $client.Close()
    }
}
