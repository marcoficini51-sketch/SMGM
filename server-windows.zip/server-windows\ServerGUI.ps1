#
# Pannello di controllo per SMGServer.
#
# Avvialo con "Avvia server.bat" (imposta la policy di esecuzione al volo,
# senza modificare niente a livello di sistema).
#

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

# Windows marchia i file che arrivano da internet, e aprendo il .ps1 a mano
# esce l'avviso di sicurezza. Il marchio si toglie una volta sola, qui: dal
# secondo avvio non compare piu' nemmeno aprendo lo script direttamente.
try {
    $qui = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
    Get-ChildItem -LiteralPath $qui -Recurse -Force -ErrorAction SilentlyContinue |
        Unblock-File -ErrorAction SilentlyContinue
} catch { }

$here    = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
$exePath = Join-Path $here "SMGServer.exe"
$outLog  = Join-Path $here "server.log"
$errLog  = Join-Path $here "server.err"

$testExe = Join-Path $here "TestPlayers.exe"
$starExe = Join-Path $here "StarSpawn.exe"
$chipExe = Join-Path $here "ChipTest.exe"
$warpExe = Join-Path $here "Warp.exe"
$testLog = Join-Path $here "testplayers.log"
$testCtl = Join-Path $here "testplayers.count"

$ffFile   = Join-Path $here "friendlyfire.txt"
$tpFile   = Join-Path $here "tp.txt"
$hostFile = Join-Path $here "host.txt"
$byeFile  = Join-Path $here "bye.txt"
$playersFile = Join-Path $here "players.txt"   # dal server: solo chi gioca davvero
$nameFile = Join-Path $here "servername.txt"
$warpFile = Join-Path $here "testboss1.txt"
$langFile = Join-Path $here "lingua.txt"
$devFile  = Join-Path $here "devmode.txt"

$shareScript = Join-Path $here "SaveShare.ps1"
$shareLog    = Join-Path $here "saveshare.log"
$hideFile    = Join-Path $here "nascondi-ip.txt"  # 1 = indirizzi nascosti a schermo
$shareFile   = Join-Path $here "condividi.txt"   # 1 = accesa (di serie), 0 = spenta a mano

$script:proc      = $null
$script:offsets   = @{ $outLog = 0; $errLog = 0 }
$script:players   = @{}
$script:testProc  = $null
$script:testCount = 0
$script:shareProc = $null
$script:hostSlot  = -1

$MAX_TEST = 7       # 8 slot sul server, uno e' del giocatore vero
$TEST_SPACING = 250 # distanza fra una copia e l'altra, misurata sul percorso

# ---------------------------------------------------------------- lingua
# Ogni scritta ha una chiave; i controlli si registrano con Reg, cosi' al
# cambio di lingua basta riscorrere l'elenco invece di ritoccarli a mano.
$S = @{}
$S["it"] = @{
    titolo      = "Super Mario Galaxy - Server"
    testata     = "Super Mario Galaxy"
    sottotesta  = "server multiplayer"
    lingua      = "Lingua"
    dev         = "Dev mode"
    acceso      = "In esecuzione"
    spento      = "Fermo"
    dettAcceso  = "in ascolto su UDP {0} - PID {1}"
    dettSpento  = "premi Avvia per accendere il server"
    avvia       = "Avvia"
    ferma       = "Ferma"
    porta       = "Porta UDP"
    giocatori   = "Giocatori collegati: {0}"
    ff          = "Friendly fire"
    ffOn        = "Friendly fire ACCESO: schianto = 1 di danno, piroetta = caduta"
    ffOff       = "Friendly fire SPENTO: nessuno puo' fare male agli altri"
    indirizzo   = "Indirizzo da dare agli amici"
    hideIp      = "Hide IP"
    copia       = "Copia"
    copiato     = "Copiato!"
    registro    = "Registro"
    pulisci     = "Pulisci registro"
    partita     = "PARTITA"
    tp          = "Teletrasporta tutti da me"
    slot        = "slot"
    tpNota      = "vuoto = il gioco su questo PC; solo chi e' nella tua galassia"
    nome        = "Nome del server (lo vedono gli amici nel gioco)"
    salvaNome   = "Salva nome"
    condividi   = "Condividi il mio salvataggio (porta 5030)"
    luigiBtn    = "You are playing as Luigi"
    marioBtn    = "You are playing as Mario"
    logLuigi    = "--- personaggio: {0} (vale dal prossimo avvio del gioco) ---"
    condNota    = "gli amici lo prendono dal loro pannello, prima di avviare il gioco"
    strumenti   = "STRUMENTI DI PROVA"
    testPlayer  = "Test player"
    testPlayerN = "Test player ({0}/{1})"
    distanza    = "distanza"
    distNota    = "unita' fra un Mario e l'altro, regolabile mentre gira"
    stella      = "Stella per tutti"
    numero      = "numero"
    stellaNota  = "stella della vostra missione; 0 = prova dalla 1 alla 7"
    senzaStella = "senza stella (fa partire solo la sequenza)"
    pezzetto    = "Add 1 test"
    pezzNota    = "+1 al contatore dei pezzetti di stellina, per tutti"
    punto       = "Punto di prova (Test boss 1)"
    salvaPunto  = "Salva posizione attuale"
    vaiPunto    = "Test boss 1"
    uccidi      = "Uccidi tutti"
    uccidiNota  = "morte vera, come le zone di morte del gioco"
    mbFermoT    = "Server fermo"
    mbFermo     = "Accendi prima il server."
    mbMancaT    = "File mancante"
    mbManca     = "Non trovo {0} in:`n{1}"
    mbPortaT    = "Porta"
    mbPorta     = "Porta non valida. Usa un numero fra 1 e 65535."
    mbNumeroT   = "Numero"
    mbNumero    = "Il numero della stella va da 1 a 255 (0 = prova dalla 1 alla 7)."
    mbSenzaT    = "Stella"
    mbSenza     = "Senza stella serve un numero preciso: scrivi da 1 a 7."
    mbUccidiT   = "Uccidi tutti"
    mbUccidi    = "Uccido tutti i Mario: perdono una vita e ripartono dall'ultimo punto.`n`nProcedo?"
    mbPuntoT    = "Test boss 1"
    mbPunto     = "Servono tre numeri: x y z. Usa 'Salva posizione attuale'."
    mbPosT      = "Posizione"
    mbPos       = "Non riesco a leggere la posizione: qualcuno deve essere dentro una galassia."
    mbSlotT     = "Slot"
    mbSlot      = "Lo slot va da 0 a 7 (vuoto = il gioco su questo PC)."
    mbTpT       = "Teletrasporto"
    mbTp        = "Non trovo il tuo gioco fra i collegati.`n`nScrivi il tuo slot nella casella (il numero fra parentesi in 'Connected to ... (N)')."
    mbGiaT      = "Server gia' attivo"
    mbGia       = "C'e' gia' un server in esecuzione (PID {0}).`n`nLo fermo e ne avvio uno nuovo?"
    mbErroreT   = "Errore"
    mbErrore    = "Avvio fallito:`n{0}"
    mbChiusoT   = "Avvio non riuscito"
    mbChiuso    = "Il server si e' chiuso subito dopo l'avvio."
    mbOccupata  = "La porta {0} e' gia' occupata da un altro programma.`n`nProva con un'altra porta, oppure chiudi cio' che la usa."
    logStella   = "--- stella {0} ---"
    logStellaTp = "--- stella {0}: la annuncia il primo Test player ---"
    logPezzetto = "--- prova: +1 al contatore dei pezzetti ---"
    logPieno    = "Il server non ha slot liberi. Se un gioco e' stato chiuso da poco,`r`nil suo posto si libera dopo un minuto di silenzio.`r`n"
    logPienoT   = "Il server non ha slot liberi: spegni i Test player e riprova.`r`n"
    logTp       = "--- teletrasporto: tutti dallo slot {0} ---"
    logTpMulti  = "(da questo PC ci sono piu' giochi: uso lo slot {0}; se non sei tu scrivilo nella casella)"
    logNome     = "--- nome del server: {0} (rifai il kit per darlo agli amici) ---"
    logHost     = "--- chi ospita: slot {0} (comanda lui i boss) ---"
    logBye      = "--- chi ospita ha chiuso il gioco: gli altri tornano al titolo ---"
    logCond     = "--- salvataggio condiviso sulla porta 5030 ---"
    logNoCond   = "--- salvataggio non piu' condiviso ---"
    logCondNo   = "--- condivisione non partita ---"
    logPos      = "--- posizione: {0} ---"
    logPunto    = "--- test boss 1: {0} ---"
    logUccidi   = "--- uccidi tutti: {0} ---"
    logTestOff  = "--- test fermato ---`r`nI Mario gia' comparsi restano fermi a schermo: il mod non`r`nrimuove mai un giocatore. Per farli sparire riavvia il gioco.`r`n"
    logTestOn   = "--- {0} in fila a {1} unita' l'uno, l'ultimo a {2} dietro di te ---"
    logTestMax  = "--- alla prossima pressione il test si ferma ---`r`n"
    logTestNo   = "--- le copie non si sono collegate ---"
    logNoParte  = "--- {0} non partito: {1} ---"
    senzaAvvio  = "apri il pannello senza avviare"
    avviando    = "avvio in corso..."
}
$S["en"] = @{
    titolo      = "Super Mario Galaxy - Server"
    testata     = "Super Mario Galaxy"
    sottotesta  = "multiplayer server"
    lingua      = "Language"
    dev         = "Dev mode"
    acceso      = "Running"
    spento      = "Stopped"
    dettAcceso  = "listening on UDP {0} - PID {1}"
    dettSpento  = "press Start to turn the server on"
    avvia       = "Start"
    ferma       = "Stop"
    porta       = "UDP port"
    giocatori   = "Players connected: {0}"
    ff          = "Friendly fire"
    ffOn        = "Friendly fire ON: ground pound = 1 damage, spin = knockback"
    ffOff       = "Friendly fire OFF: nobody can hurt anyone"
    indirizzo   = "Address to give your friends"
    hideIp      = "Hide IP"
    copia       = "Copy"
    copiato     = "Copied!"
    registro    = "Log"
    pulisci     = "Clear log"
    partita     = "GAME"
    tp          = "Teleport everyone to me"
    slot        = "slot"
    tpNota      = "empty = the game on this PC; only players in your galaxy"
    nome        = "Server name (your friends see it in game)"
    salvaNome   = "Save name"
    condividi   = "Share my save file (port 5030)"
    luigiBtn    = "You are playing as Luigi"
    marioBtn    = "You are playing as Mario"
    logLuigi    = "--- character: {0} (takes effect next time you start the game) ---"
    condNota    = "your friends take it from their own panel, before starting the game"
    strumenti   = "TEST TOOLS"
    testPlayer  = "Test player"
    testPlayerN = "Test player ({0}/{1})"
    distanza    = "spacing"
    distNota    = "units between one Mario and the next, adjustable while running"
    stella      = "Star for everyone"
    numero      = "number"
    stellaNota  = "the star of your mission; 0 = try 1 to 7"
    senzaStella = "no star (plays the sequence only)"
    pezzetto    = "Add 1 test"
    pezzNota    = "+1 on the star chip counter, for everyone"
    punto       = "Test point (Test boss 1)"
    salvaPunto  = "Save current position"
    vaiPunto    = "Test boss 1"
    uccidi      = "Kill everyone"
    uccidiNota  = "a real death, like the game's own death planes"
    mbFermoT    = "Server stopped"
    mbFermo     = "Start the server first."
    mbMancaT    = "Missing file"
    mbManca     = "I can't find {0} in:`n{1}"
    mbPortaT    = "Port"
    mbPorta     = "Invalid port. Use a number between 1 and 65535."
    mbNumeroT   = "Number"
    mbNumero    = "The star number goes from 1 to 255 (0 = try 1 through 7)."
    mbSenzaT    = "Star"
    mbSenza     = "Without a star you need an exact number: type 1 to 7."
    mbUccidiT   = "Kill everyone"
    mbUccidi    = "I'll kill every Mario: they lose a life and restart from the last checkpoint.`n`nGo ahead?"
    mbPuntoT    = "Test boss 1"
    mbPunto     = "Three numbers are needed: x y z. Use 'Save current position'."
    mbPosT      = "Position"
    mbPos       = "I can't read the position: someone has to be inside a galaxy."
    mbSlotT     = "Slot"
    mbSlot      = "The slot goes from 0 to 7 (empty = the game on this PC)."
    mbTpT       = "Teleport"
    mbTp        = "I can't find your game among the connected ones.`n`nType your slot in the box (the number in brackets in 'Connected to ... (N)')."
    mbGiaT      = "Server already running"
    mbGia       = "A server is already running (PID {0}).`n`nShall I stop it and start a new one?"
    mbErroreT   = "Error"
    mbErrore    = "Start failed:`n{0}"
    mbChiusoT   = "Could not start"
    mbChiuso    = "The server closed right after starting."
    mbOccupata  = "Port {0} is already taken by another program.`n`nTry another port, or close what is using it."
    logStella   = "--- star {0} ---"
    logStellaTp = "--- star {0}: announced by the first Test player ---"
    logPezzetto = "--- test: +1 on the star chip counter ---"
    logPieno    = "The server has no free slots. If a game was closed recently,`r`nits place frees up after a minute of silence.`r`n"
    logPienoT   = "The server has no free slots: turn the Test players off and retry.`r`n"
    logTp       = "--- teleport: everyone to slot {0} ---"
    logTpMulti  = "(this PC has more than one game: using slot {0}; if that isn't you, type yours in the box)"
    logNome     = "--- server name: {0} (rebuild the kit to give it to your friends) ---"
    logHost     = "--- host: slot {0} (bosses answer to them) ---"
    logBye      = "--- the host closed the game: everyone else goes back to the title ---"
    logCond     = "--- save file shared on port 5030 ---"
    logNoCond   = "--- save file no longer shared ---"
    logCondNo   = "--- sharing did not start ---"
    logPos      = "--- position: {0} ---"
    logPunto    = "--- test boss 1: {0} ---"
    logUccidi   = "--- kill everyone: {0} ---"
    logTestOff  = "--- test stopped ---`r`nThe Marios already on screen stay there: the mod never removes`r`na player. Restart the game to get rid of them.`r`n"
    logTestOn   = "--- {0} in a row {1} units apart, the last one {2} behind you ---"
    logTestMax  = "--- one more press and the test stops ---`r`n"
    logTestNo   = "--- the copies did not connect ---"
    logNoParte  = "--- {0} did not start: {1} ---"
    senzaAvvio  = "open the panel without starting"
    avviando    = "starting..."
}

$script:lang = "it"
if (Test-Path $langFile) {
    $l = (Get-Content $langFile -Raw -ErrorAction SilentlyContinue).Trim().ToLower()
    if ($S.ContainsKey($l)) { $script:lang = $l }
}

function T($chiave) {
    $t = $S[$script:lang][$chiave]
    if ($null -eq $t) { $t = $S["it"][$chiave] }
    return $t
}

$script:testi = New-Object System.Collections.ArrayList

function Reg($ctl, $chiave) {
    [void]$script:testi.Add(@{ C = $ctl; K = $chiave })
    $ctl.Text = T $chiave
    return $ctl
}

# ---------------------------------------------------------------- palette
$cBg      = [System.Drawing.Color]::FromArgb(24, 24, 34)
$cPanel   = [System.Drawing.Color]::FromArgb(36, 36, 52)
$cPanel2  = [System.Drawing.Color]::FromArgb(31, 31, 45)
$cText    = [System.Drawing.Color]::FromArgb(232, 232, 244)
$cMuted   = [System.Drawing.Color]::FromArgb(138, 138, 164)
$cOn      = [System.Drawing.Color]::FromArgb(94, 200, 140)
$cOff     = [System.Drawing.Color]::FromArgb(198, 96, 96)
$cAccent  = [System.Drawing.Color]::FromArgb(228, 168, 72)
$cLine    = [System.Drawing.Color]::FromArgb(52, 52, 72)

$fTitle   = New-Object System.Drawing.Font("Segoe UI Semibold", 15)
$fSection = New-Object System.Drawing.Font("Segoe UI Semibold", 8)
$fLabel   = New-Object System.Drawing.Font("Segoe UI", 8.5)
$fBody    = New-Object System.Drawing.Font("Segoe UI", 9.5)
$fStatus  = New-Object System.Drawing.Font("Segoe UI Semibold", 11)
$fMono    = New-Object System.Drawing.Font("Consolas", 9)
$fAddr    = New-Object System.Drawing.Font("Consolas", 11, [System.Drawing.FontStyle]::Bold)

$W = 620            # larghezza della finestra
$M = 22             # margine
$CW = 556           # larghezza delle schede

# ---------------------------------------------------------------- finestra
$form = New-Object System.Windows.Forms.Form
$form.Text = T "titolo"
$form.Size = New-Object System.Drawing.Size($W, 1000)
$form.StartPosition = "CenterScreen"
$form.BackColor = $cBg
$form.ForeColor = $cText
$form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox = $false
# doppio buffer, se no crescendo e calando la finestra sfarfalla. La proprieta'
# e' protetta: si arriva solo per riflessione.
try {
    $prop = [System.Windows.Forms.Form].GetProperty("DoubleBuffered", [System.Reflection.BindingFlags]"Instance,NonPublic")
    $prop.SetValue($form, $true, $null)
} catch { }

# ---------------------------------------------------------------- sfondo
# La copertina sfocata sta in sfondo.png (la prepara sfondo.ps1). Si carica da
# memoria, se no il file resta bloccato finche' il pannello e' aperto.
$script:bg = $null
$sfondoFile = Join-Path $here "sfondo.png"
if (Test-Path $sfondoFile) {
    try {
        $byte = [System.IO.File]::ReadAllBytes($sfondoFile)
        $ms = New-Object System.IO.MemoryStream (,$byte)
        $script:bg = [System.Drawing.Image]::FromStream($ms)
        $form.BackgroundImage = $script:bg
        $form.BackgroundImageLayout = "None"   # ancorato in alto a sinistra:
    } catch { }                                # cosi' i ritagli restano allineati
}

# angoli arrotondati: si ritaglia la forma del controllo
function Round-Ctl($ctl, $r) {
    $pth = New-Object System.Drawing.Drawing2D.GraphicsPath
    $w = $ctl.Width; $h = $ctl.Height; $d = $r * 2
    $pth.AddArc(0, 0, $d, $d, 180, 90)
    $pth.AddArc(($w - $d), 0, $d, $d, 270, 90)
    $pth.AddArc(($w - $d), ($h - $d), $d, $d, 0, 90)
    $pth.AddArc(0, ($h - $d), $d, $d, 90, 90)
    $pth.CloseFigure()
    $ctl.Region = New-Object System.Drawing.Region $pth
}

# "vetro": il pezzo di sfondo che sta sotto la scheda, piu' un velo di colore.
# I controlli WinForms non sanno essere semitrasparenti, ma una figura ritagliata
# dallo sfondo fa lo stesso effetto e non costa niente.
function Set-Glass($panel, $alpha) {
    if ($null -eq $script:bg) { return }
    $b = New-Object System.Drawing.Bitmap $panel.Width, $panel.Height
    $g = [System.Drawing.Graphics]::FromImage($b)
    $dest = New-Object System.Drawing.Rectangle 0, 0, $panel.Width, $panel.Height
    $g.DrawImage($script:bg, $dest, $panel.Left, $panel.Top, $panel.Width, $panel.Height, "Pixel")
    $br = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb($alpha, 36, 36, 52))
    $g.FillRectangle($br, 0, 0, $panel.Width, $panel.Height)
    $g.Dispose()
    $panel.BackgroundImage = $b
}

# ---------------------------------------------------------------- pillole
# I pulsanti sono la pillola della schermata d'avvio, ritagliata su misura.
# pillola.png e' quella a riposo, pillola2.png quella col mouse sopra: le
# prepara avvio.ps1 scontornandole dal verde. Se mancano, i pulsanti restano
# quelli piatti di prima.
$script:pillA = $null
$script:pillB = $null
try {
    $fa = Join-Path $here "pillola.png"
    $fb = Join-Path $here "pillola2.png"
    if ((Test-Path $fa) -and (Test-Path $fb)) {
        $ba = [System.IO.File]::ReadAllBytes($fa)
        $script:pillA = [System.Drawing.Image]::FromStream((New-Object System.IO.MemoryStream (,$ba)))
        $bb = [System.IO.File]::ReadAllBytes($fb)
        $script:pillB = [System.Drawing.Image]::FromStream((New-Object System.IO.MemoryStream (,$bb)))
    }
} catch { $script:pillA = $null }

# quanto tirare i tre colori: la pillola e' bianco-azzurra, da li' si ricavano
# le altre. Cosi' un pulsante pericoloso resta rosso anche con la nuova veste.
$TINTE = @{
    chiaro = @(1.00, 1.00, 1.00)
    rosso  = @(1.30, 0.60, 0.58)
    verde  = @(0.70, 1.16, 0.80)
    ambra  = @(1.28, 1.02, 0.60)
}
$INCHIOSTRO = @{
    chiaro = [System.Drawing.Color]::FromArgb(12, 70, 120)
    rosso  = [System.Drawing.Color]::FromArgb(132, 24, 24)
    verde  = [System.Drawing.Color]::FromArgb(16, 84, 42)
    ambra  = [System.Drawing.Color]::FromArgb(112, 64, 6)
}

# I tappi tondi si copiano tali e quali, si stira solo il tratto dritto di
# mezzo: se no su un pulsante largo e basso diventerebbero ovali.
function Taglia-Pillola($img, $dw, $dh, $tinta) {
    $sw = $img.Width; $sh = $img.Height
    $tapS = [int]($sh / 2)
    $tapD = [int]($dh / 2)
    if ($tapD * 2 -gt $dw) { $tapD = [int]($dw / 2) }
    $b = New-Object System.Drawing.Bitmap $dw, $dh, ([System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [System.Drawing.Graphics]::FromImage($b)
    $g.InterpolationMode = "HighQualityBicubic"
    $g.PixelOffsetMode = "HighQuality"
    $t = $TINTE[$tinta]
    $attr = $null
    if ($null -ne $t -and $tinta -ne "chiaro") {
        $m = New-Object System.Drawing.Imaging.ColorMatrix
        $m.Matrix00 = $t[0]; $m.Matrix11 = $t[1]; $m.Matrix22 = $t[2]; $m.Matrix33 = 1
        $attr = New-Object System.Drawing.Imaging.ImageAttributes
        $attr.SetColorMatrix($m)
    }
    $pezzi = @(
        @(0, $tapS, 0, $tapD),                                        # tappo sinistro
        @($tapS, ($sw - 2 * $tapS), $tapD, ($dw - 2 * $tapD)),        # mezzo, stirato
        @(($sw - $tapS), $tapS, ($dw - $tapD), $tapD)                 # tappo destro
    )
    foreach ($p in $pezzi) {
        if ($p[3] -le 0) { continue }
        $dst = New-Object System.Drawing.Rectangle $p[2], 0, $p[3], $dh
        if ($null -ne $attr) {
            $g.DrawImage($img, $dst, $p[0], 0, $p[1], $sh, "Pixel", $attr)
        } else {
            $src = New-Object System.Drawing.Rectangle $p[0], 0, $p[1], $sh
            $g.DrawImage($img, $dst, $src, "Pixel")
        }
    }
    $g.Dispose()
    return $b
}

# il pezzo di sfondo che sta sotto al pulsante: senza, attorno alla pillola
# resterebbe un rettangolo pieno, perche' i pulsanti non sanno essere trasparenti
function Sotto($ctl) {
    $b = New-Object System.Drawing.Bitmap $ctl.Width, $ctl.Height
    $g = [System.Drawing.Graphics]::FromImage($b)
    $padre = $ctl.Parent
    $sorgente = $null
    if ($padre -is [System.Windows.Forms.Form]) { $sorgente = $script:bg }
    elseif ($null -ne $padre) { $sorgente = $padre.BackgroundImage }
    if ($null -ne $sorgente) {
        $dst = New-Object System.Drawing.Rectangle 0, 0, $ctl.Width, $ctl.Height
        $g.DrawImage($sorgente, $dst, $ctl.Left, $ctl.Top, $ctl.Width, $ctl.Height, "Pixel")
    } elseif ($null -ne $padre) {
        $g.Clear($padre.BackColor)
    }
    $g.Dispose()
    return $b
}

function Componi($ctl, $pillola, $tinta) {
    $b = Sotto $ctl
    $g = [System.Drawing.Graphics]::FromImage($b)
    $p = Taglia-Pillola $pillola $ctl.Width $ctl.Height $tinta
    $g.DrawImage($p, 0, 0)
    $g.Dispose(); $p.Dispose()
    return $b
}

function Vesti($btn, $tinta) {
    if ($null -eq $script:pillA) { return $false }
    $a = Componi $btn $script:pillA $tinta
    $b = Componi $btn $script:pillB $tinta
    $btn.BackgroundImage = $a
    $btn.BackgroundImageLayout = "None"
    $btn.FlatAppearance.BorderSize = 0
    $btn.FlatAppearance.MouseOverBackColor = [System.Drawing.Color]::Transparent
    $btn.FlatAppearance.MouseDownBackColor = [System.Drawing.Color]::Transparent
    $btn.ForeColor = $INCHIOSTRO[$tinta]
    $btn.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 8.5)
    $btn.Add_MouseEnter({ $this.BackgroundImage = $this.Tag.Sopra }.GetNewClosure())
    $btn.Add_MouseLeave({ $this.BackgroundImage = $this.Tag.Fermo }.GetNewClosure())
    $btn.Tag = @{ Fermo = $a; Sopra = $b }
    return $true
}

function New-Label($text, $x, $y, $w, $h, $font, $color, $parent) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $text; $l.Location = New-Object System.Drawing.Point($x, $y)
    $l.Size = New-Object System.Drawing.Size($w, $h)
    $l.Font = $font; $l.ForeColor = $color; $l.BackColor = [System.Drawing.Color]::Transparent
    if ($parent) { $parent.Controls.Add($l) } else { $form.Controls.Add($l) }
    return $l
}

# intestazione di sezione: scritta piccola in maiuscolo e una riga sottile
function New-Section($chiave, $y) {
    $l = New-Label "" $M $y 300 14 $fSection $cMuted $null
    Reg $l $chiave | Out-Null
    $riga = New-Object System.Windows.Forms.Panel
    $riga.Location = New-Object System.Drawing.Point($M, ($y + 17))
    $riga.Size = New-Object System.Drawing.Size($CW, 1)
    $riga.BackColor = $cLine
    $form.Controls.Add($riga)
    $script:ultimaRiga = $riga
    return $l
}

function New-Btn($chiave, $x, $y, $w, $h, $colore, $parent, $tinta = "chiaro") {
    $b = New-Object System.Windows.Forms.Button
    $b.Location = New-Object System.Drawing.Point($x, $y)
    $b.Size = New-Object System.Drawing.Size($w, $h)
    $b.FlatStyle = "Flat"
    $b.FlatAppearance.BorderSize = 1
    $b.FlatAppearance.BorderColor = $colore
    $b.FlatAppearance.MouseOverBackColor = $cPanel
    $b.BackColor = $cBg; $b.ForeColor = $colore
    $b.Font = $fLabel
    if ($parent) { $parent.Controls.Add($b) } else { $form.Controls.Add($b) }
    if (-not (Vesti $b $tinta)) { Round-Ctl $b 6 }
    if ($chiave) { Reg $b $chiave | Out-Null }
    return $b
}

function New-Box($testo, $x, $y, $w, $colore, $parent) {
    $t = New-Object System.Windows.Forms.TextBox
    $t.Text = $testo
    $t.Location = New-Object System.Drawing.Point($x, $y)
    $t.Size = New-Object System.Drawing.Size($w, 26)
    $t.Font = $fMono
    $t.BackColor = [System.Drawing.Color]::FromArgb(22, 22, 32); $t.ForeColor = $colore
    $t.BorderStyle = "FixedSingle"
    if ($parent) { $parent.Controls.Add($t) } else { $form.Controls.Add($t) }
    return $t
}

function New-Chk($chiave, $x, $y, $w, $parent) {
    $c = New-Object System.Windows.Forms.CheckBox
    $c.Location = New-Object System.Drawing.Point($x, $y)
    $c.Size = New-Object System.Drawing.Size($w, 22)
    $c.Font = $fBody
    $c.ForeColor = $cText
    $c.BackColor = [System.Drawing.Color]::Transparent
    if ($parent) { $parent.Controls.Add($c) } else { $form.Controls.Add($c) }
    Reg $c $chiave | Out-Null
    return $c
}

# ---------------------------------------------------------------- testata
Reg (New-Label "" 22 16 360 26 $fTitle $cText $null) "testata" | Out-Null
Reg (New-Label "" 24 42 360 18 $fLabel $cMuted $null) "sottotesta" | Out-Null

$cmbLang = New-Object System.Windows.Forms.ComboBox
$cmbLang.Location = New-Object System.Drawing.Point(398, 18)
$cmbLang.Size = New-Object System.Drawing.Size(100, 24)
$cmbLang.DropDownStyle = "DropDownList"
$cmbLang.Font = $fLabel
$cmbLang.BackColor = $cPanel; $cmbLang.ForeColor = $cText
$cmbLang.FlatStyle = "Flat"
[void]$cmbLang.Items.Add("Italiano")
[void]$cmbLang.Items.Add("English")
$cmbLang.SelectedIndex = $(if ($script:lang -eq "en") { 1 } else { 0 })
$form.Controls.Add($cmbLang)

$btnDev = New-Btn "dev" 506 18 72 24 $cMuted $null

# ---------------------------------------------------------------- volume dei suoni
# Il volume del pannello (solo i suoi suoni, non quello di Windows): Windows
# tiene un volume per ogni programma, e waveOutSetVolume cambia il nostro.
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class VolumePannello {
    [DllImport("winmm.dll")] static extern int waveOutSetVolume(IntPtr h, uint v);
    public static void Imposta(int percento) {
        if (percento < 0) percento = 0;
        if (percento > 100) percento = 100;
        uint x = (uint)(percento * 0xFFFF / 100);
        waveOutSetVolume(IntPtr.Zero, x | (x << 16));
    }
}
"@
$volFile = Join-Path $here "volume.txt"
$script:volume = 80
if (Test-Path $volFile) {
    $v = 0
    if ([int]::TryParse((Get-Content $volFile -Raw).Trim(), [ref]$v)) { $script:volume = [Math]::Max(0, [Math]::Min(100, $v)) }
}
try { [VolumePannello]::Imposta($script:volume) } catch { }

$volCtl = New-Object System.Windows.Forms.Label
$volCtl.Location = New-Object System.Drawing.Point(398, 50)
$volCtl.Size = New-Object System.Drawing.Size(180, 18)
$volCtl.BackColor = [System.Drawing.Color]::Transparent
$volCtl.Cursor = [System.Windows.Forms.Cursors]::Hand
$form.Controls.Add($volCtl)
$script:volTrascina = $false
$script:volIcona = New-Object System.Drawing.Font("Segoe MDL2 Assets", 9)
$script:volTesto = New-Object System.Drawing.Font("Segoe UI", 8)

function Vol-DaMouse($x) {
    $x0 = 22; $x1 = $volCtl.Width - 36
    $p = [int][Math]::Round(($x - $x0) * 100.0 / ($x1 - $x0))
    $script:volume = [Math]::Max(0, [Math]::Min(100, $p))
    try { [VolumePannello]::Imposta($script:volume) } catch { }
    $volCtl.Invalidate()
}

$volCtl.Add_Paint({
    param($s, $e)
    $g = $e.Graphics
    $g.SmoothingMode = "AntiAlias"
    $g.TextRenderingHint = "ClearTypeGridFit"
    $cy = [single]($s.Height / 2)
    $v = $script:volume
    $glifo = if ($v -eq 0) { 0xE74F } elseif ($v -lt 34) { 0xE993 } elseif ($v -lt 67) { 0xE994 } else { 0xE995 }
    $grigio = [System.Drawing.Color]::FromArgb(200, 190, 196, 214)
    $br = New-Object System.Drawing.SolidBrush $grigio
    $g.DrawString([string][char]$glifo, $script:volIcona, $br, [single]0, [single]2)
    $x0 = [single]22; $x1 = [single]($s.Width - 36)
    $pen = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(70, 255, 255, 255)), 4
    $pen.StartCap = "Round"; $pen.EndCap = "Round"
    $g.DrawLine($pen, $x0, $cy, $x1, $cy)
    $xv = [single]($x0 + ($x1 - $x0) * $v / 100.0)
    if ($v -gt 0) {
        $pen2 = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(255, 255, 214, 90)), 4
        $pen2.StartCap = "Round"; $pen2.EndCap = "Round"
        $g.DrawLine($pen2, $x0, $cy, $xv, $cy)
        $pen2.Dispose()
    }
    $pomo = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::White)
    $g.FillEllipse($pomo, [single]($xv - 6), [single]($cy - 6), [single]12, [single]12)
    $g.DrawString("$v%", $script:volTesto, $br, [single]($x1 + 9), [single]1)
    $pen.Dispose(); $br.Dispose(); $pomo.Dispose()
})
$volCtl.Add_MouseDown({ param($s, $e) $script:volTrascina = $true; Vol-DaMouse $e.X })
$volCtl.Add_MouseMove({ param($s, $e) if ($script:volTrascina) { Vol-DaMouse $e.X } })
$volCtl.Add_MouseUp({
    param($s, $e)
    $script:volTrascina = $false
    Vol-DaMouse $e.X
    try { Set-Content -Path $volFile -Value "$($script:volume)" -NoNewline -Encoding ascii } catch { }
    Suona $script:sndOk               # per sentire subito com'e'
})
$volCtl.Add_MouseWheel({
    param($s, $e)
    $script:volume = [Math]::Max(0, [Math]::Min(100, $script:volume + [Math]::Sign($e.Delta) * 5))
    try { [VolumePannello]::Imposta($script:volume) } catch { }
    try { Set-Content -Path $volFile -Value "$($script:volume)" -NoNewline -Encoding ascii } catch { }
    $volCtl.Invalidate()
})

# i suoni del gioco: quello del puntamento e quello della conferma
function Carica-Suono($nome) {
    $f = Join-Path $here $nome
    if (-not (Test-Path $f)) { return $null }
    try {
        $sp = New-Object System.Media.SoundPlayer $f
        $sp.Load()          # in memoria adesso: al primo passaggio non deve esitare
        return $sp
    } catch { return $null }
}
$script:sndFocus = Carica-Suono "suono-focus.wav"
$script:sndOk = Carica-Suono "suono-ok.wav"
$script:sndAnnulla = Carica-Suono "suono-annulla.wav"
$script:sndDevOn = Carica-Suono "suono-dev-on.wav"
$script:sndDevOff = Carica-Suono "suono-dev-off.wav"

function Suona($sp) {
    if ($null -eq $sp) { return }
    try { $sp.Play() } catch { }     # Play() non blocca: il pannello non si ferma
}


# ---------------------------------------------------------------- stato
$statusPanel = New-Object System.Windows.Forms.Panel
$statusPanel.Location = New-Object System.Drawing.Point($M, 72)
$statusPanel.Size = New-Object System.Drawing.Size($CW, 74)
$statusPanel.BackColor = $cPanel
$form.Controls.Add($statusPanel)
Set-Glass $statusPanel 140
Round-Ctl $statusPanel 10

$dot = New-Object System.Windows.Forms.Label
$dot.Text = [char]0x25CF
$dot.Font = New-Object System.Drawing.Font("Segoe UI", 20)
$dot.ForeColor = $cOff
$dot.Location = New-Object System.Drawing.Point(16, 17)
$dot.Size = New-Object System.Drawing.Size(32, 38)
$dot.BackColor = [System.Drawing.Color]::Transparent
$statusPanel.Controls.Add($dot)

$lblStatus = New-Label "" 50 15 280 24 $fStatus $cText $statusPanel
$lblDetail = New-Label "" 52 41 330 20 $fLabel $cMuted $statusPanel

$btnToggle = New-Object System.Windows.Forms.Button
$btnToggle.Location = New-Object System.Drawing.Point(418, 19)
$btnToggle.Size = New-Object System.Drawing.Size(120, 36)
$btnToggle.FlatStyle = "Flat"
$btnToggle.FlatAppearance.BorderSize = 0
$btnToggle.BackColor = $cOn
$btnToggle.ForeColor = [System.Drawing.Color]::FromArgb(20, 32, 24)
$btnToggle.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 10)
$statusPanel.Controls.Add($btnToggle)
Round-Ctl $btnToggle 8

# Il tasto Avvia/Ferma usa la stessa pillola, in due tinte: chiara da fermo,
# rossa mentre il server gira, se no non si capirebbe lo stato.
$script:pill = @{}
if ($null -ne $script:pillA) {
    $script:pill["fermo"]  = Componi $btnToggle $script:pillA "chiaro"
    $script:pill["fermo2"] = Componi $btnToggle $script:pillB "chiaro"
    $script:pill["acceso"]  = Componi $btnToggle $script:pillA "rosso"
    $script:pill["acceso2"] = Componi $btnToggle $script:pillB "rosso"
    $btnToggle.FlatAppearance.BorderSize = 0
    $btnToggle.FlatAppearance.MouseOverBackColor = [System.Drawing.Color]::Transparent
    $btnToggle.FlatAppearance.MouseDownBackColor = [System.Drawing.Color]::Transparent
    $btnToggle.BackgroundImageLayout = "None"
    $btnToggle.Add_MouseEnter({ Aggiorna-Pillola $true })
    $btnToggle.Add_MouseLeave({ Aggiorna-Pillola $false })
}

$script:sopraToggle = $false
function Aggiorna-Pillola($sopra) {
    if ($script:pill.Count -eq 0) { return }
    $script:sopraToggle = $sopra
    $acceso = Test-Running
    $nome = $(if ($acceso) { "acceso" } else { "fermo" })
    if ($sopra) { $nome += "2" }
    $btnToggle.BackgroundImage = $script:pill[$nome]
    if ($acceso) {
        $btnToggle.ForeColor = $INCHIOSTRO["rosso"]
    } else {
        $btnToggle.ForeColor = $INCHIOSTRO["chiaro"]
    }
}

# ---------------------------------------------------------------- porta e ff
$lblPort = Reg (New-Label "" $M 158 120 18 $fLabel $cMuted $null) "porta"
$txtPort = New-Box "5029" $M 178 90 $cText $null
$lblPlayers = New-Label "" 130 182 230 20 $fBody $cText $null

$chkFF = New-Chk "ff" 430 180 148 $null
$chkFF.Checked = ((Test-Path $ffFile) -and ((Get-Content $ffFile -Raw -ErrorAction SilentlyContinue) -match '^1'))

function Write-FriendlyFire {
    $v = "0"
    if ($chkFF.Checked) { $v = "1" }
    Set-Content -Path $ffFile -Value $v -NoNewline -Encoding ascii
}

# ---------------------------------------------------------------- indirizzo
Reg (New-Label "" $M 218 300 18 $fLabel $cMuted $null) "indirizzo" | Out-Null
$script:nascondiIp = $false
if (Test-Path $hideFile) { $script:nascondiIp = ((Get-Content $hideFile -Raw).Trim() -eq "1") }
$chkHide = New-Chk "hideIp" 440 214 138 $null
$chkHide.Font = $fLabel
$chkHide.Checked = $script:nascondiIp

$addrPanel = New-Object System.Windows.Forms.Panel
$addrPanel.Location = New-Object System.Drawing.Point($M, 238)
$addrPanel.Size = New-Object System.Drawing.Size($CW, 52)
$addrPanel.BackColor = $cPanel
$form.Controls.Add($addrPanel)
Set-Glass $addrPanel 140
Round-Ctl $addrPanel 10

$cmbAddr = New-Object System.Windows.Forms.ComboBox
$cmbAddr.Location = New-Object System.Drawing.Point(14, 13)
$cmbAddr.Size = New-Object System.Drawing.Size(396, 28)
$cmbAddr.DropDownStyle = "DropDownList"
$cmbAddr.Font = $fAddr
$cmbAddr.BackColor = $cPanel; $cmbAddr.ForeColor = $cAccent
$cmbAddr.FlatStyle = "Flat"
$addrPanel.Controls.Add($cmbAddr)

$btnCopy = New-Btn "copia" 424 12 118 30 $cMuted $addrPanel

# ---------------------------------------------------------------- registro
Reg (New-Label "" $M 302 200 18 $fLabel $cMuted $null) "registro" | Out-Null

$txtLog = New-Object System.Windows.Forms.TextBox
$txtLog.Location = New-Object System.Drawing.Point($M, 322)
$txtLog.Size = New-Object System.Drawing.Size($CW, 148)
$txtLog.Multiline = $true
$txtLog.ScrollBars = "Vertical"
$txtLog.ReadOnly = $true
$txtLog.Font = $fMono
$txtLog.BackColor = [System.Drawing.Color]::FromArgb(18, 18, 27)
$txtLog.ForeColor = [System.Drawing.Color]::FromArgb(150, 210, 180)
$txtLog.BorderStyle = "FixedSingle"
$form.Controls.Add($txtLog)
Round-Ctl $txtLog 6

$btnClear = New-Btn "pulisci" $M 478 130 28 $cMuted $null

# ---------------------------------------------------------------- partita
New-Section "partita" 524 | Out-Null

$btnTp = New-Btn "tp" $M 552 190 30 $cOn $null "verde"
Reg (New-Label "" 222 558 40 16 $fLabel $cMuted $null) "slot" | Out-Null
$txtTp = New-Box "" 262 552 40 $cOn $null
$lblTpNota = Reg (New-Label "" 312 550 266 32 $fLabel $cMuted $null) "tpNota"

$lblNome = Reg (New-Label "" $M 594 400 18 $fLabel $cMuted $null) "nome"
$txtName = New-Object System.Windows.Forms.TextBox
$txtName.Location = New-Object System.Drawing.Point($M, 614)
$txtName.Size = New-Object System.Drawing.Size(220, 26)
$txtName.Font = $fBody
$txtName.MaxLength = 15
$txtName.BackColor = [System.Drawing.Color]::FromArgb(22, 22, 32); $txtName.ForeColor = $cAccent
$txtName.BorderStyle = "FixedSingle"
if (Test-Path $nameFile) { $txtName.Text = (Get-Content $nameFile -Raw).Trim() }
if ([string]::IsNullOrWhiteSpace($txtName.Text)) { $txtName.Text = "Il mio server" }
$form.Controls.Add($txtName)

$btnName = New-Btn "salvaNome" 252 613 100 28 $cAccent $null "ambra"

# ---------------------------------------------------------------- personaggio
# La scelta sta nella riga @luigi del servers.txt che il gioco legge: la stessa
# che scrive il pannello client, cosi' i due pannelli su questo PC vanno d'accordo.
$riivServers = @((Join-Path $env:APPDATA "Dolphin Emulator\Load\Riivolution\servers.txt"),
                 (Join-Path $env:APPDATA "Dolphin Emulator\Load\Riivolution\riivolution\servers.txt"))
function Leggi-Luigi {
    foreach ($f in $riivServers) {
        if (Test-Path $f) { return (@(Get-Content $f | Where-Object { $_.Trim() -eq "@luigi" }).Count -gt 0) }
    }
    return $false
}
$script:luigi = Leggi-Luigi
$btnLuigi = New-Btn $null 362 612 216 32 $cAccent $null "rosso"
$btnLuigi.Padding = New-Object System.Windows.Forms.Padding(26, 0, 0, 0)
function Carica-Icona($nome) {
    $f = Join-Path $here $nome
    if (-not (Test-Path $f)) { return $null }
    try {
        $byte = [System.IO.File]::ReadAllBytes($f)
        return [System.Drawing.Image]::FromStream((New-Object System.IO.MemoryStream (,$byte)))
    } catch { return $null }
}
$script:icoLuigi = Carica-Icona "icona-luigi.png"
$script:icoMario = Carica-Icona "icona-mario.png"
function Con-Faccia($img) {
    $ico = $(if ($script:luigi) { $script:icoLuigi } else { $script:icoMario })
    if ($null -eq $ico) { return $img }
    $g = [System.Drawing.Graphics]::FromImage($img)
    $g.InterpolationMode = "HighQualityBicubic"
    $h = $btnLuigi.Height - 8
    $w = [int]($ico.Width * $h / $ico.Height)
    $g.DrawImage($ico, 12, 4, $w, $h)
    $g.Dispose()
    return $img
}
function Aggiorna-Luigi {
    $tinta = $(if ($script:luigi) { "verde" } else { "rosso" })
    if ($null -ne $script:pillA) {
        $btnLuigi.Tag = @{ Fermo = (Con-Faccia (Componi $btnLuigi $script:pillA $tinta)); Sopra = (Con-Faccia (Componi $btnLuigi $script:pillB $tinta)) }
        $btnLuigi.BackgroundImage = $btnLuigi.Tag.Fermo
        $btnLuigi.ForeColor = $INCHIOSTRO[$tinta]
    }
    $btnLuigi.Text = T $(if ($script:luigi) { "luigiBtn" } else { "marioBtn" })
}
Aggiorna-Luigi
$btnLuigi.Add_Click({
    $script:luigi = -not $script:luigi
    foreach ($f in $riivServers) {
        if (-not (Test-Path (Split-Path $f))) { continue }
        $righe = @()
        if (Test-Path $f) { $righe = @(Get-Content $f | Where-Object { $_.Trim() -ne "@luigi" }) }
        if ($script:luigi) { $righe = @("@luigi") + $righe }
        Set-Content -Path $f -Value (($righe -join "`r`n") + "`r`n") -NoNewline -Encoding ascii
    }
    Aggiorna-Luigi
    Log-Riga ((T "logLuigi") -f $(if ($script:luigi) { "Luigi" } else { "Mario" }))
    Suona $script:sndOk
})

$chkShare = New-Chk "condividi" $M 654 400 $null
$lblCondNota = Reg (New-Label "" $M 678 540 18 $fLabel $cMuted $null) "condNota"

# ---------------------------------------------------------------- strumenti
$lblDevSec = New-Section "strumenti" 710
$lblDevLine = $script:ultimaRiga

$devPanel = New-Object System.Windows.Forms.Panel
$devPanel.Location = New-Object System.Drawing.Point($M, 736)
$devPanel.Size = New-Object System.Drawing.Size($CW, 202)
$devPanel.BackColor = $cPanel2
$form.Controls.Add($devPanel)
Set-Glass $devPanel 170
Round-Ctl $devPanel 10

$btnTest = New-Btn "testPlayer" 14 14 150 30 $cAccent $devPanel "ambra"
Reg (New-Label "" 174 20 60 16 $fLabel $cMuted $devPanel) "distanza" | Out-Null
$txtSpacing = New-Box "$TEST_SPACING" 232 14 56 $cAccent $devPanel
Reg (New-Label "" 298 12 244 32 $fLabel $cMuted $devPanel) "distNota" | Out-Null

$btnStar = New-Btn "stella" 14 52 150 30 $cAccent $devPanel "ambra"
Reg (New-Label "" 174 58 60 16 $fLabel $cMuted $devPanel) "numero" | Out-Null
$txtStar = New-Box "1" 232 52 46 $cAccent $devPanel
Reg (New-Label "" 298 50 244 18 $fLabel $cMuted $devPanel) "stellaNota" | Out-Null
$chkSeq = New-Chk "senzaStella" 298 68 250 $devPanel
$chkSeq.Font = $fLabel

$btnChip = New-Btn "pezzetto" 14 90 150 30 $cAccent $devPanel "ambra"
Reg (New-Label "" 174 96 368 18 $fLabel $cMuted $devPanel) "pezzNota" | Out-Null

Reg (New-Label "" 14 128 300 16 $fLabel $cMuted $devPanel) "punto" | Out-Null
$txtWarp = New-Box "" 14 146 200 $cAccent $devPanel
if (Test-Path $warpFile) { $txtWarp.Text = (Get-Content $warpFile -Raw).Trim() }
$btnWarpSave = New-Btn "salvaPunto" 222 145 168 28 $cMuted $devPanel
$btnWarpGo = New-Btn "vaiPunto" 398 145 144 28 $cAccent $devPanel "ambra"

$btnKill = New-Btn "uccidi" 398 178 144 24 $cOff $devPanel "rosso"
Reg (New-Label "" 14 180 370 18 $fLabel $cMuted $devPanel) "uccidiNota" | Out-Null

# ---------------------------------------------------------------- dev on/off
$script:dev = $false
if (Test-Path $devFile) {
    $script:dev = ((Get-Content $devFile -Raw -ErrorAction SilentlyContinue).Trim() -eq "1")
}

# La finestra non salta da un'altezza all'altra: ci arriva in dieci passi da
# 16 millesimi, svelta all'inizio e morbida alla fine. La sezione degli
# strumenti si accende prima di crescere e si spegne dopo essersi ritirata,
# cosi' si vede scorrere invece di comparire di colpo.
$ALTO = 1000
$BASSO = 758

$script:dvA = 0
$script:dvB = 0
$script:dvI = 0
$script:dvN = 10
$devTime = New-Object System.Windows.Forms.Timer
$devTime.Interval = 16
$devTime.Add_Tick({
    $script:dvI++
    $q = $script:dvI / $script:dvN
    if ($q -ge 1) {
        $devTime.Stop()
        $form.Height = $script:dvB
        if (-not $script:dev) {
            $lblDevSec.Visible = $false
            $lblDevLine.Visible = $false
            $devPanel.Visible = $false
        }
        return
    }
    $e = 1 - [Math]::Pow(1 - $q, 3)
    $form.Height = [int]($script:dvA + ($script:dvB - $script:dvA) * $e)
})

function Apply-Dev($animato = $false) {
    $meta = $(if ($script:dev) { $ALTO } else { $BASSO })

    if ($animato) {
        if ($script:dev) {
            # in salita si accende subito: deve gia' esserci mentre si scopre
            $lblDevSec.Visible = $true
            $lblDevLine.Visible = $true
            $devPanel.Visible = $true
        }
        $devTime.Stop()
        $script:dvA = $form.Height
        $script:dvB = $meta
        $script:dvI = 0
        $devTime.Start()
    } else {
        $devTime.Stop()
        $lblDevSec.Visible = $script:dev
        $lblDevLine.Visible = $script:dev
        $devPanel.Visible = $script:dev
        $form.Size = New-Object System.Drawing.Size($W, $meta)
    }

    if ($null -ne $script:pillA) {
        $t = $(if ($script:dev) { "ambra" } else { "chiaro" })
        $btnDev.Tag = @{ Fermo = (Componi $btnDev $script:pillA $t); Sopra = (Componi $btnDev $script:pillB $t) }
        $btnDev.BackgroundImage = $btnDev.Tag.Fermo
        $btnDev.ForeColor = $INCHIOSTRO[$t]
    } elseif ($script:dev) {
        $btnDev.ForeColor = $cAccent
        $btnDev.FlatAppearance.BorderColor = $cAccent
    } else {
        $btnDev.ForeColor = $cMuted
        $btnDev.FlatAppearance.BorderColor = $cMuted
    }
    Set-Content -Path $devFile -Value $(if ($script:dev) { "1" } else { "0" }) -NoNewline -Encoding ascii
}

$btnDev.Add_Click({
    $script:dev = -not $script:dev
    Suona $(if ($script:dev) { $script:sndDevOn } else { $script:sndDevOff })
    Apply-Dev $true
})

# ---------------------------------------------------------------- azioni
# Attesa che non congela la finestra: a pezzetti, lasciando disegnare. Senza
# questo, durante l'avvio del server la schermata resta mezza ridipinta.
function Aspetta($ms) {
    $fine = (Get-Date).AddMilliseconds($ms)
    while ((Get-Date) -lt $fine) {
        [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 40
    }
}

function Test-Running {
    return ($null -ne $script:proc -and -not $script:proc.HasExited)
}


# ---------------------------------------------------------------- nascondi IP
# Per i video: gli indirizzi si vedono come ***.***.***.***. Il registro si
# tiene anche "in chiaro" da parte, cosi' spegnendo l'opzione torna leggibile.
$script:logRaw = New-Object System.Text.StringBuilder
function Maschera($t) {
    if ($null -eq $t) { return $t }
    if (-not $script:nascondiIp) { return $t }
    return [regex]::Replace([string]$t, '\b\d{1,3}(\.\d{1,3}){3}\b', '***.***.***.***')
}

function Append-Log($text) {
    if ([string]::IsNullOrWhiteSpace($text)) { return }
    [void]$script:logRaw.Append($text)
    $txtLog.AppendText((Maschera $text))
    $txtLog.SelectionStart = $txtLog.TextLength
    $txtLog.ScrollToCaret()
}

function Pulisci-Log {
    [void]$script:logRaw.Clear()
    $txtLog.Clear()
}

function Log-Riga($testo) { Append-Log "`r`n$testo`r`n" }

function Show-Msg($testo, $titolo, $tipo) {
    [System.Windows.Forms.MessageBox]::Show($testo, $titolo, "OK", $tipo) | Out-Null
}

function Need-Running {
    if (Test-Running) { return $true }
    Show-Msg (T "mbFermo") (T "mbFermoT") "Information"
    return $false
}

function Need-File($percorso, $nome) {
    if (Test-Path $percorso) { return $true }
    Show-Msg ((T "mbManca") -f $nome, $here) (T "mbMancaT") "Error"
    return $false
}

function Update-TestButton {
    if ($script:testCount -gt 0) {
        $btnTest.Text = (T "testPlayerN") -f $script:testCount, $MAX_TEST
    } else {
        $btnTest.Text = T "testPlayer"
    }
}

function Update-Status {
    if (Test-Running) {
        $dot.ForeColor = $cOn
        $lblStatus.Text = T "acceso"
        $lblDetail.Text = (T "dettAcceso") -f $txtPort.Text, $script:proc.Id
        $btnToggle.Text = T "ferma"
        $btnToggle.BackColor = $cOff
        $btnToggle.ForeColor = [System.Drawing.Color]::White
        Aggiorna-Pillola $script:sopraToggle
        $txtPort.Enabled = $false
        $lblPlayers.Text = (T "giocatori") -f $script:players.Count
    } else {
        $dot.ForeColor = $cOff
        $lblStatus.Text = T "spento"
        $lblDetail.Text = T "dettSpento"
        $btnToggle.Text = T "avvia"
        $btnToggle.BackColor = $cOn
        $btnToggle.ForeColor = [System.Drawing.Color]::FromArgb(20, 32, 24)
        Aggiorna-Pillola $script:sopraToggle
        $txtPort.Enabled = $true
        $lblPlayers.Text = (T "giocatori") -f 0
    }
}

function Apply-Language {
    foreach ($e in $script:testi) { $e.C.Text = T $e.K }
    $form.Text = T "titolo"
    Update-Status
    Update-TestButton
    Set-Content -Path $langFile -Value $script:lang -NoNewline -Encoding ascii
}

$cmbLang.Add_SelectedIndexChanged({
    $script:lang = $(if ($cmbLang.SelectedIndex -eq 1) { "en" } else { "it" })
    Apply-Language
})

$chkFF.Add_CheckedChanged({
    Write-FriendlyFire
    if ($chkFF.Checked) { Append-Log ((T "ffOn") + "`r`n") } else { Append-Log ((T "ffOff") + "`r`n") }
})

# ---------------------------------------------------------------- indirizzi
function Get-Addresses {
    $list = @()
    try {
        $ips = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
               Where-Object { $_.IPAddress -notlike "127.*" -and $_.IPAddress -notlike "169.254.*" }
        foreach ($ip in $ips) {
            $tag = $ip.InterfaceAlias
            if ($tag -like "*Radmin*")   { $list += [pscustomobject]@{ Sort = 0; Text = "$($ip.IPAddress)   (Radmin VPN)"; Ip = $ip.IPAddress } }
            elseif ($tag -like "*Wi-Fi*" -or $tag -like "*Ethernet*") {
                if ($ip.IPAddress -notlike "192.168.56.*" -and $ip.IPAddress -notlike "192.168.244.*" -and
                    $ip.IPAddress -notlike "192.168.31.*"  -and $ip.IPAddress -notlike "192.168.137.*" -and
                    $ip.IPAddress -notlike "172.2*") {
                    $list += [pscustomobject]@{ Sort = 1; Text = "$($ip.IPAddress)   (LAN)"; Ip = $ip.IPAddress }
                }
            }
        }
    } catch { }
    $list += [pscustomobject]@{ Sort = 2; Text = "127.0.0.1   (localhost)"; Ip = "127.0.0.1" }
    return $list | Sort-Object Sort
}

$script:addrList = Get-Addresses
function Riempi-Indirizzi {
    $scelto = $cmbAddr.SelectedIndex
    $cmbAddr.Items.Clear()
    foreach ($a in $script:addrList) { [void]$cmbAddr.Items.Add((Maschera $a.Text)) }
    if ($scelto -ge 0 -and $scelto -lt $cmbAddr.Items.Count) { $cmbAddr.SelectedIndex = $scelto }
}
Riempi-Indirizzi
if ($cmbAddr.Items.Count -gt 0) { $cmbAddr.SelectedIndex = 0 }

function Update-HostSlot {
    # Una volta scelto non si cambia piu': con piu' indirizzi di questo PC
    # (rete di casa, VPN, 127.0.0.1) e le connessioni vecchie rimaste appese,
    # il posto "piu' basso" cambiava da solo e il comando dei boss saltava da
    # un gioco all'altro. Si riparte solo riavviando il server.
    if ($script:hostSlot -ge 0) { return }
    $mine = @($script:addrList | ForEach-Object { $_.Ip })
    $trovati = @($script:players.Keys | Where-Object { $mine -contains $script:players[$_] } |
                 ForEach-Object { [int]$_ } | Sort-Object)
    if ($trovati.Count -eq 0) { return }
    if ($trovati[0] -eq $script:hostSlot) { return }
    $script:hostSlot = $trovati[0]
    Set-Content -Path $hostFile -Value "$($script:hostSlot)" -NoNewline -Encoding ascii
    Log-Riga ((T "logHost") -f $script:hostSlot)
}

# ---------------------------------------------------------------- server
function Start-Server {
    if (-not (Need-File $exePath "SMGServer.exe")) { return }
    $port = 5029
    if (-not [int]::TryParse($txtPort.Text, [ref]$port) -or $port -lt 1 -or $port -gt 65535) {
        Show-Msg (T "mbPorta") (T "mbPortaT") "Warning"
        return
    }
    # Un'altra istanza terrebbe occupata la porta e il nuovo processo
    # morirebbe subito con l'errore 10048.
    $orphans = @(Get-Process -Name SMGServer -ErrorAction SilentlyContinue)
    if ($orphans.Count -gt 0) {
        $ids = ($orphans | ForEach-Object { $_.Id }) -join ", "
        $answer = [System.Windows.Forms.MessageBox]::Show(
            ((T "mbGia") -f $ids), (T "mbGiaT"), "YesNo", "Question")
        if ($answer -ne "Yes") { return }
        $orphans | Stop-Process -Force -ErrorAction SilentlyContinue
        Aspetta 800
    }

    Remove-Item $outLog, $errLog -ErrorAction SilentlyContinue
    $script:offsets[$outLog] = 0
    $script:offsets[$errLog] = 0
    $script:players = @{}
    Pulisci-Log
    try {
        # il file di controllo va scritto prima: il server lo legge subito
        Write-FriendlyFire
        $ffArg = "--friendly-fire=off"
        if ($chkFF.Checked) { $ffArg = "--friendly-fire=on" }
        $script:proc = Start-Process -FilePath $exePath `
            -ArgumentList "$port", "0.0.0.0", $ffArg, "--controllo", "`"$ffFile`"", "--tp", "`"$tpFile`"", "--host", "`"$hostFile`"", "--bye", "`"$byeFile`"", "--players", "`"$playersFile`"" `
            -PassThru -WindowStyle Hidden `
            -RedirectStandardOutput $outLog -RedirectStandardError $errLog
    } catch {
        Show-Msg ((T "mbErrore") -f $_) (T "mbErroreT") "Error"
        $script:proc = $null
        return
    }

    # Se il bind fallisce il processo muore subito: meglio dirlo chiaramente
    # invece di lasciare la finestra su "Fermo" senza spiegazioni.
    Aspetta 1200
    if ($script:proc.HasExited) {
        $why = ""
        foreach ($f in @($errLog, $outLog)) {
            if (Test-Path $f) { $why += (Get-Content $f -Raw) }
        }
        $msg = T "mbChiuso"
        if ($why -match '10048') {
            $msg = (T "mbOccupata") -f $port
        } elseif ($why.Trim()) {
            $msg += "`n`n" + $why.Trim()
        }
        Show-Msg $msg (T "mbChiusoT") "Warning"
        $script:proc = $null
    }
}

function Stop-TestPlayers {
    if ($script:testProc -and -not $script:testProc.HasExited) {
        try { $script:testProc.Kill() } catch { }
    }
    Get-Process -Name TestPlayers -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    $script:testProc = $null
}

function Stop-Share {
    if ($script:shareProc -and -not $script:shareProc.HasExited) {
        try { $script:shareProc.Kill() } catch { }
    }
    $script:shareProc = $null
}

function Stop-Server {
    $script:hostSlot = -1
    Remove-Item $hostFile -ErrorAction SilentlyContinue
    Remove-Item $byeFile -ErrorAction SilentlyContinue
    # senza server le copie di test non hanno piu' niente a cui collegarsi
    Stop-TestPlayers
    $script:testCount = 0
    Update-TestButton
    if (Test-Running) { try { $script:proc.Kill() } catch { } }
    $script:proc = $null
}

$btnToggle.Add_Click({
    if (Test-Running) {
        Suona $script:sndAnnulla     # il suono di quando si annulla, nel gioco
        Stop-Server
    } else {
        Suona $script:sndOk
        Start-Server
    }
    Update-Status
})

$btnCopy.Add_Click({
    if ($cmbAddr.SelectedIndex -lt 0) { return }
    $ip = $script:addrList[$cmbAddr.SelectedIndex].Ip
    $port = $txtPort.Text.Trim()
    Set-Clipboard -Value "${ip}:${port}"
    $btnCopy.Text = T "copiato"
    $script:copyTimer = New-Object System.Windows.Forms.Timer
    $script:copyTimer.Interval = 1200
    $script:copyTimer.Add_Tick({
        $btnCopy.Text = T "copia"
        $script:copyTimer.Stop()
    })
    $script:copyTimer.Start()
})

$btnClear.Add_Click({ Pulisci-Log })

$chkHide.Add_CheckedChanged({
    $script:nascondiIp = $chkHide.Checked
    Set-Content -Path $hideFile -Value $(if ($script:nascondiIp) { "1" } else { "0" }) -NoNewline -Encoding ascii
    Riempi-Indirizzi
    $txtLog.Text = (Maschera $script:logRaw.ToString())
    $txtLog.SelectionStart = $txtLog.TextLength
    $txtLog.ScrollToCaret()
})

$btnName.Add_Click({
    $n = $txtName.Text.Trim()
    if ($n -eq "") { $n = "Il mio server" }
    $txtName.Text = $n
    Set-Content -Path $nameFile -Value $n -NoNewline -Encoding ascii
    Log-Riga ((T "logNome") -f $n)
})

$chkShare.Add_CheckedChanged({
    if ($chkShare.Checked) {
        if (-not (Test-Path $shareScript)) {
            Show-Msg ((T "mbManca") -f "SaveShare.ps1", $here) (T "mbMancaT") "Error"
            $chkShare.Checked = $false
            return
        }
        Remove-Item $shareLog -ErrorAction SilentlyContinue
        try {
            Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
                Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -like ("*-File*" + $shareScript + "*-LogFile*") } |
                ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
        } catch { }
        try {
            $script:shareProc = Start-Process -FilePath "powershell.exe" `
                -ArgumentList "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$shareScript`"", `
                              "-LogFile", "`"$shareLog`"" `
                -PassThru -WindowStyle Hidden
        } catch {
            Log-Riga ((T "logNoParte") -f "SaveShare", $_)
            $chkShare.Checked = $false
            return
        }
        Start-Sleep -Milliseconds 600
        $why = ""
        if (Test-Path $shareLog) { $why = (Get-Content $shareLog -Raw) }
        if ($script:shareProc.HasExited) {
            Log-Riga ((T "logCondNo") + "`r`n" + $why)
            $chkShare.Checked = $false
            return
        }
        Log-Riga ((T "logCond") + "`r`n" + $why)
        if (-not $script:avvioShare) { Set-Content -Path $shareFile -Value "1" -NoNewline -Encoding ascii }
    } else {
        Stop-Share
        Log-Riga (T "logNoCond")
        if (-not $script:avvioShare) { Set-Content -Path $shareFile -Value "0" -NoNewline -Encoding ascii }
    }
})

$btnTp.Add_Click({
    if (-not (Need-Running)) { return }
    $slot = -1
    $t = $txtTp.Text.Trim()
    if ($t -ne "") {
        if (-not [int]::TryParse($t, [ref]$slot) -or $slot -lt 0 -or $slot -gt 7) {
            Show-Msg (T "mbSlot") (T "mbSlotT") "Warning"
            return
        }
    } else {
        # il gioco su questo PC e' quello collegato da un indirizzo di questo PC
        $mine = @($script:addrList | ForEach-Object { $_.Ip })
        $found = @($script:players.Keys | Where-Object { $mine -contains $script:players[$_] } |
                   ForEach-Object { [int]$_ } | Sort-Object)
        if ($found.Count -eq 0) {
            Show-Msg (T "mbTp") (T "mbTpT") "Information"
            return
        }
        $slot = $found[0]
        if ($found.Count -gt 1) { Log-Riga ((T "logTpMulti") -f $slot) }
    }
    Set-Content -Path $tpFile -Value "$slot" -NoNewline -Encoding ascii
    Log-Riga ((T "logTp") -f $slot)
})

# ---------------------------------------------------------------- strumenti
$btnTest.Add_Click({
    if (-not (Need-Running)) { return }
    if (-not (Need-File $testExe "TestPlayers.exe")) { return }

    $script:testCount++
    if ($script:testCount -gt $MAX_TEST) { $script:testCount = 0 }

    # Il numero passa da un file: il processo apre le connessioni una volta
    # sola e cambia solo quante ne anima. Riavviarlo a ogni pressione
    # bruciava gli slot del server.
    $sp = $TEST_SPACING
    [void][int]::TryParse($txtSpacing.Text.Trim(), [ref]$sp)
    if ($sp -lt 20) { $sp = 20 }
    if ($sp -gt 2000) { $sp = 2000 }
    $txtSpacing.Text = "$sp"

    Set-Content -Path $testCtl -Value "$($script:testCount) $sp" -NoNewline -Encoding ascii

    if ($script:testCount -eq 0) {
        Stop-TestPlayers
        Update-TestButton
        Log-Riga (T "logTestOff")
        return
    }

    $alive = $script:testProc -and -not $script:testProc.HasExited
    if (-not $alive) {
        Remove-Item $testLog, "$testLog.err" -ErrorAction SilentlyContinue
        try {
            $script:testProc = Start-Process -FilePath $testExe `
                -ArgumentList "$($txtPort.Text)", "$sp", "`"$testCtl`"" `
                -PassThru -WindowStyle Hidden `
                -RedirectStandardOutput $testLog -RedirectStandardError "$testLog.err"
        } catch {
            Log-Riga ((T "logNoParte") -f "TestPlayers", $_)
            $script:testCount = 0
            Update-TestButton
            return
        }
        Start-Sleep -Milliseconds 900
        if ($script:testProc.HasExited) {
            $why = ""
            if (Test-Path $testLog) { $why = (Get-Content $testLog -Raw) }
            Log-Riga ((T "logTestNo") + "`r`n" + $why)
            $script:testCount = 0
            Update-TestButton
            return
        }
    }

    Update-TestButton
    Log-Riga ((T "logTestOn") -f $script:testCount, $sp, ($script:testCount * $sp))
    if ($script:testCount -eq $MAX_TEST) { Append-Log (T "logTestMax") }
})

$btnStar.Add_Click({
    if (-not (Need-Running)) { return }
    $vivo = ($script:testProc -and -not $script:testProc.HasExited)
    if (-not $vivo -and -not (Need-File $starExe "StarSpawn.exe")) { return }
    $id = 0
    if (-not [int]::TryParse($txtStar.Text.Trim(), [ref]$id) -or $id -lt 0 -or $id -gt 255) {
        Show-Msg (T "mbNumero") (T "mbNumeroT") "Warning"
        return
    }
    $label = "$id"
    if ($chkSeq.Checked) {
        if ($id -eq 0) {
            Show-Msg (T "mbSenza") (T "mbSenzaT") "Warning"
            return
        }
        $id = $id -bor 0x80          # il mod: non cercare la stella, parti e basta
        $label = "$($id -band 0x7F) *"
    }

    # Coi Test player accesi tutti gli slot del server possono essere occupati:
    # l'annuncio allora lo fa il primo Mario finto, che e' gia' collegato.
    if ($vivo) {
        if ($null -eq $script:starSeq) { $script:starSeq = 0 }
        $script:starSeq++
        $sp = $TEST_SPACING
        [void][int]::TryParse($txtSpacing.Text.Trim(), [ref]$sp)
        Set-Content -Path $testCtl -Value "$($script:testCount) $sp $id $($script:starSeq)" -NoNewline -Encoding ascii
        Log-Riga ((T "logStellaTp") -f $label)
        return
    }
    # A chi ha quella stella nella propria scena compare addosso e la prende:
    # finisce il livello, come una stella vera.
    $out = Join-Path $env:TEMP "starspawn.out"
    Remove-Item $out -ErrorAction SilentlyContinue
    try {
        Start-Process -FilePath $starExe -ArgumentList "$($txtPort.Text)", "$id" `
            -WindowStyle Hidden -Wait -RedirectStandardOutput $out | Out-Null
    } catch {
        Log-Riga ((T "logNoParte") -f "StarSpawn", $_)
        return
    }
    $msg = ""
    if (Test-Path $out) { $msg = (Get-Content $out -Raw) }
    Log-Riga ((T "logStella") -f $label) ; Append-Log "$msg`r`n"
    if ($msg -match 'pieno') { Append-Log (T "logPieno") }
})

$btnChip.Add_Click({
    if (-not (Need-Running)) { return }
    if (-not (Need-File $chipExe "ChipTest.exe")) { return }
    $out = Join-Path $env:TEMP "chiptest.out"
    Remove-Item $out -ErrorAction SilentlyContinue
    try {
        Start-Process -FilePath $chipExe -ArgumentList "127.0.0.1", "$($txtPort.Text)", "1" `
            -WindowStyle Hidden -Wait -RedirectStandardOutput $out | Out-Null
    } catch {
        Log-Riga ((T "logNoParte") -f "ChipTest", $_)
        return
    }
    $msg = ""
    if (Test-Path $out) { $msg = (Get-Content $out -Raw) }
    Log-Riga (T "logPezzetto") ; Append-Log "$msg`r`n"
    if ($msg -match 'pieno') { Append-Log (T "logPienoT") }
})

function Invoke-Warp($argomenti) {
    if (-not (Need-Running)) { return $null }
    if (-not (Need-File $warpExe "Warp.exe")) { return $null }
    $tutti = @("$($txtPort.Text)") + $argomenti
    $out = & $warpExe @tutti 2>&1 | Out-String
    return $out.Trim()
}

$btnWarpSave.Add_Click({
    $out = Invoke-Warp @("leggi")
    if ($null -eq $out) { return }
    Log-Riga ((T "logPos") -f $out)
    if ($out -match '^OK\s+(\S+)\s+(\S+)\s+(\S+)') {
        $txtWarp.Text = "$($matches[1]) $($matches[2]) $($matches[3])"
        Set-Content -Path $warpFile -Value $txtWarp.Text -NoNewline -Encoding ascii
    } else {
        Show-Msg (T "mbPos") (T "mbPosT") "Warning"
    }
})

$btnWarpGo.Add_Click({
    $p = $txtWarp.Text.Trim() -split '\s+'
    if ($p.Count -lt 3) {
        Show-Msg (T "mbPunto") (T "mbPuntoT") "Warning"
        return
    }
    Set-Content -Path $warpFile -Value ($p[0..2] -join " ") -NoNewline -Encoding ascii
    $out = Invoke-Warp @($p[0], $p[1], $p[2])
    if ($null -ne $out) { Log-Riga ((T "logPunto") -f $out) }
})

# Il mod ha un segnale apposta (bit 0x08): chi lo riceve muore con la stessa
# funzione che il gioco usa per le zone di morte.
$btnKill.Add_Click({
    $risposta = [System.Windows.Forms.MessageBox]::Show(
        (T "mbUccidi"), (T "mbUccidiT"), "YesNo", "Warning")
    if ($risposta -ne "Yes") { return }
    $out = Invoke-Warp @("uccidi", "30")
    if ($null -ne $out) { Log-Riga ((T "logUccidi") -f $out) }
})

# ---------------------------------------------------------------- il gioco dell'host
# Chi ospita gioca su questo PC. Quando chiude Super Mario Galaxy (la X, lo
# stop, o Dolphin intero) la finestra col nome del gioco sparisce: il pannello
# lo vede entro mezzo secondo e lo dice al server, che rimanda tutti al titolo.
Add-Type -TypeDefinition @"
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
public static class FinestreGioco {
    delegate bool EnumProc(IntPtr h, IntPtr l);
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc f, IntPtr l);
    [DllImport("user32.dll")] static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
    public static bool Aperto(int[] pids) {
        var set = new HashSet<uint>();
        foreach (var p in pids) set.Add((uint)p);
        bool trovato = false;
        EnumWindows((h, l) => {
            uint pid;
            GetWindowThreadProcessId(h, out pid);
            if (!set.Contains(pid)) return true;
            var sb = new StringBuilder(512);
            GetWindowText(h, sb, 512);
            var t = sb.ToString();
            if (t.IndexOf("RMGE01", StringComparison.OrdinalIgnoreCase) >= 0 ||
                t.IndexOf("Mario Galaxy", StringComparison.OrdinalIgnoreCase) >= 0) { trovato = true; return false; }
            return true;
        }, IntPtr.Zero);
        return trovato;
    }
}
"@
$script:giocoAperto = $false
function Guarda-GiocoHost {
    $pids = @(Get-Process -Name "Dolphin*" -ErrorAction SilentlyContinue | ForEach-Object { $_.Id })
    $aperto = $false
    if ($pids.Count -gt 0) { try { $aperto = [FinestreGioco]::Aperto([int[]]$pids) } catch { } }
    if ($script:giocoAperto -and -not $aperto -and $script:hostSlot -ge 0) {
        Set-Content -Path $byeFile -Value "1" -NoNewline -Encoding ascii
        Log-Riga (T "logBye")
    }
    $script:giocoAperto = $aperto
}

# ---------------------------------------------------------------- polling
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 500
$timer.Add_Tick({
    $running = Test-Running
    Update-Status

    foreach ($path in @($outLog, $errLog)) {
        if (-not (Test-Path $path)) { continue }
        try {
            $seen = $script:offsets[$path]
            # la lunghezza va chiesta al file aperto: quella della cartella
            # (Get-Item) resta ferma finche' il server tiene il file aperto,
            # e il registro restava vuoto
            $fs = [System.IO.File]::Open($path, 'Open', 'Read', 'ReadWrite')
            $len = $fs.Length
            if ($len -lt $seen) { $seen = 0 }   # il file e' stato ricreato
            if ($len -le $seen) { $fs.Close() }
            else {
                [void]$fs.Seek($seen, 'Begin')
                $buf = New-Object byte[] ($len - $seen)
                [void]$fs.Read($buf, 0, $buf.Length)
                $fs.Close()
                $script:offsets[$path] = $len

                $chunk = [System.Text.Encoding]::UTF8.GetString($buf)
                Append-Log $chunk

                foreach ($line in ($chunk -split "`n")) {
                    if ($line -match 'Connected to ([\d\.]+) on port (\d+) \((\d+)\)') {
                        $script:players[$matches[3]] = $matches[1]
                    }
                }
            }
        } catch { }
    }

    # i giocatori li dice il server (niente fantasmi): solo chi manda pacchetti di gioco
    if ($running -and (Test-Path $playersFile)) {
        try {
            $vivi = @{}
            foreach ($r in [System.IO.File]::ReadAllLines($playersFile)) {
                $pz = $r.Trim().Split(' ')
                if ($pz.Count -eq 2) { $vivi[$pz[0]] = $pz[1] }
            }
            $script:players = $vivi
        } catch { }
    }
    if ($running) { Update-HostSlot; Guarda-GiocoHost } else { $script:giocoAperto = $false }
})

$form.Add_FormClosing({ $timer.Stop(); Stop-TestPlayers; Stop-Server; Stop-Share })

# ---------------------------------------------------------------- schermata d'avvio
# Prima di tutto il resto si vede la copertina con un pulsante solo. Le tre
# immagini le prepara avvio.ps1; se mancano si parte dritti sul pannello.
$schFile = Join-Path $here "schermata.png"
$script:splash = $null

function Carica-Img($percorso) {
    if (-not (Test-Path $percorso)) { return $null }
    try {
        $byte = [System.IO.File]::ReadAllBytes($percorso)
        $ms = New-Object System.IO.MemoryStream (,$byte)
        return [System.Drawing.Image]::FromStream($ms)
    } catch { return $null }
}

$imgSch = Carica-Img $schFile
$imgTasto = Carica-Img (Join-Path $here "tasto.png")
$imgTasto2 = Carica-Img (Join-Path $here "tasto2.png")

if ($null -ne $imgSch -and $null -ne $imgTasto) {
    $splash = New-Object System.Windows.Forms.Panel
    $splash.Dock = "Fill"
    $splash.BackgroundImage = $imgSch
    $splash.BackgroundImageLayout = "None"
    $splash.BackColor = $cBg
    $form.Controls.Add($splash)
    $splash.BringToFront()
    $script:splash = $splash

    $tasto = New-Object System.Windows.Forms.PictureBox
    $tasto.Cursor = "Hand"
    $splash.Controls.Add($tasto)

    # Animazione a 60 fotogrammi al secondo: il pulsante non salta da un disegno
    # all'altro, ci arriva in sei passi da 16 millesimi. Le figure sono pronte
    # prima, tutte della stessa misura e col pulsante centrato: cosi' cambia
    # solo l'immagine e non c'e' sfarfallio.
    $cw = [int]($imgTasto.Width * 1.30)
    $ch = [int]($imgTasto.Height * 2.00)
    $bx = [int]((604 - $cw) / 2)
    $by = [int](770 - $ch / 2)
    $due = $(if ($null -ne $imgTasto2) { $imgTasto2 } else { $imgTasto })

    # Ogni figura si porta dietro il pezzo di copertina che le sta sotto. Senza,
    # il pulsante dovrebbe essere trasparente e Windows ridisegnerebbe anche la
    # copertina a ogni fotogramma: e' li' che si vedeva lo sfarfallio.
    function Fondo-Tasto($cw, $ch) {
        $b = New-Object System.Drawing.Bitmap $cw, $ch
        $g = [System.Drawing.Graphics]::FromImage($b)
        $dst = New-Object System.Drawing.Rectangle 0, 0, $cw, $ch
        $g.DrawImage($imgSch, $dst, $bx, $by, $cw, $ch, "Pixel")
        $g.Dispose()
        return $b
    }

    function Scala-Tasto($img, $sc, $cw, $ch) {
        $b = Fondo-Tasto $cw $ch
        $g = [System.Drawing.Graphics]::FromImage($b)
        $g.InterpolationMode = "HighQualityBicubic"
        $w = [int]($img.Width * $sc); $h = [int]($img.Height * $sc)
        $g.DrawImage($img, [int](($cw - $w) / 2), [int](($ch - $h) / 2), $w, $h)
        $g.Dispose()
        return $b
    }

    $PASSI = 6                      # quanti passi per salire e scendere
    $script:frames = @( (Scala-Tasto $imgTasto 0.94 $cw $ch) )   # 0 = fermo
    for ($i = 1; $i -le $PASSI; $i++) {
        $q = $i / $PASSI
        $sc = 0.94 + 0.06 * (1 - [Math]::Pow(1 - $q, 2))         # rallenta alla fine
        $script:frames += (Scala-Tasto $due $sc $cw $ch)
    }
    $script:frames += (Scala-Tasto $due 0.90 $cw $ch)            # premuto
    $script:fTop = $PASSI
    $script:fGiu = $PASSI + 1

    $tasto.Size = New-Object System.Drawing.Size $cw, $ch
    $tasto.Location = New-Object System.Drawing.Point $bx, $by
    $tasto.Image = $script:frames[0]

    # Lo scoppio di quando si preme, come il logo del titolo: la pillola si
    # schiaccia, rimbalza piu' grande del normale e torna a posto, con un lampo
    # dietro. Diciotto figure a 16 millesimi: circa un terzo di secondo.
    function Lampo($g, $cx, $cy, $rx, $ry, $alpha) {
        if ($alpha -le 0) { return }
        $pth = New-Object System.Drawing.Drawing2D.GraphicsPath
        $pth.AddEllipse(($cx - $rx), ($cy - $ry), (2 * $rx), (2 * $ry))
        $pgb = New-Object System.Drawing.Drawing2D.PathGradientBrush $pth
        $pgb.CenterColor = [System.Drawing.Color]::FromArgb([int]$alpha, 180, 240, 255)
        $pgb.SurroundColors = @([System.Drawing.Color]::FromArgb(0, 120, 200, 255))
        $g.FillPath($pgb, $pth)
        $pgb.Dispose(); $pth.Dispose()
    }

    $script:burst = @()
    $NB = 18
    for ($i = 0; $i -lt $NB; $i++) {
        $t = $i / ($NB - 1)
        if ($t -lt 0.18) {
            $sc = 0.90 + ($t / 0.18) * 0.03                                  # schiacciata
        } else {
            $u = ($t - 0.18) / 0.82
            $sc = 1.0 + 0.15 * [Math]::Sin([Math]::PI * $u) * (1 - $u * 0.45) # rimbalzo
        }
        $bm = Fondo-Tasto $cw $ch
        $gg = [System.Drawing.Graphics]::FromImage($bm)
        $gg.SmoothingMode = "AntiAlias"
        $gg.InterpolationMode = "HighQualityBicubic"
        Lampo $gg ($cw / 2) ($ch / 2) ($imgTasto.Width * 0.58 * (0.85 + 0.35 * $t)) ($imgTasto.Height * 0.62 * (0.85 + 0.35 * $t)) (110 * [Math]::Sin([Math]::PI * $t))
        $w2 = [int]($due.Width * $sc); $h2 = [int]($due.Height * $sc)
        $gg.DrawImage($due, [int](($cw - $w2) / 2), [int](($ch - $h2) / 2), $w2, $h2)
        $gg.Dispose()
        $script:burst += $bm
    }

    $script:fIdx = 0
    $script:fMeta = 0
    $anim = New-Object System.Windows.Forms.Timer
    $anim.Interval = 16             # 60 volte al secondo
    $anim.Add_Tick({
        if ($script:fIdx -eq $script:fMeta) { $anim.Stop(); return }
        if ($script:fIdx -lt $script:fMeta) { $script:fIdx++ } else { $script:fIdx-- }
        $tasto.Image = $script:frames[$script:fIdx]
    })

    # Mentre scorre lo scoppio i due temporizzatori si contenderebbero la figura
    # da mostrare: finche' quello dura, il passaggio del mouse non tocca niente.
    $tasto.Add_MouseEnter({
        if ($null -ne $sco -and $sco.Enabled) { return }
        Suona $script:sndFocus
        $script:fMeta = $script:fTop
        $anim.Start()
    })
    $tasto.Add_MouseLeave({
        if ($null -ne $sco -and $sco.Enabled) { return }
        $script:fMeta = 0
        $anim.Start()
    })
    $tasto.Add_MouseDown({
        if ($null -ne $sco -and $sco.Enabled) { return }
        $anim.Stop()
        $script:fIdx = $script:fGiu      # l'indice segue davvero la figura mostrata
        $tasto.Image = $script:frames[$script:fGiu]
    })
    $tasto.Add_MouseUp({
        if ($null -ne $sco -and $sco.Enabled) { return }
        $script:fIdx = $script:fTop
        $script:fMeta = $script:fTop
        $tasto.Image = $script:frames[$script:fTop]
    })

    $lblSenza = New-Object System.Windows.Forms.Label
    $lblSenza.Location = New-Object System.Drawing.Point 0, 856
    $lblSenza.Size = New-Object System.Drawing.Size 604, 20
    $lblSenza.TextAlign = "MiddleCenter"
    $lblSenza.Font = $fLabel
    $lblSenza.ForeColor = [System.Drawing.Color]::FromArgb(225, 228, 245)
    $lblSenza.BackColor = [System.Drawing.Color]::Transparent
    $lblSenza.Cursor = "Hand"
    $splash.Controls.Add($lblSenza)
    Reg $lblSenza "senzaAvvio" | Out-Null

    # La copertina non sparisce di colpo: resta un attimo sopra al pannello,
    # si allarga e sfuma. Non e' piu' il pannello della schermata: e' una
    # finestrella senza bordi appoggiata sopra, perche' solo una finestra sa
    # essere semitrasparente. Sotto si vede il pannello vero, vivo, non una
    # sua fotografia.
    $script:tra = @()
    $script:tIdx = 0
    $script:ov = $null
    $tratime = New-Object System.Windows.Forms.Timer
    $tratime.Interval = 16
    $tratime.Add_Tick({
        if ($script:tIdx -ge $script:tra.Count) {
            $tratime.Stop()
            if ($null -ne $script:ov) { $script:ov.Close(); $script:ov = $null }
            $form.ActiveControl = $btnToggle
            return
        }
        $script:ov.BackgroundImage = $script:tra[$script:tIdx]
        $script:ov.Opacity = [Math]::Max(0, 1 - ($script:tIdx / ($script:tra.Count - 1)))
        $script:tIdx++
    })

    function Chiudi-Splash {
        # prima la finestra prende la misura del pannello: le figure della
        # dissolvenza devono essere grandi quanto lui, se no restano bordi
        # Niente Refresh: finche' non si torna al giro dei messaggi la finestra
        # non si ridipinge, quindi il pannello non fa capolino prima che la
        # copertina gli si rimetta sopra.
        $script:splash.Visible = $false
        Apply-Dev
        $form.PerformLayout()

        $w = $form.ClientSize.Width
        $h = $form.ClientSize.Height
        # le figure: la copertina che si allarga. Lo sbiadire lo fa la finestra
        # con la sua trasparenza, non il disegno.
        $script:tra = @()
        $N = 14
        for ($i = 0; $i -lt $N; $i++) {
            $t = $i / ($N - 1)
            $sc = 1 + 0.30 * $t
            $bmp = New-Object System.Drawing.Bitmap $w, $h
            $g = [System.Drawing.Graphics]::FromImage($bmp)
            $g.Clear([System.Drawing.Color]::FromArgb(10, 12, 30))
            $g.InterpolationMode = "HighQualityBilinear"
            # la copertina riempie sempre tutto, anche quando cresce
            $riempi = [Math]::Max($w / $imgSch.Width, $h / $imgSch.Height) * $sc
            $sw = [int]($imgSch.Width * $riempi); $sh = [int]($imgSch.Height * $riempi)
            $g.DrawImage($imgSch, [int](($w - $sw) / 2), [int](($h - $sh) / 2), $sw, $sh)
            $g.Dispose()
            $script:tra += $bmp
        }

        $ov = New-Object System.Windows.Forms.Form
        $ov.FormBorderStyle = "None"
        $ov.ShowInTaskbar = $false
        $ov.StartPosition = "Manual"
        $ov.Location = $form.PointToScreen((New-Object System.Drawing.Point 0, 0))
        $ov.Size = New-Object System.Drawing.Size $w, $h
        $ov.BackColor = [System.Drawing.Color]::FromArgb(10, 12, 30)
        $ov.BackgroundImage = $script:tra[0]
        $ov.BackgroundImageLayout = "None"
        $ov.Owner = $form
        $script:ov = $ov
        $ov.Show()
        $script:tIdx = 1
        $tratime.Start()
    }

    # Il clic fa partire lo scoppio; il server si avvia quando l'animazione e'
    # finita, se no la finestra si bloccherebbe a meta' rimbalzo.
    $script:bIdx = 0
    $sco = New-Object System.Windows.Forms.Timer
    $sco.Interval = 16
    $sco.Add_Tick({
        if ($script:bIdx -ge $script:burst.Count) {
            $sco.Stop()
            $tasto.Image = $script:frames[$script:fTop]
            $script:fIdx = $script:fTop
            $script:fMeta = $script:fTop
            $lblSenza.Text = T "avviando"
            $form.Refresh()
            Start-Server
            Update-Status
            $tasto.Enabled = $true
            $lblSenza.Text = T "senzaAvvio"
            if (Test-Running) { Chiudi-Splash }
            return
        }
        $tasto.Image = $script:burst[$script:bIdx]
        $script:bIdx++
    })

    $tasto.Add_Click({
        if (-not $tasto.Enabled) { return }
        Suona $script:sndOk
        $tasto.Enabled = $false
        $anim.Stop()
        $script:bIdx = 0
        $sco.Start()
    })

    $lblSenza.Add_Click({ Chiudi-Splash })
}

Apply-Language
Apply-Dev
Update-Status
if ($null -ne $script:splash) {
    # la finestra prende la misura della copertina finche' la schermata e' li'
    $form.Size = New-Object System.Drawing.Size($W, 945)
} else {
    }
$timer.Start()


# ---------------------------------------------------------------- apertura
# La finestra non compare gia' grande: nasce piccola al centro dello schermo e
# si apre in dodici passi da 16 millesimi, svelta e poi morbida. Mentre cresce
# la copertina si allarga con lei (per quel momento e' "stirata", cosi' segue
# la finestra invece di restare inchiodata in alto a sinistra); il pulsante
# resta nascosto finche' non si e' arrivati a misura, se no si vedrebbe fuori
# posto.
$script:apI = 0
$script:apN = 12
$script:apW = 0
$script:apH = 0
$script:apW0 = 0
$script:apH0 = 0

function Centra($w, $h) {
    $sc = [System.Windows.Forms.Screen]::FromControl($form).WorkingArea
    $form.Location = New-Object System.Drawing.Point ([int]($sc.X + ($sc.Width - $w) / 2)), ([int]($sc.Y + ($sc.Height - $h) / 2))
}

$apri = New-Object System.Windows.Forms.Timer
$apri.Interval = 16
$apri.Add_Tick({
    $script:apI++
    $q = $script:apI / $script:apN
    if ($q -ge 1) {
        $apri.Stop()
        $form.Size = New-Object System.Drawing.Size $script:apW, $script:apH
        Centra $script:apW $script:apH
        if ($null -ne $script:splash) {
            $script:splash.BackgroundImageLayout = "None"
            if ($null -ne $tasto) { $tasto.Visible = $true }
            if ($null -ne $lblSenza) { $lblSenza.Visible = $true }
        }
        $form.ActiveControl = $btnToggle
        return
    }
    $e = 1 - [Math]::Pow(1 - $q, 3)
    $w = [int]($script:apW0 + ($script:apW - $script:apW0) * $e)
    $h = [int]($script:apH0 + ($script:apH - $script:apH0) * $e)
    $form.Size = New-Object System.Drawing.Size $w, $h
    Centra $w $h
})

# La misura piccola si da' PRIMA di mostrarla: se la si rimpicciolisse dentro
# Add_Shown, per un istante la finestra si vedrebbe gia' grande e sarebbe un
# lampo brutto.
$script:apW = $form.Width
$script:apH = $form.Height
$script:apW0 = [int]($script:apW * 0.30)      # parte da poco meno di un terzo
$script:apH0 = [int]($script:apH * 0.30)
if ($null -ne $script:splash) {
    $script:splash.BackgroundImageLayout = "Stretch"   # la copertina segue la finestra
    if ($null -ne $tasto) { $tasto.Visible = $false }
    if ($null -ne $lblSenza) { $lblSenza.Visible = $false }
}
$form.Size = New-Object System.Drawing.Size $script:apW0, $script:apH0

$form.Add_Shown({
    Centra $script:apW0 $script:apH0
    $script:apI = 0
    $apri.Start()
})

# La condivisione del salvataggio parte da sola: chi ospita di solito la vuole,
# e chi si collega la trova pronta. Solo se l'hai spenta a mano resta spenta.
$script:avvioShare = $true
$vuoi = $true
if (Test-Path $shareFile) { $vuoi = ((Get-Content $shareFile -Raw).Trim() -ne "0") }
if ($vuoi) { $chkShare.Checked = $true }
$script:avvioShare = $false

[void]$form.ShowDialog()
