#
# Pannello di controllo per SMGServer.
#
# Avvialo con "Avvia server.bat" (imposta la policy di esecuzione al volo,
# senza modificare niente a livello di sistema).
#

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$here    = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
$exePath = Join-Path $here "SMGServer.exe"
$outLog  = Join-Path $here "server.log"
$errLog  = Join-Path $here "server.err"

$testExe = Join-Path $here "TestPlayers.exe"
$starExe = Join-Path $here "StarSpawn.exe"
$testLog = Join-Path $here "testplayers.log"
$testCtl = Join-Path $here "testplayers.count"

$script:proc      = $null
$script:offsets   = @{ $outLog = 0; $errLog = 0 }
$script:players   = @{}
$script:testProc  = $null
$script:testCount = 0

$MAX_TEST = 7       # 8 slot sul server, uno e' del giocatore vero
$TEST_SPACING = 250 # distanza fra una copia e l'altra, misurata sul percorso

# ---------------------------------------------------------------- palette
$cBg      = [System.Drawing.Color]::FromArgb(28, 28, 40)
$cPanel   = [System.Drawing.Color]::FromArgb(38, 38, 54)
$cText    = [System.Drawing.Color]::FromArgb(232, 232, 244)
$cMuted   = [System.Drawing.Color]::FromArgb(138, 138, 164)
$cOn      = [System.Drawing.Color]::FromArgb(94, 200, 140)
$cOff     = [System.Drawing.Color]::FromArgb(190, 90, 90)
$cAccent  = [System.Drawing.Color]::FromArgb(228, 168, 72)

$fTitle   = New-Object System.Drawing.Font("Segoe UI Semibold", 15)
$fLabel   = New-Object System.Drawing.Font("Segoe UI", 8.5)
$fBody    = New-Object System.Drawing.Font("Segoe UI", 9.5)
$fStatus  = New-Object System.Drawing.Font("Segoe UI Semibold", 11)
$fMono    = New-Object System.Drawing.Font("Consolas", 9)
$fAddr    = New-Object System.Drawing.Font("Consolas", 11, [System.Drawing.FontStyle]::Bold)

# ---------------------------------------------------------------- finestra
$form = New-Object System.Windows.Forms.Form
$form.Text = "Super Mario Galaxy - Server"
$form.Size = New-Object System.Drawing.Size(600, 740)
$form.StartPosition = "CenterScreen"
$form.BackColor = $cBg
$form.ForeColor = $cText
$form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox = $false

function New-Label($text, $x, $y, $w, $h, $font, $color) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $text; $l.Location = New-Object System.Drawing.Point($x, $y)
    $l.Size = New-Object System.Drawing.Size($w, $h)
    $l.Font = $font; $l.ForeColor = $color; $l.BackColor = [System.Drawing.Color]::Transparent
    $form.Controls.Add($l); return $l
}

New-Label "Super Mario Galaxy" 22 16 400 26 $fTitle $cText | Out-Null
New-Label "server multiplayer" 24 42 400 18 $fLabel $cMuted | Out-Null

# ---------------------------------------------------------------- stato
$statusPanel = New-Object System.Windows.Forms.Panel
$statusPanel.Location = New-Object System.Drawing.Point(22, 76)
$statusPanel.Size = New-Object System.Drawing.Size(546, 76)
$statusPanel.BackColor = $cPanel
$form.Controls.Add($statusPanel)

$dot = New-Object System.Windows.Forms.Label
$dot.Text = [char]0x25CF
$dot.Font = New-Object System.Drawing.Font("Segoe UI", 20)
$dot.ForeColor = $cOff
$dot.Location = New-Object System.Drawing.Point(16, 18)
$dot.Size = New-Object System.Drawing.Size(32, 38)
$dot.BackColor = [System.Drawing.Color]::Transparent
$statusPanel.Controls.Add($dot)

$lblStatus = New-Object System.Windows.Forms.Label
$lblStatus.Text = "Fermo"
$lblStatus.Font = $fStatus; $lblStatus.ForeColor = $cText
$lblStatus.Location = New-Object System.Drawing.Point(50, 16)
$lblStatus.Size = New-Object System.Drawing.Size(280, 24)
$lblStatus.BackColor = [System.Drawing.Color]::Transparent
$statusPanel.Controls.Add($lblStatus)

$lblDetail = New-Object System.Windows.Forms.Label
$lblDetail.Text = "premi Avvia per accendere il server"
$lblDetail.Font = $fLabel; $lblDetail.ForeColor = $cMuted
$lblDetail.Location = New-Object System.Drawing.Point(52, 42)
$lblDetail.Size = New-Object System.Drawing.Size(320, 20)
$lblDetail.BackColor = [System.Drawing.Color]::Transparent
$statusPanel.Controls.Add($lblDetail)

$btnToggle = New-Object System.Windows.Forms.Button
$btnToggle.Text = "Avvia"
$btnToggle.Location = New-Object System.Drawing.Point(408, 20)
$btnToggle.Size = New-Object System.Drawing.Size(120, 36)
$btnToggle.FlatStyle = "Flat"
$btnToggle.FlatAppearance.BorderSize = 0
$btnToggle.BackColor = $cOn
$btnToggle.ForeColor = [System.Drawing.Color]::FromArgb(20, 32, 24)
$btnToggle.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 10)
$statusPanel.Controls.Add($btnToggle)

# ---------------------------------------------------------------- porta
New-Label "Porta UDP" 22 168 100 18 $fLabel $cMuted | Out-Null
$txtPort = New-Object System.Windows.Forms.TextBox
$txtPort.Text = "5029"
$txtPort.Location = New-Object System.Drawing.Point(22, 188)
$txtPort.Size = New-Object System.Drawing.Size(90, 26)
$txtPort.Font = $fMono
$txtPort.BackColor = $cPanel; $txtPort.ForeColor = $cText
$txtPort.BorderStyle = "FixedSingle"
$form.Controls.Add($txtPort)

$lblPlayers = New-Label "Giocatori collegati: 0" 140 190 250 20 $fBody $cText

# ---------------------------------------------------------------- friendly fire
# Acceso: lo schianto a terra addosso a un altro giocatore gli toglie 1 di
# vita, la piroetta lo fa cadere senza danno. Spento: il server cancella i
# flag d'attacco e nessuno puo' fare male agli altri. Il server rilegge il
# file di controllo ogni secondo, quindi vale subito, senza riavviare.
$ffFile = Join-Path $here "friendlyfire.txt"

$chkFF = New-Object System.Windows.Forms.CheckBox
$chkFF.Text = "Friendly fire"
$chkFF.Location = New-Object System.Drawing.Point(420, 188)
$chkFF.Size = New-Object System.Drawing.Size(150, 24)
$chkFF.Font = $fBody
$chkFF.ForeColor = $cText
$chkFF.Checked = ((Test-Path $ffFile) -and ((Get-Content $ffFile -Raw -ErrorAction SilentlyContinue) -match '^1'))
$form.Controls.Add($chkFF)

function Write-FriendlyFire {
    $v = "0"
    if ($chkFF.Checked) { $v = "1" }
    Set-Content -Path $ffFile -Value $v -NoNewline -Encoding ascii
}

$chkFF.Add_CheckedChanged({
    Write-FriendlyFire
    if ($chkFF.Checked) {
        Append-Log "Friendly fire ACCESO: schianto = 1 di danno, piroetta = caduta`r`n"
    } else {
        Append-Log "Friendly fire SPENTO: nessuno puo' fare male agli altri`r`n"
    }
})

# ---------------------------------------------------------------- indirizzo
New-Label "Indirizzo da dare agli amici" 22 232 300 18 $fLabel $cMuted | Out-Null

$addrPanel = New-Object System.Windows.Forms.Panel
$addrPanel.Location = New-Object System.Drawing.Point(22, 252)
$addrPanel.Size = New-Object System.Drawing.Size(546, 54)
$addrPanel.BackColor = $cPanel
$form.Controls.Add($addrPanel)

$cmbAddr = New-Object System.Windows.Forms.ComboBox
$cmbAddr.Location = New-Object System.Drawing.Point(14, 14)
$cmbAddr.Size = New-Object System.Drawing.Size(390, 28)
$cmbAddr.DropDownStyle = "DropDownList"
$cmbAddr.Font = $fAddr
$cmbAddr.BackColor = $cPanel; $cmbAddr.ForeColor = $cAccent
$cmbAddr.FlatStyle = "Flat"
$addrPanel.Controls.Add($cmbAddr)

$btnCopy = New-Object System.Windows.Forms.Button
$btnCopy.Text = "Copia"
$btnCopy.Location = New-Object System.Drawing.Point(416, 13)
$btnCopy.Size = New-Object System.Drawing.Size(112, 30)
$btnCopy.FlatStyle = "Flat"
$btnCopy.FlatAppearance.BorderSize = 1
$btnCopy.FlatAppearance.BorderColor = $cMuted
$btnCopy.BackColor = $cPanel; $btnCopy.ForeColor = $cText
$btnCopy.Font = $fBody
$addrPanel.Controls.Add($btnCopy)

# ---------------------------------------------------------------- log
New-Label "Registro" 22 326 200 18 $fLabel $cMuted | Out-Null

$txtLog = New-Object System.Windows.Forms.TextBox
$txtLog.Location = New-Object System.Drawing.Point(22, 346)
$txtLog.Size = New-Object System.Drawing.Size(546, 216)
$txtLog.Multiline = $true
$txtLog.ScrollBars = "Vertical"
$txtLog.ReadOnly = $true
$txtLog.Font = $fMono
$txtLog.BackColor = [System.Drawing.Color]::FromArgb(20, 20, 30)
$txtLog.ForeColor = [System.Drawing.Color]::FromArgb(150, 210, 180)
$txtLog.BorderStyle = "FixedSingle"
$form.Controls.Add($txtLog)

$btnClear = New-Object System.Windows.Forms.Button
$btnClear.Text = "Pulisci registro"
$btnClear.Location = New-Object System.Drawing.Point(22, 574)
$btnClear.Size = New-Object System.Drawing.Size(130, 30)
$btnClear.FlatStyle = "Flat"
$btnClear.FlatAppearance.BorderSize = 1
$btnClear.FlatAppearance.BorderColor = $cMuted
$btnClear.BackColor = $cBg; $btnClear.ForeColor = $cMuted
$btnClear.Font = $fLabel
$form.Controls.Add($btnClear)

$btnTest = New-Object System.Windows.Forms.Button
$btnTest.Text = "Test player"
$btnTest.Location = New-Object System.Drawing.Point(162, 574)
$btnTest.Size = New-Object System.Drawing.Size(150, 30)
$btnTest.FlatStyle = "Flat"
$btnTest.FlatAppearance.BorderSize = 1
$btnTest.FlatAppearance.BorderColor = $cAccent
$btnTest.BackColor = $cBg; $btnTest.ForeColor = $cAccent
$btnTest.Font = $fLabel
$form.Controls.Add($btnTest)

New-Label "distanza" 322 560 70 16 $fLabel $cMuted | Out-Null

$txtSpacing = New-Object System.Windows.Forms.TextBox
$txtSpacing.Text = "$TEST_SPACING"
$txtSpacing.Location = New-Object System.Drawing.Point(322, 576)
$txtSpacing.Size = New-Object System.Drawing.Size(58, 26)
$txtSpacing.Font = $fMono
$txtSpacing.BackColor = $cPanel; $txtSpacing.ForeColor = $cAccent
$txtSpacing.BorderStyle = "FixedSingle"
$form.Controls.Add($txtSpacing)

$lblHint = New-Label "unita' fra un Mario e l'altro, regolabile mentre gira" 390 580 190 32 $fLabel $cMuted

# ---------------------------------------------------------------- stella per tutti
$btnStar = New-Object System.Windows.Forms.Button
$btnStar.Text = "Stella per tutti"
$btnStar.Location = New-Object System.Drawing.Point(22, 616)
$btnStar.Size = New-Object System.Drawing.Size(150, 30)
$btnStar.FlatStyle = "Flat"
$btnStar.FlatAppearance.BorderSize = 1
$btnStar.FlatAppearance.BorderColor = $cAccent
$btnStar.BackColor = $cBg; $btnStar.ForeColor = $cAccent
$btnStar.Font = $fLabel
$form.Controls.Add($btnStar)

New-Label "numero" 182 622 50 16 $fLabel $cMuted | Out-Null

$txtStar = New-Object System.Windows.Forms.TextBox
$txtStar.Text = "1"
$txtStar.Location = New-Object System.Drawing.Point(232, 618)
$txtStar.Size = New-Object System.Drawing.Size(46, 26)
$txtStar.Font = $fMono
$txtStar.BackColor = $cPanel; $txtStar.ForeColor = $cAccent
$txtStar.BorderStyle = "FixedSingle"
$form.Controls.Add($txtStar)

New-Label "stella della vostra missione; 0 = prova dalla 1 alla 7" 290 616 290 32 $fLabel $cMuted | Out-Null

# ---------------------------------------------------------------- teletrasporto
# Come /tp in Minecraft: tutti i Mario vengono portati dal tuo. Il pannello
# scrive il tuo slot in tp.txt; il server lo legge e per un secondo accende un
# bit nei tuoi pacchetti; il gioco degli altri, se sono nella tua stessa
# galassia, li porta dove sei tu.
$tpFile = Join-Path $here "tp.txt"

$btnTp = New-Object System.Windows.Forms.Button
$btnTp.Text = "Teletrasporta tutti da me"
$btnTp.Location = New-Object System.Drawing.Point(22, 658)
$btnTp.Size = New-Object System.Drawing.Size(190, 30)
$btnTp.FlatStyle = "Flat"
$btnTp.FlatAppearance.BorderSize = 1
$btnTp.FlatAppearance.BorderColor = $cOn
$btnTp.BackColor = $cBg; $btnTp.ForeColor = $cOn
$btnTp.Font = $fLabel
$form.Controls.Add($btnTp)

New-Label "slot" 222 664 30 16 $fLabel $cMuted | Out-Null

$txtTp = New-Object System.Windows.Forms.TextBox
$txtTp.Text = ""
$txtTp.Location = New-Object System.Drawing.Point(254, 660)
$txtTp.Size = New-Object System.Drawing.Size(40, 26)
$txtTp.Font = $fMono
$txtTp.BackColor = $cPanel; $txtTp.ForeColor = $cOn
$txtTp.BorderStyle = "FixedSingle"
$form.Controls.Add($txtTp)

New-Label "vuoto = il gioco su questo PC; solo chi e' nella tua galassia" 302 658 280 32 $fLabel $cMuted | Out-Null

# ---------------------------------------------------------------- indirizzi
function Get-Addresses {
    $list = @()
    try {
        $ips = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
               Where-Object { $_.IPAddress -notlike "127.*" -and $_.IPAddress -notlike "169.254.*" }
        foreach ($ip in $ips) {
            $tag = $ip.InterfaceAlias
            if ($tag -like "*Radmin*")   { $list += [pscustomobject]@{ Sort = 0; Text = "$($ip.IPAddress)   (Radmin VPN - consigliato)"; Ip = $ip.IPAddress } }
            elseif ($tag -like "*Wi-Fi*" -or $tag -like "*Ethernet*") {
                if ($ip.IPAddress -notlike "192.168.56.*" -and $ip.IPAddress -notlike "192.168.244.*" -and
                    $ip.IPAddress -notlike "192.168.31.*"  -and $ip.IPAddress -notlike "192.168.137.*" -and
                    $ip.IPAddress -notlike "172.2*") {
                    $list += [pscustomobject]@{ Sort = 1; Text = "$($ip.IPAddress)   (rete locale)"; Ip = $ip.IPAddress }
                }
            }
        }
    } catch { }
    $list += [pscustomobject]@{ Sort = 2; Text = "127.0.0.1   (questo stesso PC)"; Ip = "127.0.0.1" }
    return $list | Sort-Object Sort
}

$script:addrList = Get-Addresses
foreach ($a in $script:addrList) { [void]$cmbAddr.Items.Add($a.Text) }
if ($cmbAddr.Items.Count -gt 0) { $cmbAddr.SelectedIndex = 0 }

# ---------------------------------------------------------------- azioni
function Test-Running {
    return ($null -ne $script:proc -and -not $script:proc.HasExited)
}

function Append-Log($text) {
    if ([string]::IsNullOrWhiteSpace($text)) { return }
    $txtLog.AppendText($text)
    $txtLog.SelectionStart = $txtLog.TextLength
    $txtLog.ScrollToCaret()
}

function Start-Server {
    if (-not (Test-Path $exePath)) {
        [System.Windows.Forms.MessageBox]::Show(
            "Non trovo SMGServer.exe in:`n$here", "File mancante",
            "OK", "Error") | Out-Null
        return
    }
    $port = 5029
    if (-not [int]::TryParse($txtPort.Text, [ref]$port) -or $port -lt 1 -or $port -gt 65535) {
        [System.Windows.Forms.MessageBox]::Show(
            "Porta non valida. Usa un numero fra 1 e 65535.", "Porta",
            "OK", "Warning") | Out-Null
        return
    }
    # Un'altra istanza terrebbe occupata la porta e il nuovo processo
    # morirebbe subito con l'errore 10048.
    $orphans = @(Get-Process -Name SMGServer -ErrorAction SilentlyContinue)
    if ($orphans.Count -gt 0) {
        $ids = ($orphans | ForEach-Object { $_.Id }) -join ", "
        $answer = [System.Windows.Forms.MessageBox]::Show(
            "C'e' gia' un server in esecuzione (PID $ids).`n`n" +
            "Lo fermo e ne avvio uno nuovo?",
            "Server gia' attivo", "YesNo", "Question")
        if ($answer -ne "Yes") { return }
        $orphans | Stop-Process -Force -ErrorAction SilentlyContinue
        Start-Sleep -Milliseconds 800
    }

    Remove-Item $outLog, $errLog -ErrorAction SilentlyContinue
    $script:offsets[$outLog] = 0
    $script:offsets[$errLog] = 0
    $script:players = @{}
    $txtLog.Clear()
    try {
        # il file di controllo va scritto prima: il server lo legge subito
        Write-FriendlyFire
        $ffArg = "--friendly-fire=off"
        if ($chkFF.Checked) { $ffArg = "--friendly-fire=on" }
        $script:proc = Start-Process -FilePath $exePath `
            -ArgumentList "$port", "0.0.0.0", $ffArg, "--controllo", "`"$ffFile`"", "--tp", "`"$tpFile`"" `
            -PassThru -WindowStyle Hidden `
            -RedirectStandardOutput $outLog -RedirectStandardError $errLog
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Avvio fallito:`n$_", "Errore", "OK", "Error") | Out-Null
        $script:proc = $null
        return
    }

    # Se il bind fallisce il processo muore subito: meglio dirlo chiaramente
    # invece di lasciare la finestra su "Fermo" senza spiegazioni.
    Start-Sleep -Milliseconds 1200
    if ($script:proc.HasExited) {
        $why = ""
        foreach ($f in @($errLog, $outLog)) {
            if (Test-Path $f) { $why += (Get-Content $f -Raw) }
        }
        $msg = "Il server si e' chiuso subito dopo l'avvio."
        if ($why -match '10048') {
            $msg = "La porta $port e' gia' occupata da un altro programma.`n`n" +
                   "Prova con un'altra porta, oppure chiudi cio' che la usa."
        } elseif ($why.Trim()) {
            $msg += "`n`n" + $why.Trim()
        }
        [System.Windows.Forms.MessageBox]::Show($msg, "Avvio non riuscito", "OK", "Warning") | Out-Null
        $script:proc = $null
    }
}

function Stop-Server {
    # senza server le copie di test non hanno piu' niente a cui collegarsi
    Stop-TestPlayers
    $script:testCount = 0
    $btnTest.Text = "Test player"
    if (Test-Running) { try { $script:proc.Kill() } catch { } }
    $script:proc = $null
}

$btnToggle.Add_Click({
    if (Test-Running) { Stop-Server } else { Start-Server }
})

$btnCopy.Add_Click({
    if ($cmbAddr.SelectedIndex -lt 0) { return }
    $ip = $script:addrList[$cmbAddr.SelectedIndex].Ip
    $port = $txtPort.Text.Trim()
    Set-Clipboard -Value "${ip}:${port}"
    $btnCopy.Text = "Copiato!"
    $script:copyTimer = New-Object System.Windows.Forms.Timer
    $script:copyTimer.Interval = 1200
    $script:copyTimer.Add_Tick({
        $btnCopy.Text = "Copia"
        $script:copyTimer.Stop()
    })
    $script:copyTimer.Start()
})

$btnClear.Add_Click({ $txtLog.Clear() })

function Stop-TestPlayers {
    if ($script:testProc -and -not $script:testProc.HasExited) {
        try { $script:testProc.Kill() } catch { }
    }
    Get-Process -Name TestPlayers -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    $script:testProc = $null
}

$btnTest.Add_Click({
    if (-not (Test-Running)) {
        [System.Windows.Forms.MessageBox]::Show(
            "Accendi prima il server.", "Server fermo", "OK", "Information") | Out-Null
        return
    }
    if (-not (Test-Path $testExe)) {
        [System.Windows.Forms.MessageBox]::Show(
            "Non trovo TestPlayers.exe in:`n$here", "File mancante", "OK", "Error") | Out-Null
        return
    }

    $script:testCount++
    if ($script:testCount -gt $MAX_TEST) { $script:testCount = 0 }

    # Il numero passa da un file: il processo apre le connessioni una volta
    # sola e cambia solo quante ne anima. Riavviarlo a ogni pressione
    # bruciava gli slot del server.
    $sp = $TEST_SPACING
    [void][int]::TryParse($txtSpacing.Text.Trim(), [ref]$sp)
    if ($sp -lt 20) { $sp = 20 }
    if ($sp -gt 2000) { $sp = 2000 }
    $txtSpacing.Text = "$sp"

    Set-Content -Path $testCtl -Value "$($script:testCount) $sp" -NoNewline -Encoding ascii

    if ($script:testCount -eq 0) {
        Stop-TestPlayers
        $btnTest.Text = "Test player"
        Append-Log "`r`n--- test fermato ---`r`n"
        Append-Log "I Mario gia' comparsi restano fermi a schermo: il mod non`r`n"
        Append-Log "rimuove mai un giocatore. Per farli sparire riavvia il gioco.`r`n"
        return
    }

    $alive = $script:testProc -and -not $script:testProc.HasExited
    if (-not $alive) {
        Remove-Item $testLog, "$testLog.err" -ErrorAction SilentlyContinue
        try {
            $script:testProc = Start-Process -FilePath $testExe `
                -ArgumentList "$($txtPort.Text)", "$sp", "`"$testCtl`"" `
                -PassThru -WindowStyle Hidden `
                -RedirectStandardOutput $testLog -RedirectStandardError "$testLog.err"
        } catch {
            Append-Log "`r`n--- avvio fallito: $_ ---`r`n"
            $script:testCount = 0
            $btnTest.Text = "Test player"
            return
        }
        Start-Sleep -Milliseconds 900
        if ($script:testProc.HasExited) {
            $why = ""
            if (Test-Path $testLog) { $why = (Get-Content $testLog -Raw) }
            Append-Log "`r`n--- le copie non si sono collegate ---`r`n$why`r`n"
            $script:testCount = 0
            $btnTest.Text = "Test player"
            return
        }
    }

    $btnTest.Text = "Test player ($($script:testCount)/$MAX_TEST)"
    Append-Log ("`r`n--- {0} in fila a {1} unita' l'uno, l'ultimo a {2} dietro di te ---`r`n" -f `
        $script:testCount, $sp, ($script:testCount * $sp))
    if ($script:testCount -eq $MAX_TEST) {
        Append-Log "--- alla prossima pressione il test si ferma ---`r`n"
    }
})

# ---------------------------------------------------------------- polling
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 500
$timer.Add_Tick({
    $running = Test-Running

    if ($running) {
        $dot.ForeColor = $cOn
        $lblStatus.Text = "In esecuzione"
        $lblDetail.Text = "in ascolto su UDP $($txtPort.Text) - PID $($script:proc.Id)"
        $btnToggle.Text = "Ferma"
        $btnToggle.BackColor = $cOff
        $btnToggle.ForeColor = [System.Drawing.Color]::White
        $txtPort.Enabled = $false
    } else {
        $dot.ForeColor = $cOff
        $lblStatus.Text = "Fermo"
        $lblDetail.Text = "premi Avvia per accendere il server"
        $btnToggle.Text = "Avvia"
        $btnToggle.BackColor = $cOn
        $btnToggle.ForeColor = [System.Drawing.Color]::FromArgb(20, 32, 24)
        $txtPort.Enabled = $true
    }

    foreach ($path in @($outLog, $errLog)) {
        if (-not (Test-Path $path)) { continue }
        try {
            $seen = $script:offsets[$path]
            $len  = (Get-Item $path).Length
            if ($len -lt $seen) { $seen = 0 }   # il file e' stato ricreato
            if ($len -gt $seen) {
                $fs = [System.IO.File]::Open($path, 'Open', 'Read', 'ReadWrite')
                [void]$fs.Seek($seen, 'Begin')
                $buf = New-Object byte[] ($len - $seen)
                [void]$fs.Read($buf, 0, $buf.Length)
                $fs.Close()
                $script:offsets[$path] = $len

                $chunk = [System.Text.Encoding]::UTF8.GetString($buf)
                Append-Log $chunk

                foreach ($line in ($chunk -split "`n")) {
                    if ($line -match 'Connected to ([\d\.]+) on port (\d+) \((\d+)\)') {
                        $script:players[$matches[3]] = $matches[1]
                    }
                }
            }
        } catch { }
    }

    if (-not $running) { $lblPlayers.Text = "Giocatori collegati: 0" }
    else { $lblPlayers.Text = "Giocatori collegati: $($script:players.Count)" }
})
$timer.Start()

$btnStar.Add_Click({
    if (-not (Test-Running)) {
        [System.Windows.Forms.MessageBox]::Show(
            "Accendi prima il server.", "Server fermo", "OK", "Information") | Out-Null
        return
    }
    if (-not (Test-Path $starExe) -and -not ($script:testProc -and -not $script:testProc.HasExited)) {
        [System.Windows.Forms.MessageBox]::Show(
            "Non trovo StarSpawn.exe in:`n$here", "File mancante", "OK", "Error") | Out-Null
        return
    }
    $id = 0
    if (-not [int]::TryParse($txtStar.Text.Trim(), [ref]$id) -or $id -lt 0 -or $id -gt 255) {
        [System.Windows.Forms.MessageBox]::Show(
            "Il numero della stella va da 1 a 255 (0 = prova dalla 1 alla 7).", "Numero", "OK", "Warning") | Out-Null
        return
    }
    $label = "$id"
    if ($id -eq 0) { $label = "da 1 a 7" }

    # Coi Test player accesi tutti gli slot del server possono essere occupati:
    # l'annuncio allora lo fa il primo Mario finto, che e' gia' collegato.
    if ($script:testProc -and -not $script:testProc.HasExited) {
        if ($null -eq $script:starSeq) { $script:starSeq = 0 }
        $script:starSeq++
        $sp = $TEST_SPACING
        [void][int]::TryParse($txtSpacing.Text.Trim(), [ref]$sp)
        Set-Content -Path $testCtl -Value "$($script:testCount) $sp $id $($script:starSeq)" -NoNewline -Encoding ascii
        Append-Log "`r`n--- stella ${label}: la annuncia il primo Test player ---`r`n"
        return
    }
    # A chi ha quella stella nella propria scena compare addosso e la prende:
    # finisce il livello, come una stella vera.
    $out = Join-Path $env:TEMP "starspawn.out"
    Remove-Item $out -ErrorAction SilentlyContinue
    try {
        Start-Process -FilePath $starExe -ArgumentList "$($txtPort.Text)", "$id" `
            -WindowStyle Hidden -Wait -RedirectStandardOutput $out | Out-Null
    } catch {
        Append-Log "`r`n--- StarSpawn non partito: $_ ---`r`n"
        return
    }
    $msg = ""
    if (Test-Path $out) { $msg = (Get-Content $out -Raw) }
    Append-Log "`r`n--- stella $label ---`r`n$msg`r`n"
    if ($msg -match 'pieno') {
        Append-Log "Il server non ha slot liberi. Se un gioco e' stato chiuso da poco,`r`n"
        Append-Log "il suo posto si libera dopo un minuto di silenzio.`r`n"
    }
})

$btnTp.Add_Click({
    if (-not (Test-Running)) {
        [System.Windows.Forms.MessageBox]::Show(
            "Accendi prima il server.", "Server fermo", "OK", "Information") | Out-Null
        return
    }
    $slot = -1
    $t = $txtTp.Text.Trim()
    if ($t -ne "") {
        if (-not [int]::TryParse($t, [ref]$slot) -or $slot -lt 0 -or $slot -gt 7) {
            [System.Windows.Forms.MessageBox]::Show(
                "Lo slot va da 0 a 7 (vuoto = il gioco su questo PC).", "Slot", "OK", "Warning") | Out-Null
            return
        }
    } else {
        # il gioco su questo PC e' quello collegato da un indirizzo di questo PC
        $mine = @($script:addrList | ForEach-Object { $_.Ip })
        $found = @($script:players.Keys | Where-Object { $mine -contains $script:players[$_] } |
                   ForEach-Object { [int]$_ } | Sort-Object)
        if ($found.Count -eq 0) {
            [System.Windows.Forms.MessageBox]::Show(
                "Non trovo il tuo gioco fra i collegati.`n`nScrivi il tuo slot nella casella (il numero fra parentesi in 'Connected to ... (N)').",
                "Teletrasporto", "OK", "Information") | Out-Null
            return
        }
        $slot = $found[0]
        if ($found.Count -gt 1) {
            Append-Log "`r`n(da questo PC ci sono piu' giochi: uso lo slot $slot; se non sei tu scrivilo nella casella)`r`n"
        }
    }
    Set-Content -Path $tpFile -Value "$slot" -NoNewline -Encoding ascii
    Append-Log "`r`n--- teletrasporto: tutti dallo slot $slot ---`r`n"
})

$form.Add_FormClosing({ $timer.Stop(); Stop-TestPlayers; Stop-Server })

[void]$form.ShowDialog()
