# Sorgenti e patch

Due patch, entrambi verificati: applicati a una copia intatta scaricata da
GitHub non danno conflitti, e per il server il risultato è stato ricompilato
e ripassato attraverso la prova automatica del rilancio.

```bash
patch -p1 < smgserver-fixes.patch      # dentro SMGMultiplayerServer-master/
patch -p1 < mod-petari-master.patch    # dentro SMGNetworkMultiplayer-master/
```

Vanno bene anche con `git apply`.

---

## `smgserver-fixes.patch` — 19 file

### Correzioni

| Gravità | Difetto |
|---|---|
| Critico | `playerId` preso dal pacchetto e usato come indice senza controllo: un solo UDP da 60 byte con `playerId = 200` scriveva fuori dall'array e uccideva il server |
| Critico | Il controllo anti-impersonificazione registrava l'anomalia ma non fermava la scrittura: mancava il `break` |
| Alto | `memset` con l'indirizzo di un membro e la dimensione dell'intera struttura: corruzione della heap a ogni avvio, senza bisogno di traffico |
| Medio | `errno` (positivo) confrontato con `-EAGAIN`: il ritentativo non scattava mai e gli errori del socket passavano per dati validi |
| Minore | `isCandidateMode` non inizializzato: il primo pacchetto veniva interpretato leggendo memoria casuale |

I due critici sono stati verificati con AddressSanitizer confrontando
binario originale e corretto sullo stesso identico pacchetto: l'originale
muore con `SEGV` in scrittura dentro `Player::updateInfo`, il corretto
registra `Rejected packet: player id 200 is out of range (max 7)` e prosegue.
La sonda è `source/tests/oobProbe.cpp`.

### Aggiunte

- **Windows**: `include/platform_net.hpp` astrae socket, terminale e logging
  fra POSIX e Winsock. Il binario risultante è nativo e statico.
- **`SIO_UDP_CONNRESET` disattivato.** Su Windows, se un `sendto` provoca un
  ICMP «port unreachable» (cioè ogni volta che un client sparisce), la
  `recvfrom` successiva fallisce con `WSAECONNRESET`. Su un server UDP che
  parla con molti client è un comportamento inutile che fa fallire letture
  valide. Su POSIX non succede.
- **Porta e indirizzo da riga di comando**: `SMGServer [porta] [indirizzo]`.
  Prima erano fissati a tempo di compilazione.
- **Niente uscita immediata senza terminale.** L'originale usa `poll()` sullo
  stdin per il «premi Invio per chiudere»; senza un tty lo stdin è subito a
  EOF, che `poll()` riporta come leggibile, quindi il server usciva dopo un
  solo pacchetto. Serve che *entrambi* stdin e stdout siano un terminale:
  con la finestra nascosta e lo stdout su file, `_isatty(stdin)` può
  rispondere di sì pur non essendoci nessuna console.
- **Riciclo degli slot.** Uno slot silenzioso da oltre 60 secondi può essere
  riusato, ma solo quando non c'è più posto: chi ha Dolphin in pausa non
  perde la sedia, perché il mod non rifà mai l'handshake.
- **Mondo condiviso**: i tag `COIN_COLLECTED` e `ACTOR_KILLED` con i loro
  pacchetti. Il server non li interpreta, li rilancia — ma deve saperli
  leggere, se no il filtro sui tag li scarterebbe come invalidi.

### Prove

`source/tests/` contiene, oltre a quelle dell'autore:

| File | Cosa fa |
|---|---|
| `relaytest.cpp` | due client, uno annuncia moneta e nemico, l'altro deve riceverli con i campi intatti e chi manda non deve ricevere il proprio eco |
| `oobProbe.cpp` | manda un `playerId` fuori range e controlla che il server sopravviva |
| `conntest.cpp` | handshake e latenza, una riga sola leggibile da uno script |
| `follow.cpp` | un giocatore finto che ripete i tuoi movimenti con un ritardo |
| `observer.cpp` | si collega e stampa il traffico |
| `testplayers.cpp` | fino a 8 giocatori finti che ti seguono a distanza regolabile |

```bash
g++ -I include -std=c++20 -O2 -Wall \
    source/packets.cpp source/packetFactory.cpp source/transmission.cpp \
    source/protocol.cpp source/main.cpp -o SMGServer
```

Serve **g++ 12 o superiore**: il codice usa `std::is_layout_compatible` e
`std::bit_cast`.

---

## `mod-petari-master.patch` — 14 file

Il mod era scritto per una versione di [Petari](https://github.com/SMGCommunity/Petari)
di parecchi mesi prima e non compilava più: nel frattempo la decompilazione
ha rinominato campi e metodi. Il blocco non era funzionalità mancante, era
deriva di nomi. Le corrispondenze principali:

| Prima | Adesso |
|---|---|
| `_84`, `_24`, `_18` | `mMtxBuffer`, `mBaseTransformMtx`, `mBaseScale` |
| `_8 & 3` | `getMtxCalcMode()` |
| `j3dSys.mCurrentModel` | `setModel()` |
| `mJointsByIdx[i]` | `getJointNodePointer(i)` |
| `mMatrixData.mDrawMatrixCount` | `getDrawMtxNum()` |
| `mActor`, `mFlags.mIsDead` | `mHost`, `mFlag.mIsDead` |

Più le correzioni di quattro difetti del mod stesso e le due aggiunte del
mondo condiviso:

- **`CoinSync.cpp`** — riscrive `__vt__4Coin + 0x74` (`receiveOtherMsg`) per
  annunciare la moneta raccolta. L'identità che viaggia sulla rete è
  l'indice dentro il `CoinHolder`, che è lo stesso su tutte le macchine
  perché deriva dall'ordine nel file della galassia.
- **`ActorSync.cpp`** — stessa idea per la morte dei nemici, su 47 tipi.
  26 hanno la vtable esportata; per gli altri 21 la vtable è stata dedotta
  disassemblando il costruttore, e il codice la **verifica a runtime** prima
  di scriverci sopra: se i puntatori a `init` e `kill` non sono quelli
  attesi, quel tipo viene semplicemente saltato invece di corrompere memoria.

### Come compilarlo (e perché qui non è compilato)

Serve **CodeWarrior per PowerPC con licenza Gekko**. Non è un capriccio:
il mod scrive dentro le vtable del gioco e chiama funzioni per nome
decorato, quindi layout delle vtable e name mangling devono coincidere
esattamente con quelli dell'eseguibile Wii. GCC produce un ABI diverso e non
serve a niente. L'edizione gratuita Special Edition di NXP si installa e
funziona, ma la sua licenza rifiuta `-proc gekko` e `-proc 750`, e gli
header dell'SDK Wii richiedono `psq_st`, che è un'istruzione esclusiva del
Gekko.

Per questo il `CustomCode_USA.bin` nel pacchetto è la build originale
dell'autore, senza monete e nemici condivisi — con un'unica eccezione, sotto.

---

## `patch-pesi/` — la camminata, patchata a mano

La camminata di Mario è il gruppo `基本`, che fonde 4 tracce con pesi
ricalcolati a ogni fotogramma (`MarioAnimator::setWalkWeight` →
`XanimePlayer::changeTrackWeight`). Il pacchetto posizione trasportava solo
l'indice del gruppo: il pupazzo riceveva `基本`, `changeAnimation` caricava i
pesi predefiniti del file e nessuno li aggiornava più. Risultato: scivolava.

Invece di aspettare il compilatore, la patch modifica direttamente il binario
Kamek già compilato:

| Punto | Dove | Cosa fa |
|---|---|---|
| T1 | `updatePackets`, codice+0x2DB8 | `r5` è l'`XanimePlayer` di Mario: copia i 4 pesi (`+0x10`) in un buffer |
| T2 | codice+0x2E78, chiamata a `netWriteToBuffer` | scrive i pesi nei byte 56..71 del pacchetto |
| K | codice+0x5680, `implementationSize` | 56 → 72: buffer riservato e datagramma inviato crescono di 16 byte |
| T3 | ingresso di `netReadFromBuffer`, codice+0xB78 | se il pacchetto è ≥ 72 byte salva i pesi per id globale, altrimenti segna «senza pesi» |
| T4 | `calcAnim_ep`, codice+0x19D4 | se ci sono pesi per quel giocatore li scrive in `playerXanimes[i].mWeights` |

La prima versione agganciava T4 a 0x19D8, l'incremento del ciclo. Lì però
arrivano anche i giocatori inattivi (`beq` a 0x15BC) prima che `r22` sia
impostato, e la lettura dell'id finiva a un indirizzo casuale: Dolphin la
segnalava come crash su hardware vero. 0x19D4 è l'ultima istruzione del solo
percorso dei giocatori attivi. `patchweights.py` ora rifiuta qualsiasi
aggancio su cui atterri un salto, condizionato o no, salvo eccezioni
verificate e motivate una per una; `simulate.py` tratta come errore ogni
accesso fuori dalla memoria mappata e prova il percorso dell'inattivo.

Nota sul loader Syati di `riivo_USA.xml`: per i binari v2 calcola la fine
dei comandi con 16 byte di troppo e interpreta come comandi i 16 byte di
memoria dopo la fine del file. Il difetto c'era già con l'originale; su
Dolphin quella memoria è a zero e i comandi finti vengono solo segnalati
come «Unknown command: 0».

Il codice nuovo sta **dopo il BSS**, che diventa parte del codice (zeri nel
file) con dimensione zero: se lo mettessi subito dopo il codice, il BSS
slitterebbe e ogni riferimento del mod alle sue variabili globali si
romperebbe. Il controllo di lunghezza in lettura resta 56, quindi versioni
vecchie e nuove si capiscono in entrambe le direzioni.

### Friendly fire, nella stessa patch

| Punto | Dove | Cosa fa |
|---|---|---|
| S1 | `updatePackets`, codice+0x2DE8 | se `MarioActor::_946 > 45` accende il bit `0x02` (piroetta) nei flag del pacchetto |
| V1 | `receiveMsgPush`, codice+0x39A4 | `li r4,0x4F` → `li r4,0x53`: lo schianto manda `ACTMES_ENEMY_ATTACK`, il colpo standard che toglie vita, invece dello stordimento `ENEMY_ATTACK_FLIP_JUMP` |
| V2 | `receiveMsgPush`, codice+0x3994 | bit piroetta: `receiveMessage(0x51)`, cioè `ACTMES_ENEMY_ATTACK_FLIP_ROT` (a terra `doFlipRot`: sbalzato via, nessuna vita tolta), con una pausa di 60 fotogrammi per giocatore riusando `jumpCooldown`; se no l'animazione ripartirebbe a ogni fotogramma |

La prima versione riconosceva la piroetta con `MR::isPlayerSwingAction()`, e
mandava `ACTMES_ENEMY_ATTACK_COUNTER_SPIN` (`0x60`). In gioco, misurato con
`Sniff.exe`, il flag non partiva mai: quella funzione risulta falsa durante
una piroetta normale. Il gioco invece, quando parte la piroetta, imposta il
contatore `MarioActor::_946 = mSpinIntervalTime + 0x22` (79) e lo fa
scendere di uno a fotogramma: sopra 45 si sta girando. In aria il gioco lo
azzera, quindi conta la piroetta a terra. `0x60` è stato sostituito da
`0x51`, che Begoman, BossBegoman e Kamek mandano a un Mario qualsiasi;
`COUNTER_SPIN` il gioco lo usa solo contro un Mario che sta già girando.

Chi decide è la console di chi subisce: quando il suo Mario tocca il sensore
del pupazzo dell'altro, il mod guarda i flag nel pacchetto di quello. Il
server, col friendly fire spento, cancella i bit `0x01|0x02` dai byte che
inoltra (`source/main.cpp`, `pollFriendlyFire`), e la prova è
`source/tests/fftest.cpp`.

Che `ACTMES_ENEMY_ATTACK` tolga esattamente 1 di vita è il comportamento del
gioco con i nemici comuni; `Mario::damage`/`faint` in Petari non sono ancora
decompilate, quindi non è stato letto nel codice.

| File | |
|---|---|
| `kmn.py` | lettore e disassemblatore di binari Kamek, con le rilocazioni |
| `ppcasm.py` | assemblatore PowerPC minimo, con `@ha`/`@l` tradotti in rilocazioni |
| `patchweights.py` | la patch: controlla ogni parola originale prima di sovrascriverla |
| `simulate.py` | caricatore Kamek + mini emulatore PowerPC che esegue i quattro agganci |
| `CustomCode_USA.orig.bin` | il binario originale dell'autore |

```bash
python3 patchweights.py CustomCode_USA.orig.bin CustomCode_USA.bin
python3 simulate.py
```

Le verifiche fatte: caricati allo stesso indirizzo, originale e patchato
differiscono solo nelle cinque parole volute (nessuna rilocazione esistente
spostata); i quattro agganci eseguiti in emulazione preservano i registri che
il codice originale usa dopo; e `source/tests/weighttest.cpp` fa passare
pacchetti da 72 byte attraverso il server vero e attraverso `Follow`.
Quello che **non** è stato verificato qui è l'effetto a video: va provato in
Dolphin.

**Se un giorno il mod viene ricompilato**, questa patch si perde: la stessa
modifica va portata nel sorgente (`multiplayer.cpp` per l'invio,
`packets.cpp` per la lunghezza, `multimodel.cpp` per l'applicazione dei pesi).

Una volta ottenuto il compilatore: `Makefile` e `config.mk.template` sono in
`mod/`, e servono [Petari](https://github.com/SMGCommunity/Petari),
[Kamek](https://github.com/Treeki/Kamek) e Bussun.
