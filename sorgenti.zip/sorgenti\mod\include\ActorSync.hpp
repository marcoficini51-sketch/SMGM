#ifndef ACTORSYNC_HPP
#define ACTORSYNC_HPP

#include "packets/actorKill.hpp"
#include "concurrencyUtils.hpp"

class LiveActor;
class JMapInfoIter;

extern ConcurrentQueue<Packets::ActorKilled> netActorKillQueue;

namespace ActorSync {
    void initQueue();

    // Annota da quale riga del livello e' nato questo attore. Chiamata dagli
    // hook di init, prima che qualcuno possa morire.
    void record(LiveActor *actor, const JMapInfoIter &iter);

    // Comunica agli altri che questo attore e' morto qui.
    void broadcastDeath(LiveActor *actor);

    // Applica le morti ricevute. Una volta per frame, dal thread di gioco.
    void drainQueue();

    // Da chiamare al cambio di scena: gli attori annotati non esistono piu'.
    void reset();

    u32 hashName(const char *name);

    // Aggancia le classi la cui vtable non e' nella mappa dei simboli, dopo
    // averne verificato la firma. Restituisce quante ne ha agganciate: se il
    // numero e' minore del totale, qualche indirizzo dedotto era sbagliato.
    u32 applyDerivedVtables();
}

#endif
