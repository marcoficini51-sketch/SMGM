#ifndef COINSYNC_HPP
#define COINSYNC_HPP

#include "packets/coin.hpp"
#include "concurrencyUtils.hpp"

// I pacchetti arrivano nel thread dei callback di rete, ma una moneta puo'
// essere uccisa solo dal thread di gioco. La coda fa da passaggio di consegne,
// come gia' avviene per gli star bit.
extern ConcurrentQueue<Packets::CoinCollected> netCoinQueue;

namespace CoinSync {
    void initQueue();

    // Da chiamare una volta per frame dal thread di gioco.
    void drainQueue();
}

#endif
