#ifndef PACKETS_ACTORKILL_HPP
#define PACKETS_ACTORKILL_HPP

#include "packets.hpp"
#include "playerCommon.hpp"

namespace Packets {

// Un nemico ucciso da un altro giocatore.
//
// L'identita' e' la riga del file di livello da cui il nemico e' nato
// (JMapInfoIter::mIndex), catturata al momento dell'init. E' l'identificatore
// piu' solido disponibile: non cambia mai durante la partita e per definizione
// e' identico su ogni macchina che carica la stessa stella - a differenza di un
// indice in una lista, che scivola quando gli oggetti entrano ed escono.
//
// L'indice da solo pero' non basta: gli oggetti nascono da piu' tabelle (una
// per zona e livello), e la riga 5 esiste in tutte. Ci affianchiamo un hash del
// nome, cosi' una collisione richiederebbe due oggetti con lo stesso nome alla
// stessa riga di tabelle diverse.
class _ActorKilled {
    const static u32 implementationSize;
public:
    Multiplayer::Id playerId;
    u16 actorIndex;
    u32 nameHash;

    inline _ActorKilled() : actorIndex(0), nameHash(0) {}
    NetReturn netWriteToBuffer(void *buff, u32 len) const;
    static NetReturn netReadFromBuffer(Packet<_ActorKilled> *out, const void *buff, u32 len);
    static inline Tag getTag() {return ACTOR_KILLED;}
    inline u32 getSize() const {return implementationSize;}
};

typedef Packet<_ActorKilled> ActorKilled;

}

#endif
