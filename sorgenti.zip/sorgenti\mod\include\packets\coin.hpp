#ifndef PACKETS_COIN_HPP
#define PACKETS_COIN_HPP

#include "packets.hpp"
#include "playerCommon.hpp"

namespace Packets {

// Una moneta raccolta da un altro giocatore.
//
// L'identita' della moneta e' il suo indice dentro il CoinHolder della scena.
// Non e' un espediente: il gruppo viene riempito da registerActor() nell'ordine
// in cui gli oggetti nascono dai dati del livello, e due console che caricano
// la stessa galassia e la stessa stella li leggono nello stesso ordine. Quindi
// l'indice i indica la stessa identica moneta su entrambe.
class _CoinCollected {
    const static u32 implementationSize;
public:
    Multiplayer::Id playerId;
    u16 coinIndex;

    inline _CoinCollected() : coinIndex(0) {}
    NetReturn netWriteToBuffer(void *buff, u32 len) const;
    static NetReturn netReadFromBuffer(Packet<_CoinCollected> *out, const void *buff, u32 len);
    static inline Tag getTag() {return COIN_COLLECTED;}
    inline u32 getSize() const {return implementationSize;}
};

typedef Packet<_CoinCollected> CoinCollected;

}

#endif
