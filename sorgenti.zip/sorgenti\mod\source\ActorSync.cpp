// Morte dei nemici condivisa.
//
// Se uccidi un nemico, muore anche sullo schermo degli altri. Rispetto alle
// monete cambia il modo di dare un nome all'oggetto: non esiste un gruppo
// globale dei nemici, quindi l'identita' viene dalla riga del file di livello
// (JMapInfoIter::mIndex), catturata al momento dell'init.
//
// L'aggancio e' per classe, riscrivendo due voci della vtable: init per
// annotare l'identita', kill per trasmettere la morte. In fondo al file c'e'
// l'elenco delle classi coperte: aggiungerne una e' una riga.
//
// LIMITE NOTO: funziona solo per le classi la cui vtable e' esportata nella
// mappa dei simboli di Bussun - 43 delle 109 in Game/Enemy. Di quelle 43 ne
// sono collegate 26: le restanti sono contenitori (*Holder, KarikariDirector),
// oggetti di stato dell'IA (WalkerState*), pezzi di modello
// (WaterBazookaCapsule) e proiettili (KameckBeam, TakoHeiInk, KabokuriFire),
// per cui replicare la morte non avrebbe senso.
//
// Per i 66 nemici senza vtable esportata servirebbe ricavarne l'indirizzo per
// altra via: e' lavoro di reverse engineering, non di codice.

#include "ActorSync.hpp"
#include "multiplayer.hpp"
#include "globalTransmitter.hpp"
#include "debug.hpp"

#include <Game/LiveActor/LiveActor.hpp>
#include <Game/Util/JMapInfo.hpp>

#include <kamek/hooks.h>

ConcurrentQueue<Packets::ActorKilled> netActorKillQueue;
static ConcurrentQueue<Packets::ActorKilled>::Block netActorKillQueueBuffer[16];

// Quanti nemici seguire per scena. Oltre il limite semplicemente non vengono
// sincronizzati, invece di scrivere fuori dall'array. A 8 byte per voce sono
// poco piu' di 1 KB: si puo' alzare senza pensarci troppo.
static const u32 MAX_TRACKED = 192;

struct TrackedActor {
    LiveActor *actor;
    u32 nameHash;
    u16 index;
};

static TrackedActor tracked[MAX_TRACKED];
static u32 trackedCount = 0;

void ActorSync::initQueue() {
    netActorKillQueue.init(netActorKillQueueBuffer,
        sizeof(netActorKillQueueBuffer) / sizeof(*netActorKillQueueBuffer));
    trackedCount = 0;

    // Le vtable stanno in .data e ci sono fin dall'avvio, quindi si possono
    // agganciare subito: nessun nemico e' ancora nato.
    setDebugMsg(10, (u8)applyDerivedVtables());
}

void ActorSync::reset() {
    trackedCount = 0;
}

u32 ActorSync::hashName(const char *name) {
    // FNV-1a: corto, senza tabelle, e sparpaglia bene nomi simili come
    // "Kuribo" e "KuriboMini".
    u32 h = 2166136261u;
    if(name == nullptr) return h;
    while(*name) {
        h ^= (u32)(u8)*name++;
        h *= 16777619u;
    }
    return h;
}

void ActorSync::record(LiveActor *actor, const JMapInfoIter &iter) {
    if(actor == nullptr) return;
    if(trackedCount >= MAX_TRACKED) return;
    if(iter.mIndex < 0 || iter.mIndex > 0xFFFF) return;

    tracked[trackedCount].actor = actor;
    tracked[trackedCount].nameHash = hashName(actor->getName());
    tracked[trackedCount].index = (u16)iter.mIndex;
    trackedCount++;
}

void ActorSync::broadcastDeath(LiveActor *actor) {
    if(!Multiplayer::connected || actor == nullptr) return;

    for(u32 i = 0; i < trackedCount; i++) {
        if(tracked[i].actor != actor) continue;

        Packets::ActorKilled packet;
        packet.playerId = Packets::PlayerPosition::consoleId;
        packet.actorIndex = tracked[i].index;
        packet.nameHash = tracked[i].nameHash;
        setDebugMsg(2, Multiplayer::transmitter.addPacket(packet).err);
        return;
    }
}

void ActorSync::drainQueue() {
    const Packets::ActorKilled *packet;

    while(packet = netActorKillQueue.read()) {
        for(u32 i = 0; i < trackedCount; i++) {
            if(tracked[i].index != packet->actorIndex) continue;
            if(tracked[i].nameHash != packet->nameHash) continue;

            LiveActor *actor = tracked[i].actor;
            // Se e' gia' morto l'abbiamo ucciso anche noi nello stesso
            // istante: non c'e' altro da fare.
            if(actor != nullptr && !actor->mFlag.mIsDead) {
                actor->kill();
            }
            break;
        }
        netActorKillQueue.advance();
    }
}

// ---------------------------------------------------------------------------
// Aggancio per classe.
//
// init  -> vtable 0x0C : annota l'identita' e prosegue
// kill  -> vtable 0x2C : trasmette la morte e prosegue
//
// La chiamata qualificata (self->CLASS::init) salta la vtable che abbiamo
// appena dirottato e va dritta al codice originale del gioco.
// ---------------------------------------------------------------------------

#define SYNC_ENEMY(CLASS, VTSYM)                                              \
    static void CLASS##_initSync(CLASS *self, const JMapInfoIter &iter) {     \
        self->CLASS::init(iter);                                              \
        ActorSync::record(self, iter);                                        \
    }                                                                         \
    static void CLASS##_killSync(CLASS *self) {                               \
        ActorSync::broadcastDeath(self);                                      \
        self->CLASS::kill();                                                  \
    }                                                                         \
    extern kmSymbol VTSYM;                                                    \
    kmWritePointer(&VTSYM + 0x0C, CLASS##_initSync);                          \
    kmWritePointer(&VTSYM + 0x2C, CLASS##_killSync)

// ---------------------------------------------------------------------------
// Classi la cui vtable non e' nella mappa dei simboli.
//
// L'indirizzo si deduce, quindi non lo si puo' usare a tempo di caricamento:
// una deduzione sbagliata scriverebbe in mezzo a dati altrui. Qui invece si
// legge prima, si confronta con una firma nota, e si scrive solo se combacia.
// ---------------------------------------------------------------------------

struct DerivedVtable {
    u32 *vtable;
    u32 expectedInit;
    u32 expectedKill;
    void *hookInit;
    void *hookKill;
    bool applied;
};

#define DERIVED_HOOKS(CLASS)                                                  \
    static void CLASS##_initDerived(CLASS *self, const JMapInfoIter &iter) {  \
        self->CLASS::init(iter);                                              \
        ActorSync::record(self, iter);                                        \
    }                                                                         \
    static void CLASS##_killDerived(CLASS *self) {                            \
        ActorSync::broadcastDeath(self);                                      \
        self->CLASS::kill();                                                  \
    }

// >>> ELENCO NEMICI <<<
#include <Game/Enemy/HammerHeadPackun.hpp>
#include <Game/Enemy/Hanachan.hpp>
#include <Game/Enemy/HomingKiller.hpp>
#include <Game/Enemy/IceMerameraKing.hpp>
#include <Game/Enemy/Jellyfish.hpp>
#include <Game/Enemy/JellyfishElectric.hpp>
#include <Game/Enemy/Jiraira.hpp>
#include <Game/Enemy/JumpBeamer.hpp>
#include <Game/Enemy/JumpGuarder.hpp>
#include <Game/Enemy/JumpSpider.hpp>
#include <Game/Enemy/Kabokuri.hpp>
#include <Game/Enemy/Kameck.hpp>
#include <Game/Enemy/KameckTurtle.hpp>
#include <Game/Enemy/Kanina.hpp>
#include <Game/Enemy/Karikari.hpp>
#include <Game/Enemy/Karon.hpp>
#include <Game/Enemy/Kiraira.hpp>
#include <Game/Enemy/OnimasuJump.hpp>
#include <Game/Enemy/StinkBugParent.hpp>
#include <Game/Enemy/StringSpider.hpp>
#include <Game/Enemy/TakoHei.hpp>
#include <Game/Enemy/Takobo.hpp>
#include <Game/Enemy/Teresa.hpp>
#include <Game/Enemy/TeresaWater.hpp>
#include <Game/Enemy/Unizo.hpp>
#include <Game/Enemy/WaterBazooka.hpp>

SYNC_ENEMY(HammerHeadPackun,     __vt__16HammerHeadPackun);
SYNC_ENEMY(Hanachan,             __vt__8Hanachan);
SYNC_ENEMY(HomingKiller,         __vt__12HomingKiller);
SYNC_ENEMY(IceMerameraKing,      __vt__15IceMerameraKing);
SYNC_ENEMY(Jellyfish,            __vt__9Jellyfish);
SYNC_ENEMY(JellyfishElectric,    __vt__17JellyfishElectric);
SYNC_ENEMY(Jiraira,              __vt__7Jiraira);
SYNC_ENEMY(JumpBeamer,           __vt__10JumpBeamer);
SYNC_ENEMY(JumpGuarder,          __vt__11JumpGuarder);
SYNC_ENEMY(JumpSpider,           __vt__10JumpSpider);
SYNC_ENEMY(Kabokuri,             __vt__8Kabokuri);
SYNC_ENEMY(Kameck,               __vt__6Kameck);
SYNC_ENEMY(KameckTurtle,         __vt__12KameckTurtle);
SYNC_ENEMY(Kanina,               __vt__6Kanina);
SYNC_ENEMY(Karikari,             __vt__8Karikari);
SYNC_ENEMY(Karon,                __vt__5Karon);
SYNC_ENEMY(Kiraira,              __vt__7Kiraira);
SYNC_ENEMY(OnimasuJump,          __vt__11OnimasuJump);
SYNC_ENEMY(StinkBugParent,       __vt__14StinkBugParent);
SYNC_ENEMY(StringSpider,         __vt__12StringSpider);
SYNC_ENEMY(TakoHei,              __vt__7TakoHei);
SYNC_ENEMY(Takobo,               __vt__6Takobo);
SYNC_ENEMY(Teresa,               __vt__6Teresa);
SYNC_ENEMY(TeresaWater,          __vt__11TeresaWater);
SYNC_ENEMY(Unizo,                __vt__5Unizo);
SYNC_ENEMY(WaterBazooka,         __vt__12WaterBazooka);

// >>> VTABLE DEDOTTE <<<

// La vtable di queste classi non e' nella mappa dei simboli di Bussun.
// L'indirizzo e' dedotto dalla mappa coreana di Petari applicando lo
// scarto misurato sui vicini immediati - ma NON ci fidiamo: prima di
// scrivere, il mod verifica che le voci init e kill contengano gli
// indirizzi noti di quella classe. E' una firma da 64 bit: se la
// deduzione fosse sbagliata non combacerebbe, e non si scrive nulla.

#include <Game/Enemy/BasaBasa.hpp>
#include <Game/Enemy/BegomanBaby.hpp>
#include <Game/Enemy/BegomanLauncher.hpp>
#include <Game/Enemy/BombHei.hpp>
#include <Game/Enemy/CocoSambo.hpp>
#include <Game/Enemy/DharmaSambo.hpp>
#include <Game/Enemy/FireBubble.hpp>
#include <Game/Enemy/KoopaJrShip.hpp>
#include <Game/Enemy/Kuribo.hpp>
#include <Game/Enemy/KuriboChief.hpp>
#include <Game/Enemy/KuriboMini.hpp>
#include <Game/Enemy/Meramera.hpp>
#include <Game/Enemy/Metbo.hpp>
#include <Game/Enemy/Mogu.hpp>
#include <Game/Enemy/Mogucchi.hpp>
#include <Game/Enemy/PackunPetit.hpp>
#include <Game/Enemy/Petari.hpp>
#include <Game/Enemy/Pukupuku.hpp>
#include <Game/Enemy/SamboHead.hpp>
#include <Game/Enemy/Snakehead.hpp>
#include <Game/Enemy/StinkBugSmall.hpp>

DERIVED_HOOKS(BasaBasa)
DERIVED_HOOKS(BegomanBaby)
DERIVED_HOOKS(BegomanLauncher)
DERIVED_HOOKS(BombHei)
DERIVED_HOOKS(CocoSambo)
DERIVED_HOOKS(DharmaSambo)
DERIVED_HOOKS(FireBubble)
DERIVED_HOOKS(KoopaJrShip)
DERIVED_HOOKS(Kuribo)
DERIVED_HOOKS(KuriboChief)
DERIVED_HOOKS(KuriboMini)
DERIVED_HOOKS(Meramera)
DERIVED_HOOKS(Metbo)
DERIVED_HOOKS(Mogu)
DERIVED_HOOKS(Mogucchi)
DERIVED_HOOKS(PackunPetit)
DERIVED_HOOKS(Petari)
DERIVED_HOOKS(Pukupuku)
DERIVED_HOOKS(SamboHead)
DERIVED_HOOKS(Snakehead)
DERIVED_HOOKS(StinkBugSmall)

static DerivedVtable derivedTable[] = {
    { (u32 *)0x80564B24U,          0x800CD9ACU, 0x800CEBC4U, (void *)BasaBasa_initDerived, (void *)BasaBasa_killDerived, false },
    { (u32 *)0x80564EF0U,       0x800CFD84U, 0x800D008CU, (void *)BegomanBaby_initDerived, (void *)BegomanBaby_killDerived, false },
    { (u32 *)0x80565454U,   0x800D4F1CU, 0x800D52BCU, (void *)BegomanLauncher_initDerived, (void *)BegomanLauncher_killDerived, false },
    { (u32 *)0x8056672CU,           0x800DD204U, 0x800DD6A8U, (void *)BombHei_initDerived, (void *)BombHei_killDerived, false },
    { (u32 *)0x805670F4U,         0x800E5560U, 0x800E57ACU, (void *)CocoSambo_initDerived, (void *)CocoSambo_killDerived, false },
    { (u32 *)0x805675BCU,       0x800E6F6CU, 0x800E72A4U, (void *)DharmaSambo_initDerived, (void *)DharmaSambo_killDerived, false },
    { (u32 *)0x80567D68U,        0x800EC87CU, 0x800ECAC0U, (void *)FireBubble_initDerived, (void *)FireBubble_killDerived, false },
    { (u32 *)0x8056BC84U,       0x801120C4U, 0x80112348U, (void *)KoopaJrShip_initDerived, (void *)KoopaJrShip_killDerived, false },
    { (u32 *)0x8056C5BCU,            0x80117A80U, 0x80118024U, (void *)Kuribo_initDerived, (void *)Kuribo_killDerived, false },
    { (u32 *)0x8056C890U,       0x80119EBCU, 0x8011A3B8U, (void *)KuriboChief_initDerived, (void *)KuriboChief_killDerived, false },
    { (u32 *)0x8056CA6CU,        0x8011B290U, 0x8011B638U, (void *)KuriboMini_initDerived, (void *)KuriboMini_killDerived, false },
    { (u32 *)0x8056D17CU,          0x8011E720U, 0x8011EC5CU, (void *)Meramera_initDerived, (void *)Meramera_killDerived, false },
    { (u32 *)0x8056D48CU,             0x801229A0U, 0x801236F0U, (void *)Metbo_initDerived, (void *)Metbo_killDerived, false },
    { (u32 *)0x8056D7D8U,              0x80124888U, 0x80124BF4U, (void *)Mogu_initDerived, (void *)Mogu_killDerived, false },
    { (u32 *)0x8056DA40U,          0x801261E8U, 0x80126410U, (void *)Mogucchi_initDerived, (void *)Mogucchi_killDerived, false },
    { (u32 *)0x8056EAD0U,       0x8012FDA8U, 0x8013079CU, (void *)PackunPetit_initDerived, (void *)PackunPetit_killDerived, false },
    { (u32 *)0x8056EE04U,            0x8013161CU, 0x80131838U, (void *)Petari_initDerived, (void *)Petari_killDerived, false },
    { (u32 *)0x8056F4C0U,          0x80136E60U, 0x8013707CU, (void *)Pukupuku_initDerived, (void *)Pukupuku_killDerived, false },
    { (u32 *)0x8056F96CU,         0x8013A030U, 0x8013A338U, (void *)SamboHead_initDerived, (void *)SamboHead_killDerived, false },
    { (u32 *)0x8056FEC4U,         0x8013D5A4U, 0x8013DB00U, (void *)Snakehead_initDerived, (void *)Snakehead_killDerived, false },
    { (u32 *)0x805705ACU,     0x80140B54U, 0x80141614U, (void *)StinkBugSmall_initDerived, (void *)StinkBugSmall_killDerived, false },
};

static const u32 DERIVED_COUNT = sizeof(derivedTable) / sizeof(*derivedTable);

u32 ActorSync::applyDerivedVtables() {
    u32 applied = 0;
    for(u32 i = 0; i < DERIVED_COUNT; i++) {
        DerivedVtable &e = derivedTable[i];
        if(e.applied) { applied++; continue; }
        // legge, verifica, e solo allora scrive
        if(e.vtable[0x0C / 4] != e.expectedInit) continue;
        if(e.vtable[0x2C / 4] != e.expectedKill) continue;
        e.vtable[0x0C / 4] = (u32)e.hookInit;
        e.vtable[0x2C / 4] = (u32)e.hookKill;
        e.applied = true;
        applied++;
    }
    return applied;
}
