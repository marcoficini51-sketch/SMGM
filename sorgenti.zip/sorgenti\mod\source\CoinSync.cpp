// Monete condivise.
//
// Quando raccogli una moneta, l'evento viene trasmesso e la stessa moneta
// sparisce anche sullo schermo degli altri. E' il primo pezzo di stato del
// mondo davvero condiviso: fino a qui ognuno vedeva il proprio.
//
// Scelta di progetto: chi riceve fa sparire la moneta ma NON se l'accredita.
// Accreditarla a tutti significherebbe anche incrementare mHostInfo->_C, che
// il gioco usa per contare quante monete restano da far comparire a un oggetto
// ospite: toccarlo da fuori rischia di sfasare quella contabilita'. Meglio
// "mondo condiviso, punteggio separato" - chi arriva primo prende.

#include "CoinSync.hpp"
#include "multiplayer.hpp"
#include "globalTransmitter.hpp"
#include "debug.hpp"

#include <Game/MapObj/Coin.hpp>
#include <Game/MapObj/CoinHolder.hpp>
#include <Game/Util/ActorSensorUtil.hpp>
#include <Game/Util/ObjUtil.hpp>
#include <Game/LiveActor/HitSensor.hpp>
#include <Game/Util/EffectUtil.hpp>

#include <kamek/hooks.h>

ConcurrentQueue<Packets::CoinCollected> netCoinQueue;
static ConcurrentQueue<Packets::CoinCollected>::Block netCoinQueueBuffer[16];

void CoinSync::initQueue() {
    netCoinQueue.init(netCoinQueueBuffer, sizeof(netCoinQueueBuffer) / sizeof(*netCoinQueueBuffer));
}

// L'indice della moneta nel gruppo della scena. Lineare, ma il gruppo e'
// piccolo e la ricerca avviene solo nell'istante della raccolta.
static s32 findCoinIndex(const Coin *coin) {
    CoinHolder *holder = MR::getCoinHolder();
    if(holder == nullptr) return -1;

    s32 count = holder->getObjNum();
    for(s32 i = 0; i < count; i++) {
        if(holder->getMember(i) == coin) return i;
    }
    return -1;
}

// Sostituisce Coin::receiveOtherMsg nella vtable: trasmette la raccolta e poi
// lascia fare al gioco esattamente quello che faceva prima.
static bool CoinReceiveOtherMsgAndBroadcast(Coin *self, u32 msg, HitSensor *sender, HitSensor *receiver) {
    if(MR::isMsgItemGet(msg) && Multiplayer::connected) {
        s32 idx = findCoinIndex(self);
        if(idx >= 0 && idx <= 0xFFFF) {
            Packets::CoinCollected packet;
            packet.playerId = Packets::PlayerPosition::consoleId;
            packet.coinIndex = (u16)idx;
            setDebugMsg(2, Multiplayer::transmitter.addPacket(packet).err);
        }
    }

    // Chiamata qualificata: salta la vtable, che abbiamo appena dirottato, e
    // va dritta all'implementazione originale.
    return self->Coin::receiveOtherMsg(msg, sender, receiver);
}

extern kmSymbol __vt__4Coin;
kmWritePointer(&__vt__4Coin + 0x74, CoinReceiveOtherMsgAndBroadcast);

void CoinSync::drainQueue() {
    const Packets::CoinCollected *packet;
    CoinHolder *holder = MR::getCoinHolder();

    while(packet = netCoinQueue.read()) {
        if(holder != nullptr) {
            s32 count = holder->getObjNum();
            if(packet->coinIndex < count) {
                Coin *coin = holder->getMember(packet->coinIndex);
                // Se e' gia' morta l'abbiamo raccolta anche noi nello stesso
                // istante: non c'e' niente da fare, e insistere emetterebbe
                // un secondo effetto sul nulla.
                if(coin != nullptr && !coin->mFlag.mIsDead) {
                    MR::emitEffect(coin, "CoinGet");
                    coin->kill();
                }
            }
        }
        netCoinQueue.advance();
    }
}
