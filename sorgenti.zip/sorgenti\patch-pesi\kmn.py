#!/usr/bin/env python3
"""Lettore e disassemblatore di binari Kamek dinamici (formato v2).

Struttura del file:
  0x00  "Kamek\\0\\0\\2"
  0x08  dimensione BSS
  0x0C  dimensione del codice
  0x10  inizio / fine della tabella dei costruttori (offset nel codice)
  0x20  codice
  dopo  comandi di collegamento, fino a fine file

Ogni comando e' una parola: 8 bit di tipo, 24 bit di indirizzo. L'indirizzo
0xFFFFFE vuol dire "assoluto, nella parola successiva"; altrimenti e' un
offset nel codice. Gli argomenti sotto 0x80000000 sono anch'essi offset nel
codice (e' cosi' che il caricatore di Kamek li risolve).

  kmn.py info
  kmn.py dis <inizio> <fine>        offset di codice, esadecimali
  kmn.py xref <bersaglio>           chi punta a un offset o a un indirizzo
  kmn.py word <valore>              dove compare una parola nel codice
  kmn.py hooks                      comandi con indirizzo assoluto (patch al gioco)
"""
import struct, sys

CMD = {0: "Null", 1: "Addr32", 4: "Addr16Lo", 5: "Addr16Hi", 6: "Addr16Ha",
       10: "Rel24", 32: "Write32", 33: "Write16", 34: "Write8",
       35: "CondWritePointer", 36: "CondWrite32", 37: "CondWrite16",
       38: "CondWrite8", 64: "Branch", 65: "BranchLink"}
NARGS = {0: 0, 1: 1, 4: 1, 5: 1, 6: 1, 10: 1, 32: 1, 33: 1, 34: 1,
         35: 2, 36: 2, 37: 2, 38: 2, 64: 1, 65: 1}
CODE_OFF = 0x20


class Kamek:
    def __init__(self, path):
        self.raw = open(path, "rb").read()
        assert self.raw[:8] == b"Kamek\0\0\2", "non e' un binario Kamek v2"
        (self.bss, self.size, self.ctor0, self.ctor1) = struct.unpack(">IIII", self.raw[8:24])
        self.code = self.raw[CODE_OFF:CODE_OFF + self.size]
        self.cmds = []           # (posizione nel file, tipo, indirizzo, assoluto?, [argomenti])
        p = CODE_OFF + self.size
        while p + 4 <= len(self.raw):
            start = p
            hdr, = struct.unpack(">I", self.raw[p:p+4]); p += 4
            t, a = hdr >> 24, hdr & 0xFFFFFF
            absolute = a == 0xFFFFFE
            if absolute:
                a, = struct.unpack(">I", self.raw[p:p+4]); p += 4
            n = NARGS.get(t)
            if n is None:
                raise SystemExit("comando sconosciuto %d a 0x%X" % (t, start))
            args = list(struct.unpack(">%dI" % n, self.raw[p:p+4*n])); p += 4*n
            self.cmds.append((start, t, a, absolute, args))
        self.reloc = {}          # offset nel codice -> (tipo, bersaglio)
        for _, t, a, ab, args in self.cmds:
            if not ab and args:
                self.reloc[a] = (t, args[0])

    def word(self, off):
        return struct.unpack(">I", self.code[off:off+4])[0]


def tgt(v):
    return ("0x%08X" % v) if v & 0x80000000 else ("codice+0x%X" % v)


# ------------------------------------------------------------------ decodifica
def S16(v): return v - 0x10000 if v & 0x8000 else v

R = lambda n: "r%d" % n
F = lambda n: "f%d" % n
SPR = {1: "xer", 8: "lr", 9: "ctr", 912: "gqr0", 913: "gqr1", 914: "gqr2",
       915: "gqr3", 916: "gqr4", 917: "gqr5", 918: "gqr6", 919: "gqr7",
       920: "hid2", 1008: "hid0", 1009: "hid1", 268: "tbl", 269: "tbu", 26: "srr0", 27: "srr1"}

X31 = {0: "cmpw", 32: "cmplw", 8: "subfc", 10: "addc", 11: "mulhwu", 19: "mfcr",
       20: "lwarx", 23: "lwzx", 24: "slw", 26: "cntlzw", 28: "and", 40: "subf",
       54: "dcbst", 55: "lwzux", 60: "andc", 75: "mulhw", 83: "mfmsr", 86: "dcbf",
       87: "lbzx", 104: "neg", 119: "lbzux", 124: "nor", 136: "subfe", 138: "adde",
       144: "mtcrf", 146: "mtmsr", 150: "stwcx.", 151: "stwx", 183: "stwux",
       200: "subfze", 202: "addze", 215: "stbx", 234: "addme", 235: "mullw",
       266: "add", 279: "lhzx", 284: "eqv", 311: "lhzux", 316: "xor", 339: "mfspr",
       343: "lhax", 371: "mftb", 407: "sthx", 412: "orc", 444: "or", 459: "divwu",
       467: "mtspr", 470: "dcbi", 476: "nand", 491: "divw", 535: "lfsx", 536: "srw",
       567: "lfsux", 598: "sync", 599: "lfdx", 663: "stfsx", 727: "stfdx",
       792: "sraw", 824: "srawi", 854: "eieio", 922: "extsh", 954: "extsb",
       982: "icbi", 1014: "dcbz"}
MEM = {32: "lwz", 33: "lwzu", 34: "lbz", 35: "lbzu", 36: "stw", 37: "stwu",
       38: "stb", 39: "stbu", 40: "lhz", 41: "lhzu", 42: "lha", 43: "lhau",
       44: "sth", 45: "sthu", 46: "lmw", 47: "stmw"}
FMEM = {48: "lfs", 49: "lfsu", 50: "lfd", 51: "lfdu", 52: "stfs", 53: "stfsu",
        54: "stfd", 55: "stfdu"}
A63 = {18: "fdiv", 20: "fsub", 21: "fadd", 23: "fsel", 25: "fmul", 26: "frsqrte",
       28: "fmsub", 29: "fmadd", 30: "fnmsub", 31: "fnmadd"}
X63 = {0: "fcmpu", 12: "frsp", 14: "fctiw", 15: "fctiwz", 32: "fcmpo", 38: "mtfsb1",
       40: "fneg", 64: "mcrfs", 70: "mtfsb0", 72: "fmr", 136: "fnabs", 264: "fabs",
       583: "mffs", 711: "mtfsf"}
A59 = {18: "fdivs", 20: "fsubs", 21: "fadds", 24: "fres", 25: "fmuls",
       28: "fmsubs", 29: "fmadds", 30: "fnmsubs", 31: "fnmadds"}
BO = {12: "t", 4: "f", 20: "", 16: "dnz", 18: "dz"}
CRB = ["lt", "gt", "eq", "so"]


def bcname(bo, bi):
    b = bo & 0x1E
    cr, bit = divmod(bi, 4)
    if b == 20: return "", ""
    if b == 16: return "dnz", ""
    if b in (12, 4):
        neg = {"lt": "ge", "gt": "le", "eq": "ne", "so": "ns"}
        c = CRB[bit] if b == 12 else neg[CRB[bit]]
        return c, ("cr%d," % cr if cr else "")
    return "c%d,%d" % (bo, bi), ""


def dis(w, pc):
    op = w >> 26
    rD = (w >> 21) & 31; rA = (w >> 16) & 31; rB = (w >> 11) & 31
    imm = w & 0xFFFF
    if w == 0x60000000: return "nop"
    if op == 14: return ("li %s,%d" % (R(rD), S16(imm))) if rA == 0 else "addi %s,%s,%d" % (R(rD), R(rA), S16(imm))
    if op == 15: return ("lis %s,0x%X" % (R(rD), imm)) if rA == 0 else "addis %s,%s,0x%X" % (R(rD), R(rA), imm)
    if op == 7: return "mulli %s,%s,%d" % (R(rD), R(rA), S16(imm))
    if op == 8: return "subfic %s,%s,%d" % (R(rD), R(rA), S16(imm))
    if op == 10: return "cmplwi cr%d,%s,%d" % (rD >> 2, R(rA), imm)
    if op == 11: return "cmpwi cr%d,%s,%d" % (rD >> 2, R(rA), S16(imm))
    if op == 12: return "addic %s,%s,%d" % (R(rD), R(rA), S16(imm))
    if op == 13: return "addic. %s,%s,%d" % (R(rD), R(rA), S16(imm))
    if op == 24: return ("mr %s,%s" % (R(rA), R(rD))) if 0 else "ori %s,%s,0x%X" % (R(rA), R(rD), imm)
    if op == 25: return "oris %s,%s,0x%X" % (R(rA), R(rD), imm)
    if op == 26: return "xori %s,%s,0x%X" % (R(rA), R(rD), imm)
    if op == 27: return "xoris %s,%s,0x%X" % (R(rA), R(rD), imm)
    if op == 28: return "andi. %s,%s,0x%X" % (R(rA), R(rD), imm)
    if op == 29: return "andis. %s,%s,0x%X" % (R(rA), R(rD), imm)
    if op in MEM: return "%s %s,%d(%s)" % (MEM[op], R(rD), S16(imm), R(rA))
    if op in FMEM: return "%s %s,%d(%s)" % (FMEM[op], F(rD), S16(imm), R(rA))
    if op == 18:
        li = w & 0x03FFFFFC
        if li & 0x02000000: li -= 0x04000000
        aa, lk = (w >> 1) & 1, w & 1
        dest = li if aa else pc + li
        return "b%s %s" % ("l" if lk else "", "codice+0x%X" % dest)
    if op == 16:
        bd = w & 0xFFFC
        if bd & 0x8000: bd -= 0x10000
        c, cr = bcname(rD, rA)
        return "b%s%s %scodice+0x%X" % (c, "l" if w & 1 else "", cr, pc + bd)
    if op == 19:
        xo = (w >> 1) & 0x3FF
        if xo == 16:
            c, cr = bcname(rD, rA)
            return "b%slr%s" % (c, "l" if w & 1 else "")
        if xo == 528:
            c, cr = bcname(rD, rA)
            return "b%sctr%s" % (c, "l" if w & 1 else "")
        if xo == 150: return "isync"
        if xo == 193: return "crxor %d,%d,%d" % (rD, rA, rB)
        if xo == 289: return "creqv %d,%d,%d" % (rD, rA, rB)
        if xo == 50: return "rfi"
        return "op19.%d" % xo
    if op in (20, 21, 23):
        sh, mb, me = rB, (w >> 6) & 31, (w >> 1) & 31
        n = {20: "rlwimi", 21: "rlwinm", 23: "rlwnm"}[op] + ("." if w & 1 else "")
        return "%s %s,%s,%s,%d,%d" % (n, R(rA), R(rD), R(rB) if op == 23 else sh, mb, me)
    if op == 31:
        xo = (w >> 1) & 0x3FF
        rc = "." if w & 1 else ""
        if xo == 444 and rD == rB: return "mr%s %s,%s" % (rc, R(rA), R(rD))
        if xo in (339, 467, 371):
            spr = ((w >> 16) & 31) | (((w >> 11) & 31) << 5)
            nm = SPR.get(spr, "spr%d" % spr)
            return ("mf%s %s" % (nm, R(rD))) if xo != 467 else "mt%s %s" % (nm, R(rD))
        if xo in (0, 32): return "%s cr%d,%s,%s" % (X31[xo], rD >> 2, R(rA), R(rB))
        if xo == 824: return "srawi%s %s,%s,%d" % (rc, R(rA), R(rD), rB)
        if xo in (26, 922, 954): return "%s%s %s,%s" % (X31[xo], rc, R(rA), R(rD))
        if xo in (28, 60, 124, 284, 316, 412, 444, 476, 24, 536, 792):
            return "%s%s %s,%s,%s" % (X31[xo], rc, R(rA), R(rD), R(rB))
        if xo in (104, 200, 202, 234): return "%s%s %s,%s" % (X31[xo], rc, R(rD), R(rA))
        if xo in (19, 83): return "%s %s" % (X31[xo], R(rD))
        if xo in X31: return "%s%s %s,%s,%s" % (X31[xo], rc, R(rD), R(rA), R(rB))
        xo9 = (w >> 1) & 0x1FF
        if xo9 in X31: return "%s%s %s,%s,%s" % (X31[xo9], rc, R(rD), R(rA), R(rB))
        return "op31.%d" % xo
    if op == 63:
        xo5 = (w >> 1) & 31
        xo = (w >> 1) & 0x3FF
        rC = (w >> 6) & 31
        if xo in X63:
            if xo in (0, 32): return "%s cr%d,%s,%s" % (X63[xo], rD >> 2, F(rA), F(rB))
            return "%s %s,%s" % (X63[xo], F(rD), F(rB))
        if xo5 in A63:
            if xo5 == 25: return "fmul %s,%s,%s" % (F(rD), F(rA), F(rC))
            if xo5 in (18, 20, 21): return "%s %s,%s,%s" % (A63[xo5], F(rD), F(rA), F(rB))
            return "%s %s,%s,%s,%s" % (A63[xo5], F(rD), F(rA), F(rC), F(rB))
        return "op63.%d" % xo
    if op == 59:
        xo5 = (w >> 1) & 31
        rC = (w >> 6) & 31
        if xo5 in A59:
            if xo5 == 25: return "fmuls %s,%s,%s" % (F(rD), F(rA), F(rC))
            if xo5 in (18, 20, 21): return "%s %s,%s,%s" % (A59[xo5], F(rD), F(rA), F(rB))
            if xo5 == 24: return "fres %s,%s" % (F(rD), F(rB))
            return "%s %s,%s,%s,%s" % (A59[xo5], F(rD), F(rA), F(rC), F(rB))
        return "op59.%d" % xo5
    if op in (56, 57, 60, 61):
        n = {56: "psq_l", 57: "psq_lu", 60: "psq_st", 61: "psq_stu"}[op]
        d = w & 0xFFF
        if d & 0x800: d -= 0x1000
        return "%s %s,%d(%s),%d,qr%d" % (n, F(rD), d, R(rA), (w >> 15) & 1, (w >> 12) & 7)
    if op == 4: return "ps_op 0x%08X" % w
    return ".word 0x%08X" % w


def reloc_at(k, off):
    """Rilocazione che tocca l'istruzione a `off`. Rel24 e Addr32 puntano
    all'inizio della parola; Addr16Lo/Hi/Ha alla mezza parola bassa, cioe'
    a off+2."""
    return k.reloc.get(off) or k.reloc.get(off + 2)


def annotate(k, off):
    w = k.word(off)
    text = dis(w, off)
    r = reloc_at(k, off)
    if r:
        t, target = r
        if t == 10:
            text = ("bl " if w & 1 else "b ") + tgt(target)
        else:
            text += "      ; %s -> %s" % (CMD[t], tgt(target))
    return text


def main():
    # il file da leggere: KMN_BIN, oppure il secondo argomento per info/hooks,
    # altrimenti quello installato sul Desktop
    import os
    default = os.environ.get("KMN_BIN", "CustomCode_USA.bin")
    k = Kamek(sys.argv[2] if len(sys.argv) > 2 and not sys.argv[1] in ("dis", "xref", "word")
              else default)
    a = sys.argv[1] if len(sys.argv) > 1 else "info"
    if a == "info":
        print("codice 0x%X byte, BSS 0x%X byte, costruttori 0x%X..0x%X" % (k.size, k.bss, k.ctor0, k.ctor1))
        print("comandi: %d" % len(k.cmds))
        from collections import Counter
        for t, n in sorted(Counter(c[1] for c in k.cmds).items()):
            print("  %-18s %d" % (CMD[t], n))
    elif a == "dis":
        s, e = int(sys.argv[2], 16), int(sys.argv[3], 16)
        for off in range(s & ~3, e, 4):
            print("  %05X  %08X  %s" % (off, k.word(off), annotate(k, off)))
    elif a == "xref":
        want = int(sys.argv[2], 16)
        for off, (t, target) in sorted(k.reloc.items()):
            if target == want:
                print("  %05X  %s" % (off, annotate(k, off)))
        for off in range(0, k.size, 4):
            w = k.word(off)
            if (w >> 26) == 18 and off not in k.reloc:
                li = w & 0x03FFFFFC
                if li & 0x02000000: li -= 0x04000000
                if off + li == want: print("  %05X  %s" % (off, annotate(k, off)))
        for pos, t, ad, ab, args in k.cmds:
            if ab and args and args[0] == want:
                print("  gioco %s <- %s" % (tgt(ad), CMD[t]))
    elif a == "word":
        want = int(sys.argv[2], 16)
        for off in range(0, k.size, 4):
            if k.word(off) == want:
                print("  %05X" % off)
    elif a == "hooks":
        for pos, t, ad, ab, args in k.cmds:
            if ab:
                print("  %-12s gioco 0x%08X  %s" % (CMD[t], ad, " ".join(tgt(x) if t not in (32, 33, 34, 36, 37, 38) else "0x%08X" % x for x in args)))


if __name__ == "__main__":
    main()
