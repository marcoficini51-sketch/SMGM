#!/usr/bin/env python3
"""Patch a mano di CustomCode_USA.bin (binario Kamek v2), senza ricompilare
il mod. Contiene tre cose:

1. PESI DELLA CAMMINATA. La camminata di Mario e' il gruppo "基本", che fonde 4
   tracce con pesi ricalcolati a ogni fotogramma. Il pacchetto trasportava
   solo il gruppo, quindi il pupazzo scivolava.
     T1  updatePackets+0x2DB8: copia i 4 pesi del proprio Mario in g_sendW
     T2  0x2E78 (chiamata a netWriteToBuffer): li scrive nei byte 56..71
     T3  ingresso di netReadFromBuffer (0xB78): li salva per id globale
     T4  calcAnim_ep+0x19D4: li scrive in playerXanimes[i].mWeights

2. FRIENDLY FIRE. Chi subisce decide guardando i flag dell'altro.
     S1  updatePackets+0x2DE8: bit 0x02 se si sta facendo la piroetta
     V1  receiveMsgPush 0x39A4: lo schianto manda ACTMES_ENEMY_ATTACK (vita)
     V2  receiveMsgPush 0x3994: la piroetta manda ACTMES_ENEMY_ATTACK_FLIP_ROT

3. STELLA CONDIVISA. Chi prende una stella lo dice agli altri; chi e' nella
   stessa galassia se la vede comparire addosso e la prende anche lui.
     PS_recv   messa nella vtable di PowerStar al posto di receiveOtherMsg:
               se AUTORUSH_BEGIN va a buon fine (stella presa) salva numero,
               impronta della galassia e "da trasmettere per 300 pacchetti"
     T2        byte 72..75 del pacchetto: [numero, 0, impronta a 16 bit]
     T3        con un pacchetto da 76 byte annota l'evento per quel giocatore
     StarTick  chiamata da S1 a ogni fotogramma. La prima volta cerca la vtable
               di PowerStar (non e' nella mappa USA) per doppia firma:
               receiveOtherMsg e init di PowerStar nella stessa vtable. Poi,
               per ogni evento nuovo della propria galassia: la stella della
               propria scena con quel numero compare senza filmato e viene
               spostata sulla posizione del proprio Mario, che la prende.
     K         implementationSize 56 -> 76

   La trasmissione si ferma durante il filmato della stella (misurato con
   Sniff: ~6 secondi di silenzio dal tocco): per questo l'evento si conserva
   e parte quando la trasmissione riprende, con l'impronta della galassia in
   cui la stella e' stata presa.

Compatibilita': il controllo di lunghezza in lettura resta 56, quindi versioni
vecchie e nuove si capiscono. Il server inoltra la lunghezza ricevuta.

Il codice nuovo va DOPO il BSS: il BSS diventa parte del codice (zeri nel
file) e la sua dimensione va a zero, cosi' non slitta.
"""
import struct, sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from kmn import Kamek, CODE_OFF
from ppcasm import Asm

SRC = sys.argv[1] if len(sys.argv) > 1 else "/mnt/c/smgbuild/pesi/CustomCode_USA.orig.bin"
DST = sys.argv[2] if len(sys.argv) > 2 else "/mnt/c/smgbuild/pesi/CustomCode_USA.bin"

OLD_SIZE, NEW_SIZE = 56, 124     # 124 + 4 di etichetta = 128, il massimo

# (offset, parola originale attesa, descrizione)
SITES = {
    "T1": (0x2DB8, 0x80650020, "lwz r3,32(r5)          updatePackets: legge xanime->_20"),
    "T2": (0x2E78, 0x4BFFDC35, "bl codice+0xAAC        updatePackets: netWriteToBuffer"),
    "T3": (0x0B78, 0x9421FFE0, "stwu r1,-32(r1)        ingresso di netReadFromBuffer"),
    # NON 0x19D8: li' arrivano anche i giocatori inattivi (beq a 0x15BC), con
    # r22 ancora da impostare. 0x19D4 e' l'ultima istruzione del percorso dei
    # soli giocatori attivi, dove r22 e' sicuramente la posizione ricevuta.
    "T4": (0x19D4, 0xD003000C, "stfs f0,12(r3)         calcAnim_ep: xanime->_20->mRate"),
    "S1": (0x2DE8, 0x3BBF0000, "addi r29,r31,0         updatePackets: dopo i flag dello schianto"),
    # nemici: all'avvio, subito dopo DrawSyncManager::start in initWrapper
    "B0": (0x2884, 0x881E0338, "lbz r0,824(r30)        initWrapper: inizio di init() del mod"),
    "V1": (0x39A4, 0x3880004F, "li r4,0x4F             receiveMsgPush: messaggio dello schianto"),
    "V2": (0x3994, 0x540007FF, "rlwinm. r0,r0,0,31,31  receiveMsgPush: test del bit dello schianto"),
}
NEW_V1 = 0x38800053          # li r4,0x53: ACTMES_ENEMY_ATTACK, il colpo che toglie vita

# Piroetta: MarioActor::_946 (u16) = mSpinIntervalTime + 0x22 = 79 all'avvio,
# poi scende di uno a fotogramma; sopra 45 si sta girando.
SPIN_TIMER, SPIN_ACTIVE_ABOVE = 0x946, 45
RECEIVE_MSG = 0x80163760     # HitSensor::receiveMessage(u32, HitSensor*)
MSG_SPIN_HIT = 0x51          # ACTMES_ENEMY_ATTACK_FLIP_ROT
FLAG_HIPDROP, FLAG_SPIN = 0x01, 0x02
SPIN_COOLDOWN = 60

# Stella condivisa: funzioni del gioco (mappa USA di Bussun)
PS_RECV_ORIG = 0x8020F628    # PowerStar::receiveOtherMsg
PS_INIT = 0x8020EBD4         # PowerStar::init, seconda firma della vtable
GET_STAGE_NAME = 0x803F5AB8  # MR::getCurrentStageName
GET_PS_HOLDER = 0x80299EFC   # EventFunction::getPowerStarHolder
FIND_PS_INFO = 0x802110CC    # PowerStarHolder::findPowerStarRequestInfo(int) const
APPEAR_PS = 0x80211030       # PowerStarHolder::appearPowerStarWithoutDemo(int)
GET_PLAYER_POS = 0x803F1F34  # MR::getPlayerPos
MSG_AUTORUSH_BEGIN = 0x92
VTE_RECV, VTE_INIT = 0x74, 0x0C          # voci della vtable di LiveActor
OFF_STAR_ID, OFF_POS, OFF_INITPOS = 0x8C, 0x0C, 0xAC
VT_SCAN_LO, VT_SCAN_HI = 0x80560000, 0x805D0000
STAR_SEND = 300              # pacchetti con l'evento: ~5 s di trasmissione

# Nemici: init di 46 classi (mappa USA; le vtable NON dalla mappa, si cercano
# a runtime per firma). kill si legge dalla vtable, spesso e' ereditato.
EN_INITS = [0x800EF600, 0x800F3264, 0x800F55BC, 0x800F81D4, 0x800FB0BC, 0x800FC3C8, 0x800FD2F0, 0x800FDDEC, 0x801001A0, 0x80100AD8, 0x80102050, 0x80103A54, 0x80107AF8, 0x8010859C, 0x8010AEB4, 0x8010E1EC, 0x8010FEAC, 0x8013F324, 0x801423E4, 0x80146760, 0x80144E54, 0x801493B0, 0x8014C398, 0x8014CE1C, 0x80151910, 0x800CD9AC, 0x800CFD84, 0x800D4F1C, 0x800DD204, 0x800E5560, 0x800E6F6C, 0x800EC87C, 0x801120C4, 0x80117A80, 0x80119EBC, 0x8011B290, 0x8011E720, 0x801229A0, 0x80124888, 0x801261E8, 0x8012FDA8, 0x8013161C, 0x80136E60, 0x8013A030, 0x8013D5A4, 0x80140B54]
EN_SCAN_LO, EN_SCAN_HI = 0x80530000, 0x805F0000
VI_RETRACE = 0x804B38F0      # VIGetRetraceCount: fotogrammi video dall'avvio
EN_VT_MAX, EN_TR_MAX = 96, 256
EN_SEND = 20                 # pacchetti per annuncio di morte
EN_GAP = 30                  # fotogrammi senza gioco = caricamento di una scena
PK_ALIVE = 60                # un giocatore non sentito da piu' di cosi' non comanda
PK_HOLD = 180                # per quanto si tiene un nemico sull'ultima posizione ricevuta
SET_NERVE = 0x80165824       # LiveActor::setNerve(const Nerve*)
GET_SENSOR_IDX = 0x803C2648  # MR::getSensorWithIndex(LiveActor*, int)
GET_BODY_SENSOR = 0x803DF840 # MR::getBodySensor(LiveActor*)
GET_PLAYER_ACTOR = 0x80304204  # MarioAccess::getPlayerActor()
EN_PAUSE = 120               # fotogrammi in cui chi ha colpito un nemico lo muove da se'
SET_PLAYER_POS = 0x803F1F80  # MR::setPlayerPos(const TVec3f&)
FLAG_TP = 0x04               # nei flag: "venite tutti da me" (lo mette il server)
TP_COOL = 180                # dopo un teletrasporto, 3 secondi senza altri
IS_DEMO_ACTIVE = 0x803C9E84  # MR::isDemoActive()
NRV_LO, NRV_HI = 0x80400000, 0x80700000   # dove stanno le nerve e le loro vtable
CODE_HI = 0x80530000         # fine del codice del gioco
# boss: BossBegoman, BossKameck, BossStinkBug, DinoPackun, Koopa, Polta,
# SkeletalFishBoss, TombSpider, TripodBoss, OtaKing
EN_INITS += [0x80033D98, 0x80037988, 0x8003BD9C, 0x800431E0, 0x800585E4, 0x8006E460,
             0x80077568, 0x8007EE80, 0x80085FBC, 0x80069C6C]

ALLOW_CALLS = {"T3"}
ALLOW_FROM = {
    # 0x2DAC e' il ramo "defaultAnmIdx valido" che scavalca il li r0,-1: su
    # entrambe le strade r5 e' l'XanimePlayer caricato a 0x2D48.
    "T1": {0x2DAC},
    # 0x2DD8 e' il "non sta facendo lo schianto": entrambe le strade arrivano
    # subito dopo le chiamate isPlayerHipDrop*, nessun volatile vivo.
    "S1": {0x2DD8},
}
K_SIZE = (0x5680, OLD_SIZE)
NET_WRITE = 0xAAC


def main():
    k = Kamek(SRC)
    code = bytearray(k.code)

    # ------------------------------------------------ controlli sull'originale
    def word(off): return struct.unpack(">I", code[off:off+4])[0]
    for name, (off, want, what) in SITES.items():
        got = word(off)
        if got != want:
            raise SystemExit("%s: a 0x%X c'e' 0x%08X, mi aspettavo 0x%08X (%s)" % (name, off, got, want, what))
        if off in k.reloc or off + 2 in k.reloc:
            raise SystemExit("%s: a 0x%X c'e' una rilocazione, non posso sovrascriverla" % (name, off))
    if word(K_SIZE[0]) != K_SIZE[1]:
        raise SystemExit("implementationSize: a 0x%X c'e' %d, mi aspettavo %d" % (K_SIZE[0], word(K_SIZE[0]), K_SIZE[1]))
    if k.bss % 4:
        raise SystemExit("BSS non allineato a 4: 0x%X" % k.bss)

    # Nessun salto (neanche condizionato) deve atterrare su un'istruzione che
    # sostituisco, salvo eccezioni verificate e motivate in ALLOW_FROM.
    incoming = {name: [] for name in SITES}
    for off in range(0, k.size, 4):
        if off in k.reloc: continue
        w = word(off); op = w >> 26
        if op == 18:
            d = w & 0x03FFFFFC
            if d & 0x02000000: d -= 0x04000000
        elif op == 16:
            d = w & 0xFFFC
            if d & 0x8000: d -= 0x10000
        else:
            continue
        dest, link = off + d, bool(w & 1)
        for name, (site, _, _) in SITES.items():
            if dest == site and not (link and name in ALLOW_CALLS) \
                    and off not in ALLOW_FROM.get(name, ()):
                incoming[name].append(off)
    for name, froms in incoming.items():
        if froms:
            raise SystemExit("%s: a 0x%X arrivano salti da %s: il punto non e' sicuro"
                             % (name, SITES[name][0], ", ".join("0x%X" % f for f in froms)))
    print("originale: tutti gli agganci e la costante sono quelli attesi, e nessun salto ci atterra")

    # playerXanimes: a 0x19C4 il codice originale lo legge con "lwz r0,lo(r31)",
    # r31 = SOLO la meta' alta. Prendo il bersaglio dalla rilocazione originale.
    lo = k.reloc.get(0x19C4 + 2)
    if not lo or lo[0] != 4:
        raise SystemExit("a 0x19C4 mi aspettavo una Addr16Lo verso playerXanimes, trovo %r" % (lo,))
    pxv = lo[1]
    ha, lo2 = k.reloc.get(0x39B0 + 2), k.reloc.get(0x39B4 + 2)
    if not ha or not lo2 or ha[0] != 6 or lo2[0] != 4 or ha[1] != lo2[1]:
        raise SystemExit("a 0x39B0 mi aspettavo lis/addi verso jumpCooldown, trovo %r %r" % (ha, lo2))
    jump_cooldown = ha[1]

    # ------------------------------------------------ codice nuovo, dopo il BSS
    base = k.size + k.bss
    a = Asm(base)
    a.labels["g_pxv"] = pxv
    a.labels["g_jc"] = jump_cooldown
    ret = lambda name: "@0x%X" % (SITES[name][0] + 4)

    # --------------------------------------------------------------- T1
    a("""
    T1:                         ; r5 = XanimePlayer di Mario; liberi r0 r4
        lis  r4,g_sendW@ha
        addi r4,r4,g_sendW@l
        lwz  r0,16(r5)
        stw  r0,0(r4)
        lwz  r0,20(r5)
        stw  r0,4(r4)
        lwz  r0,24(r5)
        stw  r0,8(r4)
        lwz  r0,28(r5)
        stw  r0,12(r4)
    """)
    a.word(SITES["T1"][1])
    a("b %s" % ret("T1"))

    # --------------------------------------------------------------- T2
    # r3 = pos, r4 = buffer, r5 = len (76): da preservare. Liberi r0 r6 r7.
    # NB: mai "addi rX,r0,..": con r0 come sorgente vale zero.
    a("""
    T2:
        lis  r6,g_sendW@ha
        addi r6,r6,g_sendW@l
        lwz  r0,0(r6)
        stw  r0,56(r4)
        lwz  r0,4(r6)
        stw  r0,60(r4)
        lwz  r0,8(r6)
        stw  r0,64(r4)
        lwz  r0,12(r6)
        stw  r0,68(r4)
        lis  r6,g_star@ha
        addi r6,r6,g_star@l
        lhz  r7,4(r6)           ; pacchetti ancora da mandare con l'evento
        cmpwi r7,0
        beq  T2_senza
        addi r7,r7,-1
        sth  r7,4(r6)
        lwz  r0,0(r6)           ; [numero, 0, impronta] come sul filo
        stw  r0,72(r4)
        b    T2_via
    T2_senza:
        li   r0,0
        stw  r0,72(r4)
    T2_via:
        lbz  r0,6(r6)           ; spia: 0 mai cercata, 1 non trovata, 2 agganciata
        stb  r0,73(r4)
        lis  r6,g_diag@ha       ; diagnosi: esaminata, esito, ricevuta, giri
        addi r6,r6,g_diag@l
        lwz  r0,0(r6)
        stw  r0,76(r4)
        lis  r6,g_en_tx@ha      ; nemici: +0 annuncio, +8 sequenza, +10 da mandare, +12 rd, +13 wr, +16 coda
        addi r6,r6,g_en_tx@l
        lhz  r7,10(r6)
        cmpwi r7,0
        bne  T2_en_manda
        lbz  r7,12(r6)
        lbz  r8,13(r6)
        cmpw r7,r8
        beq  T2_en_niente       ; coda vuota
        mulli r8,r7,12
        add  r8,r8,r6
        lwz  r0,16(r8)
        stw  r0,0(r6)
        lwz  r0,20(r8)
        stw  r0,4(r6)
        lhz  r0,24(r8)          ; [tipo, sensore]: tipo 0 = morte, altrimenti il colpo
        sth  r0,14(r6)
        addi r7,r7,1
        andi. r7,r7,7
        stb  r7,12(r6)
        lhz  r7,8(r6)           ; sequenza: mai 0
        addi r7,r7,1
        andi. r7,r7,0xFFFF
        bne  T2_en_seq
        li   r7,1
    T2_en_seq:
        sth  r7,8(r6)
        li   r7,%d
    T2_en_manda:
        addi r7,r7,-1
        sth  r7,10(r6)
        lwz  r0,0(r6)
        stw  r0,80(r4)
        lwz  r0,4(r6)
        stw  r0,84(r4)
        lhz  r0,8(r6)
        sth  r0,88(r4)
        lhz  r0,14(r6)
        sth  r0,90(r4)
        b    T2_en_diag
    T2_en_niente:
        li   r0,0
        stw  r0,80(r4)
        stw  r0,84(r4)
        stw  r0,88(r4)
    T2_en_diag:
        lis  r6,g_pk@ha         ; posizioni dei nemici: +0 io, +1 chi comanda, +2 galassia
        addi r6,r6,g_pk@l
        lbz  r0,0(r3)           ; il mio id globale, primo byte della posizione
        stb  r0,0(r6)
        lis  r7,g_demo@ha
        addi r7,r7,g_demo@l
        lbz  r0,1(r7)
        stb  r0,76(r4)          ; quante cutscene ho visto in questa galassia
        lis  r7,g_en_st@ha
        addi r7,r7,g_en_st@l
        lbz  r0,5(r7)
        stb  r0,77(r4)          ; diagnosi: esito dell'ultimo evento nemico ricevuto
        lhz  r0,2(r6)
        sth  r0,78(r4)          ; la mia galassia
        lis  r6,g_pk_tx@ha      ; 2 nemici: [chiave, x, y, z], preparati da PosTick
        addi r6,r6,g_pk_tx@l
        lwz  r0,0(r6)
        stw  r0,92(r4)
        lwz  r0,4(r6)
        stw  r0,96(r4)
        lwz  r0,8(r6)
        stw  r0,100(r4)
        lwz  r0,12(r6)
        stw  r0,104(r4)
        lwz  r0,16(r6)
        stw  r0,108(r4)
        lwz  r0,20(r6)
        stw  r0,112(r4)
        lwz  r0,24(r6)
        stw  r0,116(r4)
        lwz  r0,28(r6)
        stw  r0,120(r4)
    """ % EN_SEND)
    a("b @0x%X" % NET_WRITE)                       # LR punta ancora a 0x2E7C

    # --------------------------------------------------------------- T3
    a("""
    T3:                         ; r3 = out, r4 = buff, r5 = len; liberi r0 r6 r7 r8
        lbz    r6,0(r4)         ; id globale del mittente
        cmplwi r6,8
        bge    T3_fine
        lbz    r0,1(r4)         ; flag: teletrasporto verso questo giocatore?
        andi.  r0,r0,%d
        beq    T3_tp_no
        lis    r7,g_tp@ha
        addi   r7,r7,g_tp@l
        lbz    r0,0(r7)
        cmpwi  r0,0
        bne    T3_tp_no
        lwz    r0,8(r4)         ; la sua posizione
        stw    r0,4(r7)
        lwz    r0,12(r4)
        stw    r0,8(r7)
        lwz    r0,16(r4)
        stw    r0,12(r7)
        li     r0,0
        cmplwi r5,%d
        blt    T3_tp_st
        lhz    r0,78(r4)        ; la sua galassia
    T3_tp_st:
        sth    r0,2(r7)
        stb    r6,1(r7)
        li     r0,1
        stb    r0,0(r7)
    T3_tp_no:
        lis    r7,g_valid@ha
        addi   r7,r7,g_valid@l
        cmplwi r5,72
        blt    T3_senza
        li     r0,1
        stbx   r0,r7,r6
        lis    r7,g_recvW@ha
        addi   r7,r7,g_recvW@l
        slwi   r8,r6,4
        add    r7,r7,r8
        lwz    r0,56(r4)
        stw    r0,0(r7)
        lwz    r0,60(r4)
        stw    r0,4(r7)
        lwz    r0,64(r4)
        stw    r0,8(r7)
        lwz    r0,68(r4)
        stw    r0,12(r7)
        b      T3_stella
    T3_senza:
        li     r0,0
        stbx   r0,r7,r6
    T3_stella:
        lis    r7,g_rx@ha       ; +0 numero[8], +8 impronta[8] (u16), +24 servito[8]
        addi   r7,r7,g_rx@l
        li     r0,0
        cmplwi r5,76
        blt    T3_numero
        lbz    r0,72(r4)
    T3_numero:
        stbx   r0,r7,r6
        cmpwi  r0,0
        bne    T3_impronta
        addi   r8,r7,24
        stbx   r0,r8,r6         ; evento finito: la prossima volta si serve di nuovo
        b      T3_nemici
    T3_impronta:
        lis    r8,g_diag@ha
        addi   r8,r8,g_diag@l
        stb    r0,2(r8)         ; diagnosi: ultima stella ricevuta
        lhz    r0,74(r4)
        slwi   r8,r6,1
        add    r8,r8,r7
        sth    r0,8(r8)
    T3_nemici:
        cmplwi r5,92
        blt    T3_fine
        lis    r7,g_en_rx@ha    ; annuncio di morte di questo giocatore (12 byte)
        addi   r7,r7,g_en_rx@l
        mulli  r8,r6,12
        add    r7,r7,r8
        lwz    r0,80(r4)
        stw    r0,0(r7)
        lwz    r0,84(r4)
        stw    r0,4(r7)
        lwz    r0,88(r4)
        stw    r0,8(r7)
        cmplwi r5,%d
        blt    T3_fine
        lis    r7,g_pk_seen@ha  ; ultimo fotogramma in cui l'ho sentito
        addi   r7,r7,g_pk_seen@l
        slwi   r8,r6,2
        add    r7,r7,r8
        lis    r8,g_en_st@ha
        lwz    r0,g_en_st@l(r8)
        stw    r0,0(r7)
        lis    r7,g_pk_stage@ha ; la sua galassia
        addi   r7,r7,g_pk_stage@l
        slwi   r8,r6,1
        add    r7,r7,r8
        lhz    r0,78(r4)
        sth    r0,0(r7)
        lis    r7,g_pk_demo@ha  ; le sue cutscene
        addi   r7,r7,g_pk_demo@l
        lbz    r0,76(r4)
        stbx   r0,r7,r6
        lis    r7,g_pk_rx@ha    ; i suoi 2 nemici
        addi   r7,r7,g_pk_rx@l
        slwi   r8,r6,5
        add    r7,r7,r8
        lwz    r0,92(r4)
        stw    r0,0(r7)
        lwz    r0,96(r4)
        stw    r0,4(r7)
        lwz    r0,100(r4)
        stw    r0,8(r7)
        lwz    r0,104(r4)
        stw    r0,12(r7)
        lwz    r0,108(r4)
        stw    r0,16(r7)
        lwz    r0,112(r4)
        stw    r0,20(r7)
        lwz    r0,116(r4)
        stw    r0,24(r7)
        lwz    r0,120(r4)
        stw    r0,28(r7)
        lis    r7,g_pk_new@ha
        addi   r7,r7,g_pk_new@l
        li     r0,1
        stbx   r0,r7,r6
    T3_fine:
    """ % (FLAG_TP, NEW_SIZE, NEW_SIZE))
    a.word(SITES["T3"][1])
    a("b %s" % ret("T3"))

    # --------------------------------------------------------------- T4
    a("T4:")
    a.word(SITES["T4"][1])                         # stfs f0,12(r3), spostata
    a("""
                                ; solo giocatori attivi: r22 = posizione,
                                ; r19 = i*140; liberi r0 r3 r4 r5
        lbz    r3,0(r22)
        cmplwi r3,8
        bge    T4_fine
        lis    r4,g_valid@ha
        addi   r4,r4,g_valid@l
        lbzx   r0,r4,r3
        cmpwi  r0,0
        beq    T4_fine
        lis    r4,g_recvW@ha
        addi   r4,r4,g_recvW@l
        slwi   r3,r3,4
        add    r4,r4,r3
        lis    r5,g_pxv@ha
        lwz    r5,g_pxv@l(r5)
        add    r5,r5,r19
        lwz    r0,0(r4)
        stw    r0,16(r5)
        lwz    r0,4(r4)
        stw    r0,20(r5)
        lwz    r0,8(r4)
        stw    r0,24(r5)
        lwz    r0,12(r4)
        stw    r0,28(r5)
    T4_fine:
    """)
    a("b %s" % ret("T4"))

    # --------------------------------------------------------------- S1
    a("""
    S1:                         ; dopo i flag dello schianto; r29 = MarioActor
        bl     StarTick         ; stella condivisa (preserva r29 e la pila)
        bl     EnemyTick        ; nemici uccisi dagli altri
        bl     PosTick          ; posizioni dei nemici da chi comanda
        lhz    r0,0x%X(r29)     ; MarioActor::_946, contatore della piroetta
        cmplwi r0,%d
        ble    S1_fine
        lbz    r0,152(r1)       ; pos.stateFlags
        ori    r0,r0,%d
        stb    r0,152(r1)
    S1_fine:
    """ % (SPIN_TIMER, SPIN_ACTIVE_ABOVE, FLAG_SPIN))
    a.word(SITES["S1"][1])
    a("b %s" % ret("S1"))

    # --------------------------------------------------------------- V2
    a("""
    V2:                         ; r0 = flag dell'altro, r3 = sua posizione,
                                ; r27 = indice, r30 = sensore di Mario, r31 = del pupazzo
        andi.  r0,r0,%d
        bne    V2_schianto
        lbz    r0,60(r3)
        andi.  r0,r0,%d
        beq    V2_niente
        lis    r6,g_jc@ha
        addi   r6,r6,g_jc@l
        lbzx   r0,r6,r27
        cmpwi  r0,0
        bne    V2_spinta
        li     r0,%d
        stbx   r0,r6,r27
        mr     r3,r30
        li     r4,%d
        mr     r5,r31
        bl     0x%X             ; HitSensor::receiveMessage
        b      @0x3A10
    V2_spinta:
        b      @0x3A00
    V2_schianto:
        b      @0x399C
    V2_niente:
        b      @0x39B0
    """ % (FLAG_HIPDROP, FLAG_SPIN, SPIN_COOLDOWN, MSG_SPIN_HIT, RECEIVE_MSG))

    # --------------------------------------------------------------- StageHash
    # r3 = impronta a 16 bit del nome della galassia (h = h*31 + c)
    a("""
    StageHash:
        stwu   r1,-16(r1)
        mflr   r0
        stw    r0,20(r1)
        bl     0x%X             ; MR::getCurrentStageName
        li     r4,0
        cmpwi  r3,0
        beq    SH_fine
    SH_ciclo:
        lbz    r0,0(r3)
        cmpwi  r0,0
        beq    SH_fine
        mulli  r4,r4,31
        add    r4,r4,r0
        addi   r3,r3,1
        b      SH_ciclo
    SH_fine:
        andi.  r3,r4,0xFFFF
        cmplwi r3,0xFFFF        ; 0xFFFF e' il jolly: una galassia vera non lo usa
        bne    SH_esci
        li     r3,1
    SH_esci:
        lwz    r0,20(r1)
        mtlr   r0
        addi   r1,r1,16
        blr
    """ % GET_STAGE_NAME)

    # --------------------------------------------------------------- PS_recv
    # Stessa firma di PowerStar::receiveOtherMsg(this, msg, sender, receiver).
    a("""
    PS_recv:
        stwu   r1,-32(r1)
        mflr   r0
        stw    r0,36(r1)
        stw    r31,28(r1)
        stw    r30,24(r1)
        stw    r29,20(r1)
        mr     r31,r3           ; la stella
        mr     r30,r4           ; il messaggio
        bl     0x%X             ; l'originale, con gli stessi argomenti
        mr     r29,r3
        cmpwi  r29,0
        beq    PS_fine          ; niente di fatto
        cmplwi r30,0x%X         ; ACTMES_AUTORUSH_BEGIN: la stella e' stata presa
        bne    PS_fine
        lwz    r0,0x%X(r31)     ; mPowerStarId
        cmpwi  r0,1
        blt    PS_fine
        cmpwi  r0,255
        bgt    PS_fine
        lis    r4,g_star@ha
        addi   r4,r4,g_star@l
        stb    r0,0(r4)
        bl     StageHash
        lis    r4,g_star@ha
        addi   r4,r4,g_star@l
        sth    r3,2(r4)
        li     r0,%d
        sth    r0,4(r4)
    PS_fine:
        mr     r3,r29
        lwz    r29,20(r1)
        lwz    r30,24(r1)
        lwz    r31,28(r1)
        lwz    r0,36(r1)
        mtlr   r0
        addi   r1,r1,32
        blr
    """ % (PS_RECV_ORIG, MSG_AUTORUSH_BEGIN, OFF_STAR_ID, STAR_SEND))

    # --------------------------------------------------------------- StarTick
    a("""
    StarTick:
        stwu   r1,-48(r1)
        mflr   r0
        stw    r0,52(r1)
        stw    r31,44(r1)
        stw    r30,40(r1)
        stw    r29,36(r1)
        stw    r28,32(r1)
        stw    r27,28(r1)
        stw    r26,24(r1)
        lis    r4,g_diag@ha
        addi   r4,r4,g_diag@l
        lbz    r3,3(r4)
        addi   r3,r3,1
        stb    r3,3(r4)         ; diagnosi: giri di StarTick
        lis    r31,g_star@ha
        addi   r31,r31,g_star@l

        ; 1. la vtable di PowerStar, una volta sola
        lbz    r0,6(r31)
        cmpwi  r0,0
        bne    ST_rx
        li     r0,1
        stb    r0,6(r31)        ; 1 = cercata; 2 = trovata e agganciata
        lis    r3,0x%X
        lis    r4,0x%X
        lis    r5,0x%X
        ori    r5,r5,0x%X       ; PowerStar::receiveOtherMsg
        lis    r6,0x%X
        ori    r6,r6,0x%X       ; PowerStar::init
        lis    r7,PS_recv@ha
        addi   r7,r7,PS_recv@l
    ST_cerca:
        lwz    r0,0(r3)
        cmplw  r0,r5
        bne    ST_avanti
        lwz    r0,%d(r3)        ; stessa vtable, voce init
        cmplw  r0,r6
        bne    ST_avanti
        stw    r7,0(r3)
        li     r0,2
        stb    r0,6(r31)
    ST_avanti:
        addi   r3,r3,4
        cmplw  r3,r4
        blt    ST_cerca

    ST_rx:
        ; 2. se ho appena preso io una stella, quelle degli altri le ignoro
        lhz    r0,4(r31)
        cmpwi  r0,0
        bne    ST_fine
        bl     StageHash
        mr     r30,r3
        lis    r29,g_rx@ha
        addi   r29,r29,g_rx@l
        li     r28,0
    ST_ciclo:
        lbzx   r27,r29,r28      ; numero della stella annunciata da quel giocatore
        cmpwi  r27,0
        beq    ST_prossimo
        addi   r3,r29,24
        lbzx   r0,r3,r28
        cmpw   r0,r27
        beq    ST_prossimo      ; gia' servito
        slwi   r3,r28,1
        add    r3,r3,r29
        lhz    r0,8(r3)
        cmpw   r0,r30
        beq    ST_galassia
        cmplwi r0,0xFFFF        ; jolly: vale in qualsiasi galassia (tasto del pannello)
        bne    ST_e1            ; un'altra galassia
    ST_galassia:
        addi   r3,r29,24
        stbx   r27,r3,r28       ; una volta sola per evento, comunque vada
        bl     0x%X             ; EventFunction::getPowerStarHolder
        mr     r26,r3
        cmpwi  r26,0
        beq    ST_e2
        mr     r4,r27
        bl     0x%X             ; findPowerStarRequestInfo(numero)
        cmpwi  r3,0
        beq    ST_e3            ; quella stella in questa scena non c'e'
        lwz    r0,0(r3)         ; info->mStar
        cmpwi  r0,0
        beq    ST_e4
        stw    r0,8(r1)
        mr     r3,r26
        mr     r4,r27
        bl     0x%X             ; appearPowerStarWithoutDemo: stato Wait, prendibile
        bl     0x%X             ; MR::getPlayerPos
        lwz    r4,8(r1)
        lwz    r0,0(r3)
        stw    r0,0x%X(r4)
        stw    r0,0x%X(r4)
        lwz    r0,4(r3)
        stw    r0,0x%X(r4)
        stw    r0,0x%X(r4)
        lwz    r0,8(r3)
        stw    r0,0x%X(r4)
        stw    r0,0x%X(r4)
        li     r3,5             ; esito: comparsa e spostata addosso a me
        b      ST_scrivi
    ST_e1:
        li     r3,1             ; esito: altra galassia
        b      ST_scrivi
    ST_e2:
        li     r3,2             ; esito: niente PowerStarHolder
        b      ST_scrivi
    ST_e3:
        li     r3,3             ; esito: stella non presente nella scena
        b      ST_scrivi
    ST_e4:
        li     r3,4             ; esito: stella vuota
    ST_scrivi:
        lis    r4,g_diag@ha
        addi   r4,r4,g_diag@l
        stb    r27,0(r4)
        stb    r3,1(r4)
    ST_prossimo:
        addi   r28,r28,1
        cmpwi  r28,8
        blt    ST_ciclo

    ST_fine:
        lwz    r26,24(r1)
        lwz    r27,28(r1)
        lwz    r28,32(r1)
        lwz    r29,36(r1)
        lwz    r30,40(r1)
        lwz    r31,44(r1)
        lwz    r0,52(r1)
        mtlr   r0
        addi   r1,r1,48
        blr
    """ % (VT_SCAN_LO >> 16, VT_SCAN_HI >> 16,
           PS_RECV_ORIG >> 16, PS_RECV_ORIG & 0xFFFF,
           PS_INIT >> 16, PS_INIT & 0xFFFF,
           VTE_INIT - VTE_RECV,
           GET_PS_HOLDER, FIND_PS_INFO, APPEAR_PS, GET_PLAYER_POS,
           OFF_POS, OFF_INITPOS, OFF_POS + 4, OFF_INITPOS + 4, OFF_POS + 8, OFF_INITPOS + 8))

    # --------------------------------------------------------------- dati
    # =============================================================== nemici
    a("EnBoot:")
    a("bl EnemyInstall")
    a.word(SITES["B0"][1])                         # lbz r0,824(r30), spostata
    a("b %s" % ret("B0"))

    # StrHash(r3 = stringa) -> r3 = h*31+c a 16 bit. Foglia: usa r0 r3 r4.
    a("""
    StrHash:
        li     r4,0
        cmpwi  r3,0
        beq    SX_fine
    SX_ciclo:
        lbz    r0,0(r3)
        cmpwi  r0,0
        beq    SX_fine
        mulli  r4,r4,31
        add    r4,r4,r0
        addi   r3,r3,1
        b      SX_ciclo
    SX_fine:
        andi.  r3,r4,0xFFFF
        blr
    """)

    # EnFindVt(r3 = attore) -> r3 = voce [vtable, init, kill] o 0. Foglia.
    a("""
    EnFindVt:
        lwz    r0,0(r3)
        lis    r4,g_en_vt@ha
        addi   r4,r4,g_en_vt@l
        lis    r5,g_en_vtN@ha
        lwz    r5,g_en_vtN@l(r5)
    EFV_ciclo:
        cmpwi  r5,0
        beq    EFV_no
        lwz    r6,0(r4)
        cmplw  r6,r0
        beq    EFV_si
        addi   r4,r4,20
        addi   r5,r5,-1
        b      EFV_ciclo
    EFV_si:
        mr     r3,r4
        blr
    EFV_no:
        li     r3,0
        blr
    """)

    # EnemyInstall: all'avvio, prima di qualsiasi scena. Dove una voce 0x0C
    # contiene l'init di uno dei nemici e le voci 0x08 e 0x2C sono indirizzi
    # di codice, e' la vtable di quella classe (o di una sua sottoclasse).
    init_min, init_max = min(EN_INITS), max(EN_INITS)
    a("""
    EnemyInstall:
        stwu   r1,-32(r1)
        mflr   r0
        stw    r0,36(r1)
        stw    r31,28(r1)
        stw    r30,24(r1)
        lis    r3,0x%X
        lis    r4,0x%X
        lis    r5,0x%X
        ori    r5,r5,0x%X
        lis    r6,0x%X
        ori    r6,r6,0x%X
        lis    r31,g_en_vtN@ha
        addi   r31,r31,g_en_vtN@l
        lis    r30,g_en_vt@ha
        addi   r30,r30,g_en_vt@l
    EI_cerca:
        lwz    r0,0(r3)
        cmplw  r0,r5
        blt    EI_avanti
        cmplw  r0,r6
        bgt    EI_avanti
        lis    r7,g_en_inits@ha
        addi   r7,r7,g_en_inits@l
    EI_lista:
        lwz    r8,0(r7)
        cmpwi  r8,0
        beq    EI_avanti
        cmplw  r8,r0
        beq    EI_trovato
        addi   r7,r7,4
        b      EI_lista
    EI_trovato:
        lis    r9,0x8000
        ori    r9,r9,0x4000
        lis    r10,0x8060
        lwz    r8,-4(r3)        ; voce 0x08
        cmplw  r8,r9
        blt    EI_avanti
        cmplw  r8,r10
        bge    EI_avanti
        lwz    r8,0x20(r3)      ; voce 0x2C: kill
        cmplw  r8,r9
        blt    EI_avanti
        cmplw  r8,r10
        bge    EI_avanti
        lwz    r9,0(r31)
        cmplwi r9,%d
        bge    EI_avanti
        mulli  r10,r9,20
        add    r10,r10,r30
        addi   r11,r3,-12
        stw    r11,0(r10)       ; vtable
        stw    r0,4(r10)        ; init originale
        stw    r8,8(r10)        ; kill originale
        addi   r9,r9,1
        stw    r9,0(r31)
        lis    r11,EnInitHook@ha
        addi   r11,r11,EnInitHook@l
        stw    r11,0(r3)
        lis    r11,EnKillHook@ha
        addi   r11,r11,EnKillHook@l
        stw    r11,0x20(r3)
        lwz    r12,0x50(r3)     ; voce 0x5C: receiveMsgPlayerAttack
        lis    r11,0x8000
        ori    r11,r11,0x4000
        cmplw  r12,r11
        blt    EI_noatk
        lis    r11,0x8060
        cmplw  r12,r11
        bge    EI_noatk
        stw    r12,12(r10)      ; colpo originale
        lis    r11,EnAtkHook@ha
        addi   r11,r11,EnAtkHook@l
        stw    r11,0x50(r3)
        b      EI_mov
    EI_noatk:
        li     r11,0
        stw    r11,12(r10)
    EI_mov:
        lwz    r12,0x08(r3)     ; voce 0x14: movement
        lis    r11,0x8000
        ori    r11,r11,0x4000
        cmplw  r12,r11
        blt    EI_nomov
        lis    r11,0x8060
        cmplw  r12,r11
        bge    EI_nomov
        stw    r12,16(r10)      ; movement originale
        lis    r11,EnMoveHook@ha
        addi   r11,r11,EnMoveHook@l
        stw    r11,0x08(r3)
        b      EI_avanti
    EI_nomov:
        li     r11,0
        stw    r11,16(r10)
    EI_avanti:
        addi   r3,r3,4
        cmplw  r3,r4
        blt    EI_cerca
        lwz    r9,0(r31)
        lis    r10,g_en_st@ha
        addi   r10,r10,g_en_st@l
        stb    r9,6(r10)        ; diagnosi: vtable agganciate
        lwz    r30,24(r1)
        lwz    r31,28(r1)
        lwz    r0,36(r1)
        mtlr   r0
        addi   r1,r1,32
        blr
    """ % (EN_SCAN_LO >> 16, EN_SCAN_HI >> 16, init_min >> 16, init_min & 0xFFFF,
           init_max >> 16, init_max & 0xFFFF, EN_VT_MAX))

    # EnInitHook(this, iter): init originale, poi annota il nemico.
    a("""
    EnInitHook:
        stwu   r1,-32(r1)
        mflr   r0
        stw    r0,36(r1)
        stw    r31,28(r1)
        stw    r30,24(r1)
        stw    r29,20(r1)
        mr     r31,r3
        mr     r30,r4
        bl     EnFindVt
        cmpwi  r3,0
        beq    EIH_fine
        lwz    r0,4(r3)
        mtctr  r0
        mr     r3,r31
        mr     r4,r30
        bctrl                   ; init originale
        bl     0x%X             ; VIGetRetraceCount
        lis    r29,g_en_st@ha
        addi   r29,r29,g_en_st@l
        lwz    r0,0(r29)        ; ultimo fotogramma di gioco
        subf   r0,r0,r3
        cmplwi r0,%d
        ble    EIH_annota       ; si sta giocando: nemico nato durante la partita
        lbz    r0,4(r29)
        cmpwi  r0,0
        bne    EIH_annota       ; tabella gia' svuotata in questo caricamento
        li     r0,1
        stb    r0,4(r29)
        lis    r4,g_en_trN@ha
        addi   r4,r4,g_en_trN@l
        li     r0,0
        stw    r0,0(r4)         ; nuova scena: i nemici vecchi non esistono piu'
    EIH_annota:
        lwz    r0,4(r30)        ; iter.mIndex, la riga del file di livello
        cmplwi r0,0xFFFF
        bgt    EIH_fine         ; niente riga: non identificabile
        lis    r29,g_en_trN@ha
        addi   r29,r29,g_en_trN@l
        lwz    r3,0(r29)
        cmplwi r3,%d
        bge    EIH_fine
        slwi   r4,r3,4
        lis    r5,g_en_tr@ha
        addi   r5,r5,g_en_tr@l
        add    r5,r5,r4
        addi   r3,r3,1
        stw    r3,0(r29)
        mr     r29,r5
        stw    r31,0(r29)       ; attore
        sth    r0,6(r29)        ; riga
        li     r0,0
        stb    r0,12(r29)       ; flag
        stb    r0,13(r29)       ; nessuna pausa
        slwi   r4,r3,4          ; r3 = indice + 1
        lis    r6,g_en_tg@ha
        addi   r6,r6,g_en_tg@l
        add    r6,r6,r4
        stw    r0,-4(r6)        ; nessuna posizione ricevuta per la voce nuova
        lwz    r3,0x0C(r31)     ; impronta della posizione di partenza
        lwz    r4,0x10(r31)
        xor    r3,r3,r4
        lwz    r4,0x14(r31)
        xor    r3,r3,r4
        srwi   r4,r3,16
        xor    r3,r3,r4
        sth    r3,8(r29)
        lwz    r3,4(r31)        ; NameObj::mName
        bl     StrHash
        sth    r3,4(r29)
        bl     StageHash
        sth    r3,10(r29)
    EIH_fine:
        lwz    r29,20(r1)
        lwz    r30,24(r1)
        lwz    r31,28(r1)
        lwz    r0,36(r1)
        mtlr   r0
        addi   r1,r1,32
        blr
    """ % (VI_RETRACE, EN_GAP, EN_TR_MAX))

    # EnKillHook(this): se e' un nemico annotato mette in coda l'annuncio
    # (salvo che la morte venga da un altro giocatore), poi kill originale.
    a("""
    EnKillHook:
        stwu   r1,-32(r1)
        mflr   r0
        stw    r0,36(r1)
        stw    r31,28(r1)
        mr     r31,r3
        lis    r4,g_en_tr@ha
        addi   r4,r4,g_en_tr@l
        lis    r5,g_en_trN@ha
        lwz    r5,g_en_trN@l(r5)
    EKH_cerca:
        cmpwi  r5,0
        beq    EKH_orig
        lwz    r0,0(r4)
        cmplw  r0,r31
        beq    EKH_trovato
        addi   r4,r4,16
        addi   r5,r5,-1
        b      EKH_cerca
    EKH_trovato:
        lbz    r0,12(r4)
        cmpwi  r0,0
        beq    EKH_annuncia
        li     r0,0
        stb    r0,12(r4)        ; morte arrivata da un altro: niente annuncio
        b      EKH_orig
    EKH_annuncia:
        lis    r6,g_en_tx@ha
        addi   r6,r6,g_en_tx@l
        lbz    r7,13(r6)
        addi   r8,r7,1
        andi.  r8,r8,7
        lbz    r9,12(r6)
        cmpw   r8,r9
        beq    EKH_orig         ; coda piena (8 morti in attesa): questa si perde
        mulli  r10,r7,12
        add    r10,r10,r6
        lwz    r0,4(r4)         ; [nome, riga]
        stw    r0,16(r10)
        lwz    r0,8(r4)         ; [posizione, galassia]
        stw    r0,20(r10)
        li     r0,0
        sth    r0,24(r10)       ; tipo 0: morte
        stb    r8,13(r6)
    EKH_orig:
        mr     r3,r31
        bl     EnFindVt
        cmpwi  r3,0
        beq    EKH_fine
        lwz    r0,8(r3)
        mtctr  r0
        mr     r3,r31
        bctrl                   ; kill originale
    EKH_fine:
        lwz    r31,28(r1)
        lwz    r0,36(r1)
        mtlr   r0
        addi   r1,r1,32
        blr
    """)

    # EnemyTick: da S1 a ogni fotogramma di gioco.
    a("""
    EnemyTick:
        stwu   r1,-48(r1)
        mflr   r0
        stw    r0,52(r1)
        stw    r31,44(r1)
        stw    r30,40(r1)
        stw    r29,36(r1)
        stw    r28,32(r1)
        stw    r27,28(r1)
        stw    r26,24(r1)
        bl     0x%X             ; VIGetRetraceCount
        lis    r31,g_en_st@ha
        addi   r31,r31,g_en_st@l
        stw    r3,0(r31)        ; ultimo fotogramma di gioco
        li     r0,0
        stb    r0,4(r31)        ; il prossimo caricamento potra' svuotare la tabella
        bl     StageHash
        mr     r30,r3
        lis    r29,g_en_rx@ha
        addi   r29,r29,g_en_rx@l
        li     r28,0
    ET_ciclo:
        lhz    r0,8(r29)        ; sequenza dell'annuncio di questo giocatore
        cmpwi  r0,0
        beq    ET_prossimo
        lis    r3,g_en_last@ha
        addi   r3,r3,g_en_last@l
        slwi   r4,r28,1
        add    r3,r3,r4
        lhz    r4,0(r3)
        cmpw   r4,r0
        beq    ET_prossimo      ; gia' visto
        sth    r0,0(r3)
        lhz    r0,6(r29)
        cmpw   r0,r30
        bne    ET_e1            ; un'altra galassia
        lis    r27,g_en_tr@ha
        addi   r27,r27,g_en_tr@l
        lis    r26,g_en_trN@ha
        lwz    r26,g_en_trN@l(r26)
    ET_cerca:
        cmpwi  r26,0
        beq    ET_e2
        lwz    r0,4(r27)        ; nome e riga
        lwz    r3,0(r29)
        cmplw  r0,r3
        bne    ET_altro
        lwz    r0,8(r27)        ; posizione e galassia
        lwz    r3,4(r29)
        cmplw  r0,r3
        beq    ET_trovato
    ET_altro:
        addi   r27,r27,16
        addi   r26,r26,-1
        b      ET_cerca
    ET_trovato:
        lwz    r3,0(r27)
        lbz    r0,0x68(r3)      ; mFlag.mIsDead
        cmpwi  r0,0
        bne    ET_e3            ; gia' morto
        bl     EnFindVt
        cmpwi  r3,0
        beq    ET_e3            ; non e' piu' un oggetto di una classe agganciata
        mr     r26,r3           ; voce della vtable
        lbz    r0,10(r29)       ; tipo dell'evento
        cmpwi  r0,0
        bne    ET_colpo
        li     r0,1
        stb    r0,12(r27)       ; la morte arriva da un altro: non ri-annunciarla
        lwz    r3,0(r27)
        lwz    r12,0(r3)
        lwz    r12,0x2C(r12)
        mtctr  r12
        bctrl                   ; kill, attraverso EnKillHook
        li     r3,4
        b      ET_esito
    ET_colpo:                   ; un colpo dato da un altro: lo ripete solo chi comanda
        lis    r3,g_pk@ha
        addi   r3,r3,g_pk@l
        lbz    r0,0(r3)
        lbz    r4,1(r3)
        cmpw   r0,r4
        bne    ET_e6
        lwz    r0,12(r26)
        cmpwi  r0,0
        beq    ET_e6
        lwz    r3,0(r27)
        lwz    r4,0x54(r3)      ; mSensorKeeper
        cmpwi  r4,0
        beq    ET_e6
        lwz    r0,4(r4)         ; mSensorCount
        lbz    r4,11(r29)       ; sensore colpito
        cmpw   r4,r0
        bge    ET_e6
        bl     0x%X             ; MR::getSensorWithIndex
        cmpwi  r3,0
        beq    ET_e6
        stw    r3,8(r1)
        bl     0x%X             ; MarioAccess::getPlayerActor
        cmpwi  r3,0
        beq    ET_e6
        bl     0x%X             ; MR::getBodySensor: il colpo lo da' il mio Mario
        cmpwi  r3,0
        beq    ET_e6
        mr     r5,r3
        lwz    r6,8(r1)
        lwz    r3,0(r27)
        lbz    r4,10(r29)       ; il messaggio
        lwz    r0,12(r26)
        mtctr  r0
        bctrl                   ; receiveMsgPlayerAttack originale
        li     r3,5
        b      ET_esito
    ET_e6:
        li     r3,6
        b      ET_esito
    ET_e1:
        li     r3,1
        b      ET_esito
    ET_e2:
        li     r3,2
        b      ET_esito
    ET_e3:
        li     r3,3
    ET_esito:
        stb    r3,5(r31)
    ET_prossimo:
        addi   r29,r29,12
        addi   r28,r28,1
        cmpwi  r28,8
        blt    ET_ciclo
        lwz    r26,24(r1)
        lwz    r27,28(r1)
        lwz    r28,32(r1)
        lwz    r29,36(r1)
        lwz    r30,40(r1)
        lwz    r31,44(r1)
        lwz    r0,52(r1)
        mtlr   r0
        addi   r1,r1,48
        blr
    """ % (VI_RETRACE, GET_SENSOR_IDX, GET_PLAYER_ACTOR, GET_BODY_SENSOR))

    # EnAtkHook(this, msg, sender, receiver): receiveMsgPlayerAttack originale;
    # se il colpo va a segno su un nemico annotato: per EN_PAUSE fotogrammi lo
    # muove il mio gioco (niente posizioni/stati da chi comanda), e il colpo va
    # in coda con l'indice del sensore colpito, perche' chi comanda lo ripeta.
    a("""
    EnAtkHook:
        stwu   r1,-48(r1)
        mflr   r0
        stw    r0,52(r1)
        stw    r31,44(r1)
        stw    r30,40(r1)
        stw    r29,36(r1)
        stw    r28,32(r1)
        stw    r27,28(r1)
        mr     r31,r3
        mr     r30,r4
        mr     r28,r5
        mr     r29,r6
        bl     EnFindVt
        li     r27,0
        cmpwi  r3,0
        beq    EA_fine
        lwz    r0,12(r3)
        cmpwi  r0,0
        beq    EA_fine
        mtctr  r0
        mr     r3,r31
        mr     r4,r30
        mr     r5,r28
        mr     r6,r29
        bctrl                   ; receiveMsgPlayerAttack originale
        mr     r27,r3
        cmpwi  r27,0
        beq    EA_fine          ; colpo non andato a segno
        cmplwi r30,255
        bgt    EA_fine
        lis    r4,g_en_tr@ha
        addi   r4,r4,g_en_tr@l
        lis    r5,g_en_trN@ha
        lwz    r5,g_en_trN@l(r5)
    EA_cerca:
        cmpwi  r5,0
        beq    EA_fine
        lwz    r0,0(r4)
        cmplw  r0,r31
        beq    EA_trovato
        addi   r4,r4,16
        addi   r5,r5,-1
        b      EA_cerca
    EA_trovato:
        lis    r7,g_en_st@ha
        lwz    r7,g_en_st@l(r7)
        addi   r7,r7,%d
        sth    r7,14(r4)        ; pausa fino a questo fotogramma (16 bit bassi)
        li     r0,1
        stb    r0,13(r4)
        lwz    r9,0x54(r31)     ; mSensorKeeper: che numero ha il sensore colpito?
        cmpwi  r9,0
        beq    EA_fine
        lwz    r10,4(r9)
        lwz    r11,8(r9)
        li     r12,0
    EA_sens:
        cmpw   r12,r10
        bge    EA_fine          ; non trovato: niente da ripetere
        slwi   r3,r12,2
        lwzx   r3,r11,r3
        cmpwi  r3,0
        beq    EA_sdopo
        lwz    r3,8(r3)         ; HitSensorInfo::mSensor
        cmplw  r3,r29
        beq    EA_coda
    EA_sdopo:
        addi   r12,r12,1
        b      EA_sens
    EA_coda:
        lis    r6,g_en_tx@ha
        addi   r6,r6,g_en_tx@l
        lbz    r7,13(r6)
        addi   r8,r7,1
        andi.  r8,r8,7
        lbz    r9,12(r6)
        cmpw   r8,r9
        beq    EA_fine          ; coda piena
        mulli  r10,r7,12
        add    r10,r10,r6
        lwz    r0,4(r4)
        stw    r0,16(r10)
        lwz    r0,8(r4)
        stw    r0,20(r10)
        stb    r30,24(r10)      ; tipo = il messaggio
        stb    r12,25(r10)      ; sensore
        stb    r8,13(r6)
    EA_fine:
        mr     r3,r27
        lwz    r27,28(r1)
        lwz    r28,32(r1)
        lwz    r29,36(r1)
        lwz    r30,40(r1)
        lwz    r31,44(r1)
        lwz    r0,52(r1)
        mtlr   r0
        addi   r1,r1,48
        blr
    """ % EN_PAUSE)

    # EnMoveHook(this): movement originale; se intanto il gioco e' in una
    # cutscene, questo nemico ci sta recitando (gli altri durante una cutscene
    # sono fermi): la segno. Mario durante le cutscene e' fermo e PosTick non
    # gira, quindi la conta la fa PosTick quando riparte.
    a("""
    EnMoveHook:
        stwu   r1,-16(r1)
        mflr   r0
        stw    r0,20(r1)
        stw    r31,12(r1)
        mr     r31,r3
        bl     EnFindVt
        cmpwi  r3,0
        beq    EM_fine
        lwz    r0,16(r3)
        cmpwi  r0,0
        beq    EM_fine
        mtctr  r0
        mr     r3,r31
        bctrl                   ; movement originale
        bl     0x%X             ; MR::isDemoActive
        cmpwi  r3,0
        beq    EM_fine
        lis    r4,g_demo@ha
        addi   r4,r4,g_demo@l
        li     r0,1
        stb    r0,0(r4)
    EM_fine:
        lwz    r31,12(r1)
        lwz    r0,20(r1)
        mtlr   r0
        addi   r1,r1,16
        blr
    """ % IS_DEMO_ACTIVE)

    # EnPaused(r3 = voce) -> r5 = 1 se chi comanda non deve toccarla. r29 adesso.
    # Foglia: usa r0 r5.
    a("""
    EnPaused:
        li     r5,0
        lbz    r0,13(r3)
        cmpwi  r0,0
        beq    EP_fine
        lhz    r0,14(r3)
        subf   r0,r29,r0
        andi.  r0,r0,0xFFFF
        cmplwi r0,%d
        bgt    EP_scaduta
        li     r5,1
        blr
    EP_scaduta:
        stb    r5,13(r3)
    EP_fine:
        blr
    """ % EN_PAUSE)

    # ============================================= posizioni e stati dei nemici
    # Comanda il giocatore con l'id piu' basso tra me e quelli sentiti da poco
    # nella mia galassia. Chi comanda manda a ogni pacchetto:
    #   posto 1 (20 byte): [chiave, x, y, z, nerve]  un nemico che si e' mosso,
    #                      altrimenti uno qualsiasi, a giro
    #   posto 2 (8 byte):  [chiave, nerve]           uno che ha cambiato stato,
    #                      altrimenti uno qualsiasi, a giro
    # La nerve e' lo stato del nemico: un oggetto fisso del gioco, allo stesso
    # indirizzo su tutte le console. Metterla fa partire la stessa azione, e con
    # lei animazione e attacco. Gli altri tengono il nemico sull'ultima
    # posizione ricevuta per PK_HOLD fotogrammi; la nerve la cambiano solo
    # quando arriva diversa da quella che hanno.
    # Chiave: [riga ^ nome ^ galassia, impronta della posizione di partenza].
    a("""
    PosTick:
        stwu   r1,-48(r1)
        mflr   r0
        stw    r0,52(r1)
        stw    r31,44(r1)
        stw    r30,40(r1)
        stw    r29,36(r1)
        stw    r28,32(r1)
        stw    r27,28(r1)
        stw    r26,24(r1)
        stw    r25,20(r1)
        bl     StageHash
        mr     r30,r3           ; la mia galassia
        lis    r31,g_pk@ha
        addi   r31,r31,g_pk@l
        sth    r30,2(r31)
        lis    r3,g_demo@ha     ; cutscene: +0 vista adesso, +1 quante in questa galassia, +2 galassia
        addi   r3,r3,g_demo@l
        lhz    r0,2(r3)
        cmpw   r0,r30
        beq    DM_stessa
        sth    r30,2(r3)        ; galassia nuova: si ricomincia a contare
        li     r0,0
        stb    r0,0(r3)
        stb    r0,1(r3)
    DM_stessa:
        lbz    r0,0(r3)
        cmpwi  r0,0
        beq    DM_fatto
        bl     0x%(demo)X       ; MR::isDemoActive: ancora in corso?
        cmpwi  r3,0
        bne    DM_fatto
        lis    r3,g_demo@ha
        addi   r3,r3,g_demo@l
        li     r0,0
        stb    r0,0(r3)
        lbz    r4,1(r3)
        cmplwi r4,255
        bge    DM_fatto
        addi   r4,r4,1
        stb    r4,1(r3)         ; una cutscene in piu'
    DM_fatto:
        lis    r3,g_tp@ha       ; teletrasporto: +0 richiesta, +1 da chi, +2 galassia, +4 xyz, +16 pausa
        addi   r3,r3,g_tp@l
        lhz    r4,16(r3)
        cmpwi  r4,0
        beq    TP_guarda
        addi   r4,r4,-1
        sth    r4,16(r3)
        li     r0,0
        stb    r0,0(r3)         ; durante la pausa le richieste si buttano
        b      TP_fatto
    TP_guarda:
        lbz    r0,0(r3)
        cmpwi  r0,0
        beq    TP_fatto
        li     r0,0
        stb    r0,0(r3)
        li     r4,%(cool)d
        sth    r4,16(r3)
        lhz    r0,2(r3)
        cmpwi  r0,0
        beq    TP_vai           ; galassia sconosciuta (versione vecchia): si va lo stesso
        cmpw   r0,r30
        bne    TP_fatto         ; e' in un'altra galassia
    TP_vai:
        addi   r3,r3,4
        bl     0x%(setpos)X     ; MR::setPlayerPos
        lis    r3,g_tp@ha
        addi   r3,r3,g_tp@l
        lbz    r4,18(r3)
        addi   r4,r4,1
        stb    r4,18(r3)        ; diagnosi: teletrasporti fatti
    TP_fatto:
        lis    r3,g_en_st@ha
        lwz    r29,g_en_st@l(r3) ; adesso (lo ha appena scritto EnemyTick)
        lis    r26,g_pk_tx@ha
        addi   r26,r26,g_pk_tx@l
        li     r0,-1            ; posti vuoti, se non comando io restano cosi'
        stw    r0,0(r26)
        stw    r0,20(r26)
        li     r0,0
        stw    r0,28(r26)
        lbz    r28,0(r31)       ; io
        cmplwi r28,8
        bge    PT_fine
        mr     r27,r28          ; chi comanda
        lis    r3,g_demo@ha
        addi   r3,r3,g_demo@l
        lbz    r12,1(r3)        ; le sue cutscene (per ora le mie)
        li     r25,0
    PT_m:
        cmpw   r25,r28
        beq    PT_mdopo
        lis    r3,g_pk_seen@ha
        addi   r3,r3,g_pk_seen@l
        slwi   r4,r25,2
        lwzx   r0,r3,r4
        cmpwi  r0,0
        beq    PT_mdopo         ; mai sentito
        subf   r0,r0,r29
        cmplwi r0,%(alive)d
        bgt    PT_mdopo         ; sparito
        lis    r3,g_pk_stage@ha
        addi   r3,r3,g_pk_stage@l
        slwi   r4,r25,1
        add    r3,r3,r4
        lhz    r0,0(r3)
        cmpw   r0,r30
        bne    PT_mdopo         ; in un'altra galassia
        lis    r3,g_pk_demo@ha
        addi   r3,r3,g_pk_demo@l
        lbzx   r0,r3,r25
        cmpw   r0,r12
        blt    PT_mdopo         ; ha visto meno cutscene: e' piu' indietro
        bgt    PT_mnuovo
        cmpw   r25,r27
        bge    PT_mdopo         ; pari: vince lo slot piu' basso
    PT_mnuovo:
        mr     r27,r25
        mr     r12,r0
    PT_mdopo:
        addi   r25,r25,1
        cmpwi  r25,8
        blt    PT_m
        stb    r27,1(r31)
        cmpw   r27,r28
        beq    PT_comando

        ; --- non comando: notizie nuove da chi comanda?
        lis    r3,g_pk_new@ha
        addi   r3,r3,g_pk_new@l
        lbzx   r0,r3,r27
        cmpwi  r0,0
        beq    PT_applica
        li     r0,0
        stbx   r0,r3,r27
        lis    r25,g_pk_rx@ha
        addi   r25,r25,g_pk_rx@l
        slwi   r4,r27,5
        add    r25,r25,r4
        lwz    r3,0(r25)        ; posto 1
        bl     PosFind
        cmpwi  r3,0
        beq    PT_posto2
        bl     EnPaused
        cmpwi  r5,0
        bne    PT_posto2        ; l'ho colpito io da poco: lo muove il mio gioco
        lwz    r0,4(r25)
        stw    r0,0(r4)
        lwz    r0,8(r25)
        stw    r0,4(r4)
        lwz    r0,12(r25)
        stw    r0,8(r4)
        stw    r29,12(r4)
        lhz    r4,8(r31)
        addi   r4,r4,1
        sth    r4,8(r31)        ; diagnosi: posizioni usate
        lwz    r3,0(r3)
        lwz    r4,16(r25)
        bl     NerveApply
    PT_posto2:
        lwz    r3,20(r25)
        bl     PosFind
        cmpwi  r3,0
        beq    PT_applica
        bl     EnPaused
        cmpwi  r5,0
        bne    PT_applica
        lwz    r3,0(r3)
        lwz    r4,24(r25)
        bl     NerveApply
    PT_applica:
        lis    r26,g_en_tr@ha
        addi   r26,r26,g_en_tr@l
        lis    r25,g_en_tg@ha
        addi   r25,r25,g_en_tg@l
        lis    r3,g_en_trN@ha
        lwz    r28,g_en_trN@l(r3)
    PA_ciclo:
        cmpwi  r28,0
        beq    PT_fine
        lwz    r0,12(r25)       ; fotogramma dell'ultima notizia
        cmpwi  r0,0
        beq    PA_dopo
        subf   r0,r0,r29
        cmplwi r0,%(hold)d
        bgt    PA_dopo          ; notizia vecchia: decide il gioco da solo
        mr     r3,r26
        bl     EnPaused
        cmpwi  r5,0
        bne    PA_dopo
        lwz    r3,0(r26)
        lbz    r0,0x68(r3)      ; mIsDead
        cmpwi  r0,0
        bne    PA_dopo
        lwz    r0,0(r25)
        stw    r0,0x0C(r3)      ; mTranslation
        lwz    r0,4(r25)
        stw    r0,0x10(r3)
        lwz    r0,8(r25)
        stw    r0,0x14(r3)
    PA_dopo:
        addi   r26,r26,16
        addi   r25,r25,16
        addi   r28,r28,-1
        b      PA_ciclo

        ; --- comando io: prepara i posti del prossimo pacchetto
    PT_comando:
        li     r3,1             ; uno che si e' mosso
        mr     r4,r26
        addi   r5,r31,4
        bl     PosPick
        cmpwi  r3,0
        bne    PT_stato
        li     r3,0             ; nessuno si e' mosso: uno qualsiasi
        mr     r4,r26
        addi   r5,r31,6
        bl     PosPick
    PT_stato:
        li     r3,1             ; uno che ha cambiato stato
        addi   r4,r26,20
        addi   r5,r31,10
        bl     NervePick
        cmpwi  r3,0
        bne    PT_fine
        li     r3,0
        addi   r4,r26,20
        addi   r5,r31,12
        bl     NervePick
    PT_fine:
        lwz    r25,20(r1)
        lwz    r26,24(r1)
        lwz    r27,28(r1)
        lwz    r28,32(r1)
        lwz    r29,36(r1)
        lwz    r30,40(r1)
        lwz    r31,44(r1)
        lwz    r0,52(r1)
        mtlr   r0
        addi   r1,r1,48
        blr
    """ % {"alive": PK_ALIVE, "hold": PK_HOLD, "cool": TP_COOL, "setpos": SET_PLAYER_POS,
           "demo": IS_DEMO_ACTIVE})

    # PosFind(r3 = chiave) -> r3 = voce della tabella o 0, r4 = sua posizione
    # ricevuta (g_en_tg). r30 galassia. Foglia: r0 r3-r9.
    a("""
    PosFind:
        cmpwi  r3,-1
        beq    PF_no            ; posto vuoto
        srwi   r5,r3,16
        xor    r5,r5,r30        ; riga ^ nome
        andi.  r6,r3,0xFFFF     ; impronta della posizione di partenza
        lis    r7,g_en_tr@ha
        addi   r7,r7,g_en_tr@l
        lis    r4,g_en_tg@ha
        addi   r4,r4,g_en_tg@l
        lis    r8,g_en_trN@ha
        lwz    r8,g_en_trN@l(r8)
    PF_cerca:
        cmpwi  r8,0
        beq    PF_no
        lhz    r0,10(r7)
        cmpw   r0,r30
        bne    PF_altro
        lhz    r0,8(r7)
        cmpw   r0,r6
        bne    PF_altro
        lhz    r0,6(r7)
        lhz    r9,4(r7)
        xor    r0,r0,r9
        cmpw   r0,r5
        bne    PF_altro
        mr     r3,r7
        blr
    PF_altro:
        addi   r7,r7,16
        addi   r4,r4,16
        addi   r8,r8,-1
        b      PF_cerca
    PF_no:
        li     r3,0
        blr
    """)

    # NerveApply(r3 = nemico, r4 = nerve): se e' vivo, ha una Spine e la nerve
    # e' credibile (oggetto del gioco con vtable e execute nel codice) ed e'
    # diversa da quella attuale e da quella in arrivo: LiveActor::setNerve.
    a("""
    NerveApply:
        stwu   r1,-16(r1)
        mflr   r0
        stw    r0,20(r1)
        lis    r5,0x%(lo)X
        lis    r6,0x%(hi)X
        cmplw  r4,r5
        blt    NA_fine
        cmplw  r4,r6
        bge    NA_fine
        lwz    r7,0(r4)         ; vtable della nerve
        cmplw  r7,r5
        blt    NA_fine
        cmplw  r7,r6
        bge    NA_fine
        lwz    r7,8(r7)         ; Nerve::execute
        lis    r5,0x8000
        ori    r5,r5,0x4000
        lis    r6,0x%(codehi)X
        cmplw  r7,r5
        blt    NA_fine
        cmplw  r7,r6
        bge    NA_fine
        lbz    r0,0x68(r3)      ; mIsDead
        cmpwi  r0,0
        bne    NA_fine
        lwz    r5,0x50(r3)      ; mSpine
        cmpwi  r5,0
        beq    NA_fine
        lwz    r0,4(r5)         ; mCurrNerve
        cmplw  r0,r4
        beq    NA_fine
        lwz    r0,8(r5)         ; mNextNerve
        cmplw  r0,r4
        beq    NA_fine
        bl     0x%(setnerve)X   ; LiveActor::setNerve
        lis    r5,g_pk@ha
        addi   r5,r5,g_pk@l
        lhz    r6,14(r5)
        addi   r6,r6,1
        sth    r6,14(r5)        ; diagnosi: stati cambiati
    NA_fine:
        lwz    r0,20(r1)
        mtlr   r0
        addi   r1,r1,16
        blr
    """ % {"lo": NRV_LO >> 16, "hi": NRV_HI >> 16, "codehi": CODE_HI >> 16, "setnerve": SET_NERVE})

    # Chiave della voce r9 in r0 (usa r12). r30 galassia.
    KEY = """
        lhz    r0,6(r9)
        lhz    r12,4(r9)
        xor    r0,r0,r12
        xor    r0,r0,r30
        slwi   r0,r0,16
        lhz    r12,8(r9)
        add    r0,r0,r12
    """

    # PosPick(r3 = 1 solo se mosso, r4 = posto da 20 byte, r5 = contatore del
    # giro u16) -> r3 = 1 se riempito. r30 galassia. Foglia: r0 r3-r12.
    a("""
    PosPick:
        lis    r6,g_en_trN@ha
        lwz    r6,g_en_trN@l(r6)
        mr     r7,r6            ; tentativi
        lhz    r8,0(r5)
    PK_ciclo:
        cmpwi  r7,0
        beq    PK_niente
        cmplw  r8,r6
        blt    PK_dentro
        li     r8,0
    PK_dentro:
        slwi   r9,r8,4
        lis    r10,g_en_tr@ha
        addi   r10,r10,g_en_tr@l
        add    r9,r9,r10        ; voce
        mulli  r11,r8,12
        lis    r12,g_en_ls@ha
        addi   r12,r12,g_en_ls@l
        add    r11,r11,r12      ; ultima posizione mandata
        addi   r8,r8,1
        addi   r7,r7,-1
        lhz    r0,10(r9)
        cmpw   r0,r30
        bne    PK_ciclo
        lwz    r10,0(r9)
        lbz    r0,0x68(r10)
        cmpwi  r0,0
        bne    PK_ciclo         ; morto
        cmpwi  r3,0
        beq    PK_prendi
        lwz    r0,0x0C(r10)
        lwz    r12,0(r11)
        cmplw  r0,r12
        bne    PK_prendi
        lwz    r0,0x10(r10)
        lwz    r12,4(r11)
        cmplw  r0,r12
        bne    PK_prendi
        lwz    r0,0x14(r10)
        lwz    r12,8(r11)
        cmplw  r0,r12
        bne    PK_prendi
        b      PK_ciclo         ; fermo
    PK_prendi:
        sth    r8,0(r5)
    """ + KEY + """
        stw    r0,0(r4)
        lwz    r0,0x0C(r10)
        stw    r0,4(r4)
        stw    r0,0(r11)
        lwz    r0,0x10(r10)
        stw    r0,8(r4)
        stw    r0,4(r11)
        lwz    r0,0x14(r10)
        stw    r0,12(r4)
        stw    r0,8(r11)
        li     r0,0
        lwz    r12,0x50(r10)    ; mSpine
        cmpwi  r12,0
        beq    PK_nerve
        lwz    r0,4(r12)        ; mCurrNerve
    PK_nerve:
        stw    r0,16(r4)
        li     r3,1
        blr
    PK_niente:
        li     r3,0
        blr
    """)

    # NervePick(r3 = 1 solo se cambiata, r4 = posto da 8 byte, r5 = contatore
    # del giro u16) -> r3 = 1 se riempito. r30 galassia. Foglia: r0 r3-r12.
    a("""
    NervePick:
        lis    r6,g_en_trN@ha
        lwz    r6,g_en_trN@l(r6)
        mr     r7,r6
        lhz    r8,0(r5)
    NP_ciclo:
        cmpwi  r7,0
        beq    NP_niente
        cmplw  r8,r6
        blt    NP_dentro
        li     r8,0
    NP_dentro:
        slwi   r9,r8,4
        lis    r10,g_en_tr@ha
        addi   r10,r10,g_en_tr@l
        add    r9,r9,r10        ; voce
        slwi   r11,r8,2
        lis    r12,g_en_ln@ha
        addi   r12,r12,g_en_ln@l
        add    r11,r11,r12      ; ultima nerve mandata
        addi   r8,r8,1
        addi   r7,r7,-1
        lhz    r0,10(r9)
        cmpw   r0,r30
        bne    NP_ciclo
        lwz    r10,0(r9)
        lbz    r0,0x68(r10)
        cmpwi  r0,0
        bne    NP_ciclo         ; morto
        lwz    r10,0x50(r10)    ; mSpine
        cmpwi  r10,0
        beq    NP_ciclo
        lwz    r10,4(r10)       ; mCurrNerve
        cmpwi  r10,0
        beq    NP_ciclo
        cmpwi  r3,0
        beq    NP_prendi
        lwz    r0,0(r11)
        cmplw  r0,r10
        beq    NP_ciclo         ; stessa di prima
    NP_prendi:
        sth    r8,0(r5)
        stw    r10,0(r11)
    """ + KEY + """
        stw    r0,0(r4)
        stw    r10,4(r4)
        li     r3,1
        blr
    NP_niente:
        li     r3,0
        blr
    """)

    a.align(16)
    a.label("g_sendW"); a.zero(16)
    a.label("g_valid"); a.zero(8)
    a.label("g_star");  a.zero(8)      # numero, 0, impronta u16, da mandare u16, vtable u8, 0
    a.label("g_rx");    a.zero(32)     # numero[8], impronta[8] u16, servito[8]
    a.label("g_diag");  a.zero(4)      # esaminata, esito, ricevuta, giri
    a.label("g_en_st");  a.zero(8)     # ultimo fotogramma u32, svuotata u8, esito u8, vtable u8, 0
    a.label("g_en_tx");  a.zero(112)   # annuncio 8, seq u16, da mandare u16, rd u8, wr u8, tipo u8, sensore u8, coda 8x12
    a.label("g_en_rx");  a.zero(96)    # 8 giocatori x [nome, riga, posizione, galassia, seq, 0] u16
    a.label("g_en_last"); a.zero(16)   # ultima sequenza vista per giocatore
    a.label("g_en_vtN"); a.zero(4)
    a.label("g_en_vt");  a.zero(EN_VT_MAX * 20)   # vtable, init, kill, colpo, movement
    a.label("g_en_trN"); a.zero(4)
    a.label("g_en_tr");  a.zero(EN_TR_MAX * 16)   # attore, nome, riga, posizione, galassia, flag
    a.label("g_en_inits")
    for x in EN_INITS: a.word(x)
    a.word(0)
    a.label("g_recvW"); a.zero(8 * 16)
    a.label("g_pk");       a.zero(16)          # io u8, chi comanda u8, galassia u16, giri posizione u16 x2, posizioni usate u16, giri nerve u16 x2, nerve messe u16
    a.label("g_pk_seen");  a.zero(8 * 4)       # fotogramma dell'ultimo pacchetto da 124 per giocatore
    a.label("g_pk_stage"); a.zero(8 * 2)       # la sua galassia
    a.label("g_pk_new");   a.zero(8)           # posti non ancora letti
    a.label("g_pk_rx");    a.zero(8 * 32)      # i suoi 2 posti
    a.label("g_pk_tx");    a.zero(32)          # i miei 2 posti
    a.label("g_en_ls");    a.zero(EN_TR_MAX * 12)   # ultima posizione mandata, per voce
    a.label("g_en_tg");    a.zero(EN_TR_MAX * 16)   # posizione ricevuta + fotogramma, per voce
    a.label("g_en_ln");    a.zero(EN_TR_MAX * 4)    # ultima nerve mandata, per voce
    a.label("g_tp");       a.zero(20)               # teletrasporto
    a.label("g_demo");     a.zero(4)                # cutscene: vista, quante, galassia u16
    a.label("g_pk_demo");  a.zero(8)                # cutscene viste da ogni giocatore

    blob, relocs = a.encode()

    # ------------------------------------------------ agganci nel codice vecchio
    def branch(frm, to, link=False):
        d = to - frm
        return (18 << 26) | (d & 0x03FFFFFC) | (1 if link else 0)

    hooks = {
        "T1": branch(SITES["T1"][0], a.labels["T1"]),
        "T2": branch(SITES["T2"][0], a.labels["T2"], link=True),
        "T3": branch(SITES["T3"][0], a.labels["T3"]),
        "T4": branch(SITES["T4"][0], a.labels["T4"]),
        "S1": branch(SITES["S1"][0], a.labels["S1"]),
        "V2": branch(SITES["V2"][0], a.labels["V2"]),
        "V1": NEW_V1,
        "B0": branch(SITES["B0"][0], a.labels["EnBoot"]),
    }
    for name, w in hooks.items():
        code[SITES[name][0]:SITES[name][0]+4] = struct.pack(">I", w)
    code[K_SIZE[0]:K_SIZE[0]+4] = struct.pack(">I", NEW_SIZE)

    new_code = bytes(code) + b"\0" * k.bss + blob
    assert len(new_code) == base + len(blob)

    old_cmds = k.raw[CODE_OFF + k.size:]
    new_cmds = bytearray(old_cmds)
    for off, t, target in relocs:
        assert off < 0xFFFFFE
        new_cmds += struct.pack(">II", (t << 24) | off, target)

    header = b"Kamek\0\0\2" + struct.pack(">IIII", 0, len(new_code), k.ctor0, k.ctor1) + k.raw[24:CODE_OFF]
    out = header + new_code + bytes(new_cmds)
    open(DST, "wb").write(out)
    # le etichette, per l'emulatore: niente da indovinare dall'altra parte
    json.dump({n: v for n, v in a.labels.items()}, open(DST + ".labels.json", "w"), indent=1)

    print("codice nuovo a codice+0x%X, %d byte, %d rilocazioni" % (base, len(blob), len(relocs)))
    for n in ("T1", "T2", "T3", "T4", "S1", "V2", "StageHash", "PS_recv", "StarTick",
              "g_sendW", "g_valid", "g_star", "g_rx", "g_recvW"):
        print("  %-10s codice+0x%X" % (n, a.labels[n]))
    print("file: %d -> %d byte" % (len(k.raw), len(out)))


if __name__ == "__main__":
    main()
