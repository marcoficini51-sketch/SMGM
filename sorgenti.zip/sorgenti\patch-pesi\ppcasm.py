#!/usr/bin/env python3
"""Assemblatore PowerPC minimo, per le patch a mano del binario Kamek.

Solo le istruzioni che servono. Le etichette sono offset nel codice del
binario; i riferimenti ai dati con @ha/@l diventano comandi di rilocazione
Kamek, perche' il binario viene caricato a un indirizzo noto solo a runtime.
I salti restano relativi e si codificano subito: codice e bersagli stanno
nello stesso blocco, quindi la distanza non cambia dove che sia caricato.
"""
import re, struct

ADDR16_LO, ADDR16_HA, REL24 = 4, 6, 10

D_OPS = {"lwz": 32, "lwzu": 33, "lbz": 34, "stw": 36, "stwu": 37, "stb": 38,
         "lhz": 40, "sth": 44, "lfs": 48, "stfs": 52}
BC = {"beq": (12, 2), "bne": (4, 2), "blt": (12, 0), "bge": (4, 0),
      "bgt": (12, 1), "ble": (4, 1)}


def reg(s):
    s = s.strip()
    m = re.fullmatch(r"[rf](\d+)", s)
    if not m: raise ValueError("registro non valido: %r" % s)
    return int(m.group(1))


def num(s):
    return int(s.strip(), 0)


class Asm:
    def __init__(self, base):
        self.base = base            # offset nel codice della prima istruzione
        self.items = []             # (offset, testo o parola, riga sorgente)
        self.labels = {}
        self.pc = base

    # ----------------------------------------------------------- costruzione
    def label(self, name):
        if name in self.labels: raise ValueError("etichetta doppia: " + name)
        self.labels[name] = self.pc

    def __call__(self, text):
        for line in text.strip().splitlines():
            line = line.split(";")[0].strip()
            if not line: continue
            if line.endswith(":"):
                self.label(line[:-1].strip()); continue
            self.items.append((self.pc, line))
            self.pc += 4

    def word(self, v):
        self.items.append((self.pc, ".word 0x%08X" % v)); self.pc += 4

    def zero(self, n):
        assert n % 4 == 0
        for _ in range(n // 4): self.word(0)

    def align(self, a):
        while self.pc % a: self.word(0)

    # ------------------------------------------------------------ codifica
    def _target(self, s):
        s = s.strip()
        if s in self.labels: return self.labels[s]
        if s.startswith("@"): return num(s[1:])          # offset assoluto nel codice
        raise ValueError("bersaglio sconosciuto: " + s)

    def _imm(self, s, pc, relocs):
        """Immediato a 16 bit, eventualmente simbolo@ha / simbolo@l."""
        s = s.strip()
        m = re.fullmatch(r"(\w+)@(ha|l)", s)
        if m:
            t = self._target(m.group(1))
            relocs.append((pc + 2, ADDR16_HA if m.group(2) == "ha" else ADDR16_LO, t))
            return 0
        return num(s) & 0xFFFF

    def encode(self):
        out, relocs = bytearray(), []
        for pc, line in self.items:
            out += struct.pack(">I", self._one(pc, line, relocs))
        return bytes(out), relocs

    def _one(self, pc, line, relocs):
        if line.startswith(".word"): return num(line.split()[1])
        mn, _, ops = line.partition(" ")
        a = [x.strip() for x in ops.split(",")] if ops else []

        if mn == "blr": return 0x4E800020
        if mn == "nop": return 0x60000000
        if mn in ("b", "bl") and a[0].lower().startswith("0x8"):
            # funzione del gioco a indirizzo assoluto: la distanza la conosce
            # solo il loader, quindi va una rilocazione Rel24
            relocs.append((pc, REL24, int(a[0], 16)))
            return (18 << 26) | (1 if mn == "bl" else 0)
        if mn in ("b", "bl"):
            d = self._target(a[0]) - pc
            assert -0x2000000 <= d < 0x2000000 and d % 4 == 0
            return (18 << 26) | (d & 0x03FFFFFC) | (1 if mn == "bl" else 0)
        if mn in BC:
            bo, bi = BC[mn]
            d = self._target(a[0]) - pc
            assert -0x8000 <= d < 0x8000, "salto condizionato troppo lontano"
            return (16 << 26) | (bo << 21) | (bi << 16) | (d & 0xFFFC)
        if mn == "li":  return (14 << 26) | (reg(a[0]) << 21) | self._imm(a[1], pc, relocs)
        if mn == "lis": return (15 << 26) | (reg(a[0]) << 21) | self._imm(a[1], pc, relocs)
        if mn == "addi":
            return (14 << 26) | (reg(a[0]) << 21) | (reg(a[1]) << 16) | self._imm(a[2], pc, relocs)
        if mn in ("cmpwi", "cmplwi"):
            op = 11 if mn == "cmpwi" else 10
            return (op << 26) | (reg(a[0]) << 16) | (num(a[1]) & 0xFFFF)     # sempre cr0
        if mn in D_OPS:
            m = re.fullmatch(r"(.+)\((r\d+)\)", a[1])
            off = self._imm(m.group(1), pc, relocs)
            return (D_OPS[mn] << 26) | (reg(a[0]) << 21) | (reg(m.group(2)) << 16) | off
        if mn in ("add", "lbzx", "stbx", "lwzx", "stwx"):
            xo = {"add": 266, "lbzx": 87, "stbx": 215, "lwzx": 23, "stwx": 151}[mn]
            return (31 << 26) | (reg(a[0]) << 21) | (reg(a[1]) << 16) | (reg(a[2]) << 11) | (xo << 1)
        if mn == "mflr": return (31 << 26) | (reg(a[0]) << 21) | (8 << 16) | (339 << 1)
        if mn == "mtctr": return (31 << 26) | (reg(a[0]) << 21) | (9 << 16) | (467 << 1)
        if mn == "bctrl": return 0x4E800421
        if mn == "subf":                                 # rD = rB - rA
            return (31 << 26) | (reg(a[0]) << 21) | (reg(a[1]) << 16) | (reg(a[2]) << 11) | (40 << 1)
        if mn == "xor":                                  # xor rA,rS,rB
            return (31 << 26) | (reg(a[1]) << 21) | (reg(a[0]) << 16) | (reg(a[2]) << 11) | (316 << 1)
        if mn == "srwi":
            n = num(a[2])
            return (21 << 26) | (reg(a[1]) << 21) | (reg(a[0]) << 16) | ((32 - n) << 11) | (n << 6) | (31 << 1)
        if mn == "mtlr": return (31 << 26) | (reg(a[0]) << 21) | (8 << 16) | (467 << 1)
        if mn in ("cmpw", "cmplw"):                      # sempre cr0
            xo = 0 if mn == "cmpw" else 32
            return (31 << 26) | (reg(a[0]) << 16) | (reg(a[1]) << 11) | (xo << 1)
        if mn == "mulli":
            return (7 << 26) | (reg(a[0]) << 21) | (reg(a[1]) << 16) | (num(a[2]) & 0xFFFF)
        if mn in ("andi.", "ori"):
            op = 28 if mn == "andi." else 24
            return (op << 26) | (reg(a[1]) << 21) | (reg(a[0]) << 16) | (num(a[2]) & 0xFFFF)
        if mn == "mr":
            s = reg(a[1])
            return (31 << 26) | (s << 21) | (reg(a[0]) << 16) | (s << 11) | (444 << 1)
        if mn == "slwi":
            n = num(a[2])
            return (21 << 26) | (reg(a[1]) << 21) | (reg(a[0]) << 16) | (n << 11) | (0 << 6) | ((31 - n) << 1)
        raise ValueError("istruzione non supportata: " + line)
