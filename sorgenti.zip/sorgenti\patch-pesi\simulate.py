#!/usr/bin/env python3
"""Prova la patch del mod senza un Wii.

1. Caricatore Kamek (come il loader Syati di riivo_USA.xml): originale e
   patchato allo stesso indirizzo devono differire solo nei punti voluti.
2. Mini emulatore PowerPC che esegue davvero il codice nuovo. Ogni accesso
   fuori dalla memoria mappata e' un errore, come in Dolphin. Le funzioni del
   gioco sono finte, in Python, agganciate ai loro indirizzi veri: registrano
   con quali argomenti vengono chiamate.

  simulate.py [patchato]
"""
import struct, sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from kmn import Kamek

ORIG = "/mnt/c/smgbuild/pesi/CustomCode_USA.orig.bin"
NEW = sys.argv[1] if len(sys.argv) > 1 else "/mnt/c/smgbuild/pesi/CustomCode_USA.bin"
BASE = 0x80800000
fails = 0


def check(cond, msg):
    global fails
    print("  %s  %s" % ("ok  " if cond else "NO  ", msg))
    if not cond: fails += 1


# --------------------------------------------------------------- caricatore
def load(path):
    k = Kamek(path)
    mem = bytearray(k.code) + bytearray(k.bss)
    res = lambda v: v if v & 0x80000000 else BASE + v
    for _, t, a, absolute, args in k.cmds:
        if absolute: continue
        target = res(args[0])
        if t == 1:
            mem[a:a+4] = struct.pack(">I", target)
        elif t in (4, 5, 6):
            v = {4: target & 0xFFFF, 5: target >> 16,
                 6: ((target >> 16) + (1 if target & 0x8000 else 0)) & 0xFFFF}[t]
            mem[a:a+2] = struct.pack(">H", v)
        elif t == 10:
            w, = struct.unpack(">I", mem[a:a+4])
            d = target - (BASE + a)
            mem[a:a+4] = struct.pack(">I", (w & 0xFC000003) | (d & 0x03FFFFFC))
        else:
            raise SystemExit("rilocazione interna inattesa: %d" % t)
    return k, mem


print("=== 1. caricamento: originale contro patchato ===")
ko, mo = load(ORIG)
kn, mn = load(NEW)
check([c[1:] for c in kn.cmds[:len(ko.cmds)]] == [c[1:] for c in ko.cmds],
      "i comandi originali ci sono tutti, identici e nello stesso ordine")
old_len = len(mo)
diff = sorted({o & ~3 for o in range(old_len) if mo[o] != mn[o]})
print("  parole cambiate nella parte vecchia: %s" % ", ".join("0x%X" % d for d in diff))
expected = {0x2DB8, 0x2E78, 0x0B78, 0x19D4, 0x5680, 0x2DE8, 0x3994, 0x39A4, 0x2884}
check(set(diff) == expected, "sono esattamente quelle attese")
check(mn[len(ko.code):old_len] == bytes(ko.bss), "la zona dell'ex BSS e' tutta a zero")
L = json.load(open(NEW + ".labels.json"))


# --------------------------------------------------------------- emulatore
class Fault(Exception):
    pass


class CPU:
    def __init__(self, image):
        self.regions = []
        self.map(BASE, bytes(image))
        self.map(0x81000000, bytes(0x100000))   # dati di prova
        self.map(0x80F00000, bytes(0x100000))   # pila
        self.map(0x8052F000, bytes(0xC2000))    # zona dove si cercano le vtable
        self.r = [0] * 32
        self.f = [0] * 32
        self.lr = 0
        self.ctr = 0
        self.cr0 = (False, False, False)
        self.pc = 0
        self.py = {}                            # indirizzo -> funzione finta del gioco

    def map(self, start, data):
        self.regions.append((start, bytearray(data)))

    def _find(self, a, n):
        for start, buf in self.regions:
            if start <= a and a + n <= start + len(buf):
                return buf, a - start
        raise Fault("accesso non valido a 0x%08X (pc 0x%08X)" % (a, self.pc))

    def read(self, a, n):
        buf, o = self._find(a, n); return bytes(buf[o:o+n])

    def write(self, a, data):
        buf, o = self._find(a, len(data)); buf[o:o+len(data)] = data

    def rd32(self, a): return struct.unpack(">I", self.read(a, 4))[0]
    def wr32(self, a, v): self.write(a, struct.pack(">I", v & 0xFFFFFFFF))
    def rd16(self, a): return struct.unpack(">H", self.read(a, 2))[0]
    def wr16(self, a, v): self.write(a, struct.pack(">H", v & 0xFFFF))

    def run(self, start, stop, limit=20000000):
        stops = {stop} if isinstance(stop, int) else set(stop)
        self.pc = start
        for _ in range(limit):
            if self.pc in stops: return self.pc
            if self.pc in self.py:              # funzione del gioco: la esegue Python
                self.py[self.pc](self)
                self.pc = self.lr
                continue
            self.step()
        raise RuntimeError("non arrivo a %s (fermo a 0x%X)" % (
            ", ".join("0x%X" % s for s in stops), self.pc))

    def step(self):
        w = self.rd32(self.pc)
        op = w >> 26
        d, a, b = (w >> 21) & 31, (w >> 16) & 31, (w >> 11) & 31
        simm = w & 0xFFFF
        if simm & 0x8000: simm -= 0x10000
        R = self.r
        ra0 = R[a] if a else 0
        nxt = self.pc + 4
        m = lambda: (ra0 + simm) & 0xFFFFFFFF
        s32 = lambda x: x - (1 << 32) if x & 0x80000000 else x
        if op == 14: R[d] = (ra0 + simm) & 0xFFFFFFFF
        elif op == 15: R[d] = (ra0 + (simm << 16)) & 0xFFFFFFFF
        elif op == 7: R[d] = (s32(R[a]) * simm) & 0xFFFFFFFF                   # mulli
        elif op == 32: R[d] = self.rd32(m())
        elif op == 34: R[d] = self.read(m(), 1)[0]
        elif op == 40: R[d] = self.rd16(m())
        elif op == 36: self.wr32(m(), R[d])
        elif op == 37:
            ea = m(); self.wr32(ea, R[d]); R[a] = ea
        elif op == 38: self.write(m(), bytes([R[d] & 0xFF]))
        elif op == 44: self.wr16(m(), R[d])                                    # sth
        elif op == 48: self.f[d] = self.rd32(m())
        elif op == 52: self.wr32(m(), self.f[d])
        elif op == 24: R[a] = R[d] | (w & 0xFFFF)
        elif op == 28:
            R[a] = R[d] & (w & 0xFFFF)
            self.cr0 = (False, R[a] != 0, R[a] == 0)
        elif op in (10, 11):
            x, y = R[a], w & 0xFFFF
            if op == 11: x, y = s32(x), simm
            self.cr0 = (x < y, x > y, x == y)
        elif op == 18:
            li = w & 0x03FFFFFC
            if li & 0x02000000: li -= 0x04000000
            if w & 1: self.lr = nxt
            nxt = self.pc + li
        elif op == 16:
            bd = w & 0xFFFC
            if bd & 0x8000: bd -= 0x10000
            if self.cr0[a & 3] == bool(d & 8): nxt = self.pc + bd
        elif op == 19 and ((w >> 1) & 0x3FF) == 16 and d == 20:
            nxt = self.lr
        elif op == 19 and ((w >> 1) & 0x3FF) == 528 and d == 20:     # bctr / bctrl
            if w & 1: self.lr = nxt
            nxt = self.ctr
        elif op == 21:
            sh, mb, me = b, (w >> 6) & 31, (w >> 1) & 31
            rot = ((R[d] << sh) | (R[d] >> (32 - sh))) & 0xFFFFFFFF if sh else R[d]
            mask = 0
            for i in range(mb, me + 1): mask |= 1 << (31 - i)
            R[a] = rot & mask
        elif op == 31:
            xo = (w >> 1) & 0x3FF
            spr = ((w >> 16) & 31) | (((w >> 11) & 31) << 5)
            if xo == 266: R[d] = (R[a] + R[b]) & 0xFFFFFFFF
            elif xo == 87: R[d] = self.read((ra0 + R[b]) & 0xFFFFFFFF, 1)[0]
            elif xo == 215: self.write((ra0 + R[b]) & 0xFFFFFFFF, bytes([R[d] & 0xFF]))
            elif xo == 23: R[d] = self.rd32((ra0 + R[b]) & 0xFFFFFFFF)             # lwzx
            elif xo == 444: R[a] = R[d] | R[b]
            elif xo == 0:
                x, y = s32(R[a]), s32(R[b]); self.cr0 = (x < y, x > y, x == y)
            elif xo == 32:
                x, y = R[a], R[b]; self.cr0 = (x < y, x > y, x == y)
            elif xo == 40: R[d] = (R[b] - R[a]) & 0xFFFFFFFF                # subf
            elif xo == 316: R[a] = R[d] ^ R[b]                                  # xor
            elif xo == 467 and spr == 9: self.ctr = R[d]                        # mtctr
            elif xo == 339 and spr == 8: R[d] = self.lr
            elif xo == 467 and spr == 8: self.lr = R[d]
            else: raise RuntimeError("op31.%d non emulata a 0x%X" % (xo, self.pc))
        else:
            raise RuntimeError("istruzione 0x%08X non emulata a 0x%X" % (w, self.pc))
        self.pc = nxt


def f2w(x): return struct.unpack(">I", struct.pack(">f", x))[0]


def attempt(label, fn):
    try:
        fn()
    except Fault as e:
        check(False, "%s: %s" % (label, e))


A = lambda off: BASE + off
W = [0.125, 0.25, 0.5, 0.0625]
SP = 0x80F80000
SENT = 0x80F00010                               # LR riconoscibile: "tornato al chiamante"
GARBAGE = 0xBAD00000
c = CPU(mn)
xan, ctl = 0x81000000, 0x81001000
buf, pkt, pos = 0x81002000, 0x81003000, 0x81004000
g_sendW, g_valid, g_recvW = L["g_sendW"], L["g_valid"], L["g_recvW"]
g_star, g_rx = L["g_star"], L["g_rx"]

# --- il gioco finto -------------------------------------------------------
STAGE = b"EggStarGalaxy\0"
STAGE_PTR = 0x81050000
c.write(STAGE_PTR, STAGE)
def h16(name):
    h = 0
    for ch in name:
        h = (h * 31 + ch) & 0xFFFFFFFF
    return h & 0xFFFF
MYHASH = h16(STAGE[:-1])
HOLDER, INFO, STAR = 0x81060000, 0x81061000, 0x81062000
PLAYER = 0x81063000
calls = []
game = {
    0x803F5AB8: lambda cpu: cpu.r.__setitem__(3, STAGE_PTR),                 # getCurrentStageName
    0x80299EFC: lambda cpu: cpu.r.__setitem__(3, HOLDER),                    # getPowerStarHolder
    0x802110CC: lambda cpu: (calls.append(("find", cpu.r[3], cpu.r[4])),     # findPowerStarRequestInfo
                             cpu.r.__setitem__(3, INFO if cpu.r[4] == 7 else 0)),
    0x80211030: lambda cpu: calls.append(("appear", cpu.r[3], cpu.r[4])),    # appearPowerStarWithoutDemo
    0x803F1F34: lambda cpu: cpu.r.__setitem__(3, PLAYER),                    # getPlayerPos
    # PowerStar::receiveOtherMsg originale: "presa" solo se AUTORUSH_BEGIN e ORIG_OK
    0x8020F628: lambda cpu: (calls.append(("orig", cpu.r[3], cpu.r[4], cpu.r[5], cpu.r[6])),
                             cpu.r.__setitem__(3, 1 if (cpu.r[4] in (0x92, 0x98) and ORIG_OK[0]) else 0)),
}
ORIG_OK = [1]
c.py.update(game)
for i, x in enumerate((100.0, 200.0, 300.0)): c.wr32(PLAYER + 4 * i, f2w(x))
c.wr32(INFO, STAR)
c.write(STAR + 0x8C, struct.pack(">i", 7))

# receiveMessage (per V2): la registra come prima
CALL = 0x81070000
c.py[0x80163760] = lambda cpu: (c.wr32(CALL, cpu.r[3]), c.wr32(CALL + 4, cpu.r[4]),
                                c.wr32(CALL + 8, cpu.r[5]), cpu.r.__setitem__(3, 1))


def call(fn_label, **regs):
    """Chiama una delle funzioni nuove come farebbe il gioco."""
    for k_, v in regs.items(): c.r[int(k_[1:])] = v
    c.r[1] = SP; c.lr = SENT
    c.run(A(L[fn_label]), SENT)


def reset_star():
    c.write(A(g_star), bytes(8))
    c.write(A(g_rx), bytes(32))
    c.write(A(g_star) + 6, bytes([2]))          # vtable gia' cercata: prove separate


# --------------------------------------------------------------- pesi
def t1():
    for i, x in enumerate(W): c.wr32(xan + 0x10 + 4 * i, f2w(x))
    c.wr32(xan + 0x20, ctl)
    c.r[5] = xan; c.r[1] = SP; c.lr = SENT
    c.run(A(0x2DB8), A(0x2DBC))
    check([c.rd32(A(g_sendW) + 4 * i) for i in range(4)] == [f2w(x) for x in W], "g_sendW = pesi di Mario")
    check(c.r[3] == ctl and c.r[5] == xan and c.lr == SENT, "istruzione spostata eseguita, r5 e LR intatti")


def t2():
    reset_star()
    c.r[3], c.r[4], c.r[5] = pos, buf, 76
    c.pc = A(0x2E78); c.step()
    check(c.lr == A(0x2E7C), "LR = 0x2E7C")
    c.run(c.pc, A(0xAAC))
    check([c.rd32(buf + 56 + 4 * i) for i in range(4)] == [f2w(x) for x in W], "buffer[56..71] = pesi")
    check(c.read(buf + 72, 4) == bytes([0, 2, 0, 0]), "nessuna stella: numero 0, spia vtable 2")
    c.write(A(L["g_diag"]), bytes([9, 3, 8, 42]))
    c.r[3], c.r[4], c.r[5] = pos, buf, 76
    c.pc = A(0x2E78); c.step(); c.run(c.pc, A(0xAAC))
    check(c.read(buf + 77, 1) == c.read(A(L["g_en_st"]) + 5, 1), "byte 77: esito dell'ultimo evento nemico")
    check((c.r[3], c.r[4], c.r[5]) == (pos, buf, 76), "argomenti di netWriteToBuffer intatti")
    # con una stella da annunciare
    c.write(A(g_star), bytes([5, 0, 0x12, 0x34])); c.wr16(A(g_star) + 4, 2)
    c.r[3], c.r[4], c.r[5] = pos, buf, 76
    c.pc = A(0x2E78); c.step(); c.run(c.pc, A(0xAAC))
    check(c.read(buf + 72, 4) == bytes([5, 2, 0x12, 0x34]), "stella: [numero 5, spia 2, impronta 0x1234]")
    check(c.rd16(A(g_star) + 4) == 1, "  pacchetti ancora da mandare: 2 -> 1")
    c.pc = A(0x2E78); c.step(); c.run(c.pc, A(0xAAC))
    c.pc = A(0x2E78); c.step(); c.run(c.pc, A(0xAAC))
    check(c.rd16(A(g_star) + 4) == 0 and c.read(buf + 72, 4) == bytes([0, 2, 0, 0]), "  finiti: si torna a zero")


def t3():
    reset_star()
    c.write(pkt, bytes([2]) + bytes(80))
    for i, x in enumerate(W): c.wr32(pkt + 56 + 4 * i, f2w(x))
    c.r[3], c.r[4], c.r[5], c.r[1], c.lr = pos, pkt, 72, SP, SENT
    c.run(A(0xB78), A(0xB7C))
    check(c.read(A(g_valid) + 2, 1)[0] == 1, "pacchetto da 72: pesi validi")
    check([c.rd32(A(g_recvW) + 32 + 4 * i) for i in range(4)] == [f2w(x) for x in W], "g_recvW[2] = pesi")
    check(c.read(A(g_rx) + 2, 1)[0] == 0, "pacchetto da 72: nessuna stella")
    check(c.r[1] == SP - 32 and (c.r[3], c.r[4], c.r[5]) == (pos, pkt, 72) and c.lr == SENT,
          "stwu eseguita, argomenti e LR intatti")
    c.write(pkt + 72, bytes([4, 0, 0xBE, 0xEF]))
    c.r[1], c.r[5] = SP, 76
    c.run(A(0xB78), A(0xB7C))
    check(c.read(A(L["g_diag"]) + 2, 1)[0] == 4, "diagnosi: ultima stella ricevuta = 4")
    check(c.read(A(g_rx) + 2, 1)[0] == 4 and c.rd16(A(g_rx) + 8 + 4) == 0xBEEF,
          "pacchetto da 76: stella 4, impronta 0xBEEF per il giocatore 2")
    c.write(A(g_rx) + 24 + 2, bytes([4]))       # come se fosse gia' servita
    c.r[1], c.r[5] = SP, 72
    c.run(A(0xB78), A(0xB7C))
    check(c.read(A(g_rx) + 2, 1)[0] == 0 and c.read(A(g_rx) + 24 + 2, 1)[0] == 0,
          "evento finito: numero e 'servito' tornano a zero")
    c.r[1], c.r[5] = SP, 56
    c.run(A(0xB78), A(0xB7C))
    check(c.read(A(g_valid) + 2, 1)[0] == 0, "pacchetto vecchio da 56: niente pesi")
    c.write(pkt, bytes([200])); c.r[1], c.r[5] = SP, 76
    before = c.read(A(g_valid), 8) + c.read(A(g_rx), 32)
    c.run(A(0xB78), A(0xB7C))
    check(c.read(A(g_valid), 8) + c.read(A(g_rx), 32) == before, "id 200 fuori range: nessuna scrittura")
    c.write(pkt, bytes([2])); c.r[1], c.r[5] = SP, 72
    c.run(A(0xB78), A(0xB7C))


R31 = (struct.unpack(">I", mn[0x15A8:0x15AC])[0] & 0xFFFF) << 16
PXANIMES = struct.unpack(">I", mn[0x57D0:0x57D4])[0]


def t4_active():
    c.write(pos, bytes([2]))
    i = 3
    c.r[22], c.r[31], c.r[19], c.r[23] = pos, R31, i * 140, i
    c.r[3] = ctl; c.f[0] = f2w(1.5)
    c.run(A(0x19D4), A(0x19D8))
    check(c.rd32(ctl + 12) == f2w(1.5), "stfs spostata eseguita")
    tgt = PXANIMES + i * 140 + 0x10
    check([c.rd32(tgt + 4 * j) for j in range(4)] == [f2w(x) for x in W], "pesi nel playerXanimes[3] vero")


def t4_inactive():
    c.r[22] = GARBAGE; c.r[23] = 0
    c.cr0 = (False, False, True)
    c.run(A(0x15BC), A(0x19DC))
    check(c.r[23] == 1, "giocatore inattivo: arriva all'incremento senza toccare r22")


# --------------------------------------------------------------- friendly fire
MARIO = 0x81008000


def ts1():
    reset_star()
    for timer, before, after in ((79, 0x01, 0x03), (46, 0x00, 0x02), (45, 0x00, 0x00), (0, 0x01, 0x01)):
        c.wr16(MARIO + 0x946, timer)
        c.write(SP + 152, bytes([before]))
        c.r[1], c.r[29], c.r[31], c.lr = SP, MARIO, 0x81234560, SENT
        c.run(A(0x2DE8), A(0x2DEC))
        check(c.read(SP + 152, 1)[0] == after and c.r[29] == 0x81234560 and c.r[1] == SP,
              "_946=%2d: flag 0x%02X -> 0x%02X, r29 e pila a posto dopo StarTick" % (timer, before, after))


def tv():
    check(struct.unpack(">I", mn[0x39A4:0x39A8])[0] == 0x38800053, "schianto: messaggio 0x53")
    JC = kn.reloc[0x39B2][1]
    def v2(flags, cooldown):
        c.write(pos + 60, bytes([flags])); c.write(A(JC) + 2, bytes([cooldown]))
        c.wr32(CALL + 4, 0)
        c.r[0], c.r[3], c.r[4], c.r[27] = flags, pos, pos, 2
        c.r[30], c.r[31], c.lr = 0x81005000, 0x81006000, SENT
        return c.run(A(0x3994), (A(0x399C), A(0x39B0), A(0x3A00), A(0x3A10)))
    check(v2(0x01, 0) == A(0x399C), "flag schianto: ramo dello schianto")
    check(v2(0x00, 0) == A(0x39B0), "nessun flag: come prima")
    check(v2(0x02, 0) == A(0x3A10) and c.rd32(CALL + 4) == 0x51, "piroetta: receiveMessage(0x51)")
    check(v2(0x02, 30) == A(0x3A00) and c.rd32(CALL + 4) == 0, "piroetta in pausa: spinta normale")


# --------------------------------------------------------------- stella condivisa
VT_OK, VT_DECOY = 0x80587430, 0x80590000


def t_scan():
    c.write(A(g_star), bytes(8))                # vtable non ancora cercata
    c.wr32(VT_OK + 0x74, 0x8020F628); c.wr32(VT_OK + 0x0C, 0x8020EBD4)
    c.wr32(VT_DECOY + 0x74, 0x8020F628); c.wr32(VT_DECOY + 0x0C, 0x12345678)
    call("StarTick")
    check(c.rd32(VT_OK + 0x74) == A(L["PS_recv"]), "vtable con le due firme: agganciata a PS_recv")
    check(c.rd32(VT_DECOY + 0x74) == 0x8020F628, "esca con una firma sola: lasciata stare")
    check(c.read(A(g_star) + 6, 1)[0] == 2, "stato: trovata e agganciata")
    c.wr32(VT_OK + 0x74, 0x8020F628)
    call("StarTick")
    check(c.rd32(VT_OK + 0x74) == 0x8020F628, "la ricerca si fa una volta sola")
    c.wr32(VT_OK + 0x74, 0); c.wr32(VT_DECOY + 0x74, 0)


def t_psrecv():
    reset_star()
    saved = (0x11111111, 0x22222222, 0x33333333)
    def ps(msg, ok=1, sid=7):
        ORIG_OK[0] = ok
        c.write(STAR + 0x8C, struct.pack(">i", sid))
        c.write(A(g_star), bytes(6))
        c.r[29], c.r[30], c.r[31] = saved
        del calls[:]
        call("PS_recv", r3=STAR, r4=msg, r5=0x81005000, r6=0x81006000)
        return c.r[3]
    r = ps(0x92)
    check(calls[0] == ("orig", STAR, 0x92, 0x81005000, 0x81006000), "chiama l'originale con gli stessi argomenti")
    check(r == 1, "  e restituisce il suo risultato")
    check(c.read(A(g_star), 1)[0] == 7 and c.rd16(A(g_star) + 2) == MYHASH and c.rd16(A(g_star) + 4) == 300,
          "stella presa: numero 7, impronta della galassia, 300 pacchetti")
    check((c.r[29], c.r[30], c.r[31], c.r[1]) == saved + (SP,), "r29-r31 e pila come prima")
    ps(0x98)
    check(c.rd16(A(g_star) + 4) == 0, "altro messaggio (IS_RUSH_TAKEOVER, anche se vero): niente")
    ps(0x92, ok=0)
    check(c.rd16(A(g_star) + 4) == 0, "AUTORUSH_BEGIN rifiutato dall'originale: niente")
    ps(0x92, sid=-1)
    check(c.rd16(A(g_star) + 4) == 0, "stella senza numero (-1): niente")
    c.write(STAR + 0x8C, struct.pack(">i", 7))
    ORIG_OK[0] = 1


def t_tick():
    reset_star()
    for i in range(3): c.wr32(STAR + 0x0C + 4 * i, 0); c.wr32(STAR + 0xAC + 4 * i, 0)
    def ev(gid, sid, h):
        c.write(A(g_rx) + gid, bytes([sid])); c.wr16(A(g_rx) + 8 + 2 * gid, h)
    ev(3, 7, MYHASH)
    del calls[:]
    call("StarTick")
    check(("appear", HOLDER, 7) in calls, "evento della mia galassia: appearPowerStarWithoutDemo(7)")
    pl = [c.rd32(PLAYER + 4 * i) for i in range(3)]
    check([c.rd32(STAR + 0x0C + 4 * i) for i in range(3)] == pl, "  stella spostata sul mio Mario")
    check([c.rd32(STAR + 0xAC + 4 * i) for i in range(3)] == pl, "  anche mInitPosition")
    check(c.read(A(g_rx) + 24 + 3, 1)[0] == 7, "  segnato come servito")
    check(c.read(A(L["g_diag"]), 2) == bytes([7, 5]), "  diagnosi: stella 7, esito 5 (comparsa)")
    del calls[:]
    call("StarTick")
    check(not any(x[0] == "appear" for x in calls), "stesso evento: servito una volta sola")

    reset_star(); ev(1, 7, MYHASH ^ 1); del calls[:]
    call("StarTick")
    check(not calls and c.read(A(g_rx) + 24 + 1, 1)[0] == 0, "altra galassia: niente")
    check(c.read(A(L["g_diag"]), 2) == bytes([7, 1]), "  diagnosi: esito 1 (altra galassia)")

    reset_star(); ev(2, 7, 0xFFFF); del calls[:]
    call("StarTick")
    check(("appear", HOLDER, 7) in calls, "impronta jolly 0xFFFF (tasto del pannello): vale anche qui")

    reset_star(); ev(1, 3, MYHASH); del calls[:]
    call("StarTick")
    check(("find", HOLDER, 3) in calls and not any(x[0] == "appear" for x in calls),
          "stella che nella mia scena non c'e': niente, e non ci riprova")
    check(c.read(A(g_rx) + 24 + 1, 1)[0] == 3, "  segnato come servito")
    check(c.read(A(L["g_diag"]), 2) == bytes([3, 3]), "  diagnosi: esito 3 (non nella scena)")
    giri = c.read(A(L["g_diag"]) + 3, 1)[0]
    call("StarTick")
    check(c.read(A(L["g_diag"]) + 3, 1)[0] == (giri + 1) & 0xFF, "  diagnosi: il contatore dei giri sale")

    reset_star(); ev(1, 7, MYHASH); c.wr16(A(g_star) + 4, 50); del calls[:]
    call("StarTick")
    check(not calls, "ho appena preso io una stella: ignoro quelle degli altri")


# --------------------------------------------------------------- nemici
VT_EN, VT_DECOY = 0x80560100, 0x80560400
EN_INIT, EN_KILL = 0x80117A80, 0x80118024            # Kuribo
ATK_ORIG = 0x80118100
MOV_ORIG = 0x80118200
ACT, NAME, ITER = 0x81030000, 0x81031000, 0x81032000
RETRACE = [1000]
c.py[0x804B38F0] = lambda cpu: cpu.r.__setitem__(3, RETRACE[0])            # VIGetRetraceCount
c.py[EN_INIT] = lambda cpu: calls.append(("init", cpu.r[3], cpu.r[4]))
c.py[EN_KILL] = lambda cpu: (calls.append(("kill", cpu.r[3])), c.write(cpu.r[3] + 0x68, bytes([1])))
g_en_st, g_en_tx, g_en_rx = L["g_en_st"], L["g_en_tx"], L["g_en_rx"]
g_en_tr, g_en_trN, g_en_vtN, g_en_last = L["g_en_tr"], L["g_en_trN"], L["g_en_vtN"], L["g_en_last"]
c.write(NAME, b"Kuribo\0")
POS = (f2w(12.5), f2w(-3.0), f2w(700.25))


def t_en_install():
    c.wr32(VT_EN + 0x08, 0x80123450); c.wr32(VT_EN + 0x0C, EN_INIT); c.wr32(VT_EN + 0x2C, EN_KILL)
    c.wr32(VT_EN + 0x5C, ATK_ORIG); c.wr32(VT_EN + 0x14, MOV_ORIG)
    c.wr32(VT_DECOY + 0x08, 0x80123450); c.wr32(VT_DECOY + 0x0C, EN_INIT); c.wr32(VT_DECOY + 0x2C, 1)
    c.wr32(A(g_en_vtN), 0)
    call("EnemyInstall")
    check(c.rd32(VT_EN + 0x0C) == A(L["EnInitHook"]) and c.rd32(VT_EN + 0x2C) == A(L["EnKillHook"]),
          "vtable di Kuribo trovata: init e kill agganciati")
    check(c.rd32(VT_DECOY + 0x0C) == EN_INIT, "esca (voce kill non e' codice): lasciata stare")
    check(c.rd32(A(g_en_vtN)) == 1 and c.read(A(g_en_st) + 6, 1)[0] == 1, "una vtable in tabella, diagnosi = 1")
    e = A(L["g_en_vt"])
    check((c.rd32(e), c.rd32(e + 4), c.rd32(e + 8), c.rd32(e + 12)) == (VT_EN, EN_INIT, EN_KILL, ATK_ORIG),
          "originali letti dalla vtable (anche receiveMsgPlayerAttack)")
    check(c.rd32(VT_EN + 0x5C) == A(L["EnAtkHook"]), "receiveMsgPlayerAttack agganciato")
    check(c.rd32(VT_EN + 0x14) == A(L["EnMoveHook"]) and c.rd32(e + 16) == MOV_ORIG, "movement agganciato")


def en_actor():
    c.wr32(ACT, VT_EN); c.wr32(ACT + 4, NAME)
    for i, v in enumerate(POS): c.wr32(ACT + 0x0C + 4 * i, v)
    c.write(ACT + 0x68, bytes([0]))
    c.wr32(ITER, 0x81033000); c.wr32(ITER + 4, 5)


def pos16():
    x = POS[0] ^ POS[1] ^ POS[2]
    return (x ^ (x >> 16)) & 0xFFFF


def t_en_init():
    en_actor()
    c.wr32(A(g_en_trN), 3)                      # voci della scena precedente
    c.wr32(A(g_en_st), 100); c.write(A(g_en_st) + 4, bytes([0]))
    RETRACE[0] = 1000                           # 900 fotogrammi dopo l'ultimo di gioco: caricamento
    del calls[:]
    call("EnInitHook", r3=ACT, r4=ITER)
    check(calls[0] == ("init", ACT, ITER), "init originale con gli stessi argomenti")
    check(c.rd32(A(g_en_trN)) == 1, "caricamento: tabella svuotata, poi una voce")
    e = A(g_en_tr)
    check(c.rd32(e) == ACT and c.rd16(e + 4) == h16(b"Kuribo") and c.rd16(e + 6) == 5
          and c.rd16(e + 8) == pos16() and c.rd16(e + 10) == MYHASH and c.read(e + 12, 1)[0] == 0,
          "voce: attore, nome, riga 5, posizione, galassia")
    for extra in (ACT + 0x100, ACT + 0x200):    # altri nemici della stessa classe
        c.wr32(extra, VT_EN); c.wr32(extra + 4, NAME)
    call("EnInitHook", r3=ACT + 0x100, r4=ITER)
    check(c.rd32(A(g_en_trN)) == 2, "secondo nemico dello stesso caricamento: niente svuotamento")
    c.wr32(A(g_en_st), 995); c.write(A(g_en_st) + 4, bytes([0]))
    call("EnInitHook", r3=ACT + 0x200, r4=ITER)
    check(c.rd32(A(g_en_trN)) == 3, "nemico nato durante il gioco: niente svuotamento")
    c.wr32(A(g_en_trN), 1)


def t_en_kill():
    en_actor()
    c.write(A(g_en_tx), bytes(112))
    del calls[:]
    call("EnKillHook", r3=ACT)
    check(("kill", ACT) in calls, "kill originale chiamato")
    check(c.read(A(g_en_tx) + 13, 1)[0] == 1, "morte in coda")
    e = A(g_en_tr)
    check(c.read(A(g_en_tx) + 16, 8) == c.read(e + 4, 8), "  annuncio = [nome, riga, posizione, galassia]")
    en_actor()
    c.write(e + 12, bytes([1]))                 # morte arrivata da un altro
    del calls[:]
    call("EnKillHook", r3=ACT)
    check(("kill", ACT) in calls and c.read(A(g_en_tx) + 13, 1)[0] == 1 and c.read(e + 12, 1)[0] == 0,
          "morte arrivata da un altro: kill si', annuncio no, flag tolto")


def t_en_send():
    ev = c.read(A(g_en_tx) + 16, 8)
    c.write(A(g_en_st) + 5, bytes([4]))
    got = []
    for i in range(22):
        c.r[3], c.r[4], c.r[5] = pos, buf, 92
        c.pc = A(0x2E78); c.step(); c.run(c.pc, A(0xAAC))
        got.append(c.read(buf + 80, 12))
    check(got[0][:8] == ev and got[0][8:10] == b"\x00\x01", "pacchetto: annuncio con sequenza 1")
    check(got[0][10:12] == bytes([0, 0]), "  tipo 0 (morte), sensore 0")
    check(all(g[:10] == got[0][:10] for g in got[:20]) and got[20][:10] == bytes(10),
          "  ripetuto per 20 pacchetti, poi niente")


def t_en_recv():
    c.write(pkt, bytes([2]) + bytes(95))
    c.write(pkt + 80, bytes(range(1, 11)) + b"\0\0")
    c.r[3], c.r[4], c.r[5], c.r[1], c.lr = pos, pkt, 92, SP, SENT
    c.run(A(0xB78), A(0xB7C))
    check(c.read(A(g_en_rx) + 24, 10) == bytes(range(1, 11)), "pacchetto da 92: annuncio salvato per il giocatore 2")
    c.write(A(g_en_rx), bytes(96))


def t_en_tick():
    en_actor()
    e = A(g_en_tr)
    ev = c.read(e + 4, 8)
    c.write(A(g_en_last), bytes(16)); c.write(A(g_star), bytes(8)); c.write(A(g_star) + 6, bytes([2]))
    c.write(A(g_en_rx) + 24, ev + b"\x00\x07")    # giocatore 2, sequenza 7
    del calls[:]
    call("EnemyTick")
    check(("kill", ACT) in calls, "annuncio della mia galassia: il nemico muore")
    check(c.read(A(g_en_st) + 5, 1)[0] == 4 and c.read(e + 12, 1)[0] == 0, "  esito 4, flag gia' tolto da EnKillHook")
    en_actor(); del calls[:]
    call("EnemyTick")
    check(not any(x[0] == "kill" for x in calls), "stessa sequenza: una volta sola")
    en_actor(); c.write(A(g_en_rx) + 24, ev[:6] + bytes([ev[6] ^ 1, ev[7]]) + b"\x00\x08"); del calls[:]
    call("EnemyTick")
    check(not calls and c.read(A(g_en_st) + 5, 1)[0] == 1, "altra galassia: esito 1, niente")
    c.write(ACT + 0x68, bytes([1])); c.write(A(g_en_rx) + 24, ev + b"\x00\x09"); del calls[:]
    call("EnemyTick")
    check(not calls and c.read(A(g_en_st) + 5, 1)[0] == 3, "gia' morto: esito 3, niente")


# --------------------------------------------------------------- posizioni
g_pk, g_pk_tx, g_pk_rx, g_en_tg = L["g_pk"], L["g_pk_tx"], L["g_pk_rx"], L["g_en_tg"]
ACT2 = ACT + 0x100
POS2 = (f2w(-50.0), f2w(10.0), f2w(3.5))
NOW = 5000


NRV_A, NRV_B, NRV_VT = 0x805E0000, 0x805E0010, 0x805E0100
NRV_BAD = 0x81000800                        # fuori dalla zona delle nerve
SPINE1, SPINE2 = 0x81034000, 0x81034100
SET_NERVE = 0x80165824
c.py[SET_NERVE] = lambda cpu: (calls.append(("nerve", cpu.r[3], cpu.r[4])),
                               c.wr32(c.rd32(cpu.r[3] + 0x50) + 8, cpu.r[4]))


def key_of(index, p):
    x = p[0] ^ p[1] ^ p[2]
    return ((index ^ h16(b"Kuribo") ^ MYHASH) << 16) | ((x ^ (x >> 16)) & 0xFFFF)


def pk_scene():
    en_actor()
    c.wr32(ACT2, VT_EN); c.wr32(ACT2 + 4, NAME)
    for i, v in enumerate(POS2): c.wr32(ACT2 + 0x0C + 4 * i, v)
    c.write(ACT2 + 0x68, bytes([0]))
    c.wr32(NRV_A, NRV_VT); c.wr32(NRV_B, NRV_VT); c.wr32(NRV_VT + 8, 0x80123456)
    for act, sp in ((ACT, SPINE1), (ACT2, SPINE2)):
        c.wr32(act + 0x50, sp); c.write(sp, bytes(20)); c.wr32(sp + 4, NRV_A)
    c.wr32(A(g_en_trN), 2)
    for n, (act, idx, p) in enumerate(((ACT, 5, POS), (ACT2, 9, POS2))):
        e = A(g_en_tr) + 16 * n
        k = key_of(idx, p)
        c.wr32(e, act); c.wr16(e + 4, h16(b"Kuribo")); c.wr16(e + 6, idx)
        c.wr16(e + 8, k & 0xFFFF); c.wr16(e + 10, MYHASH); c.write(e + 12, bytes(4))
    c.write(A(g_pk), bytes(16)); c.write(A(L["g_pk_seen"]), bytes(32)); c.write(A(L["g_pk_new"]), bytes(8))
    c.write(A(L["g_en_ls"]), bytes(24)); c.write(A(g_en_tg), bytes(32)); c.write(A(L["g_en_ln"]), bytes(8))
    c.wr32(A(g_en_st), NOW)


def tx():
    w = [c.rd32(A(g_pk_tx) + 4 * i) for i in range(8)]
    return w[0:5], w[5:7], w[7]


def t_pk_master():
    pk_scene()
    c.write(pos, bytes([0]))
    c.r[3], c.r[4], c.r[5] = pos, buf, 124
    c.pc = A(0x2E78); c.step(); c.run(c.pc, A(0xAAC))
    check(c.read(A(g_pk), 1)[0] == 0, "T2: il mio id (0) dal primo byte della posizione")
    call("PosTick")
    p1, p2, z = tx()
    check(c.read(A(g_pk) + 1, 1)[0] == 0 and c.rd16(A(g_pk) + 2) == MYHASH, "da solo: comando io, galassia annotata")
    check(p1 == [key_of(5, POS)] + list(POS) + [NRV_A], "posto 1: Kuribo riga 5, chiave, posizione e nerve")
    check(p2 == [key_of(5, POS), NRV_A] and z == 0, "posto 2: il suo stato (mai mandato = cambiato)")
    call("PosTick")
    p1, p2, _ = tx()
    check(p1[0] == key_of(9, POS2) and p2 == [key_of(9, POS2), NRV_A], "poi l'altro, ancora mai mandato")
    call("PosTick")
    p1, p2, _ = tx()
    check(p1[0] in (key_of(5, POS), key_of(9, POS2)) and p2[0] in (key_of(5, POS), key_of(9, POS2)),
          "tutti fermi e stessi stati: si mandano a giro")
    c.wr32(ACT2 + 0x10, f2w(12.0)); c.wr32(SPINE2 + 4, NRV_B)
    call("PosTick")
    p1, p2, _ = tx()
    check(p1 == [key_of(9, POS2), POS2[0], f2w(12.0), POS2[2], NRV_B], "quello che si muove passa davanti, con la nerve nuova")
    check(p2 == [key_of(9, POS2), NRV_B], "  e il cambio di stato passa davanti")
    c.write(ACT2 + 0x68, bytes([1])); c.wr32(ACT2 + 0x10, f2w(13.0))
    for _ in range(3):
        call("PosTick")
        p1, p2, _ = tx()
        check(p1[0] != key_of(9, POS2) and p2[0] != key_of(9, POS2), "morto: non si manda piu'")
    c.r[3], c.r[4], c.r[5] = pos, buf, 124
    c.pc = A(0x2E78); c.step(); c.run(c.pc, A(0xAAC))
    p1, p2, z = tx()
    check([c.rd32(buf + 92 + 4 * i) for i in range(8)] == p1 + p2 + [z], "T2: i posti nei byte 92..123")
    check(c.read(buf + 76, 1)[0] == 0 and c.rd16(buf + 78) == MYHASH, "  byte 76 chi comanda, 78..79 galassia")
    check((c.r[3], c.r[4], c.r[5]) == (pos, buf, 124), "  argomenti di netWriteToBuffer intatti")


def t_pk_recv():
    pk_scene()
    c.write(pkt, bytes([1]) + bytes(127))
    c.wr16(pkt + 78, MYHASH)
    body = [key_of(5, POS), f2w(1.0), f2w(2.0), f2w(3.0), NRV_B, key_of(9, POS2), NRV_B, 0]
    for i, v in enumerate(body): c.wr32(pkt + 92 + 4 * i, v)
    c.r[3], c.r[4], c.r[5], c.r[1], c.lr = pos, pkt, 124, SP, SENT
    c.run(A(0xB78), A(0xB7C))
    check(c.rd32(A(L["g_pk_seen"]) + 4) == NOW and c.rd16(A(L["g_pk_stage"]) + 2) == MYHASH,
          "T3: giocatore 1 sentito adesso, nella mia galassia")
    check([c.rd32(A(g_pk_rx) + 32 + 4 * i) for i in range(8)] == body and c.read(A(L["g_pk_new"]) + 1, 1)[0] == 1,
          "  i suoi posti salvati, da leggere")
    c.write(A(g_pk), bytes([2]))                # io sono il 2: comanda l'1
    del calls[:]
    call("PosTick")
    check(c.read(A(g_pk) + 1, 1)[0] == 1, "comanda il giocatore 1 (id piu' basso, stessa galassia)")
    check([c.rd32(ACT + 0x0C + 4 * i) for i in range(3)] == [f2w(1.0), f2w(2.0), f2w(3.0)],
          "Kuribo messo dove lo vede lui")
    check([c.rd32(ACT2 + 0x0C + 4 * i) for i in range(3)] == list(POS2), "  l'altro nemico: posizione non toccata")
    check(calls == [("nerve", ACT, NRV_B), ("nerve", ACT2, NRV_B)], "setNerve(NRV_B) su tutti e due")
    p1, p2, _ = tx()
    check(p1[0] == 0xFFFFFFFF and p2[0] == 0xFFFFFFFF, "  non comando: posti vuoti")
    check(c.read(A(L["g_pk_new"]) + 1, 1)[0] == 0 and c.rd16(A(g_pk) + 8) == 1 and c.rd16(A(g_pk) + 14) == 2,
          "  letti; diagnosi: 1 posizione, 2 stati")
    # stessa nerve di nuovo (gia' in arrivo): niente setNerve
    c.write(A(L["g_pk_new"]) + 1, bytes([1])); del calls[:]
    call("PosTick")
    check(not any(x[0] == "nerve" for x in calls), "stessa nerve gia' in arrivo: non si rimette")
    # nerve fuori zona: ignorata
    c.wr32(A(g_pk_rx) + 32 + 16, NRV_BAD); c.wr32(A(g_pk_rx) + 32 + 24, 0)
    c.wr32(SPINE1 + 8, 0); c.wr32(SPINE2 + 8, 0)
    c.write(A(L["g_pk_new"]) + 1, bytes([1])); del calls[:]
    call("PosTick")
    check(not any(x[0] == "nerve" for x in calls), "nerve fuori dalla zona del gioco (o 0): ignorata")
    c.wr32(ACT + 0x0C, f2w(99.0))               # la sua IA lo sposta
    c.wr32(A(g_en_st), NOW + 100)
    c.wr32(A(L["g_pk_seen"]) + 4, NOW + 100)
    call("PosTick")
    check(c.rd32(ACT + 0x0C) == f2w(1.0), "fotogramma dopo, senza notizie: tenuto sull'ultima posizione")
    c.wr32(ACT + 0x0C, f2w(99.0))
    c.wr32(A(g_en_st), NOW + 181); c.wr32(A(L["g_pk_seen"]) + 4, NOW + 181)
    call("PosTick")
    check(c.rd32(ACT + 0x0C) == f2w(99.0), "notizia di 181 fotogrammi fa: decide il gioco da solo")
    c.wr32(A(g_en_st), NOW + 300)
    call("PosTick")
    check(c.read(A(g_pk) + 1, 1)[0] == 2, "l'1 non si sente da 119 fotogrammi: comando io")
    c.wr32(A(L["g_pk_seen"]) + 4, NOW + 300); c.wr16(A(L["g_pk_stage"]) + 2, MYHASH ^ 1)
    call("PosTick")
    check(c.read(A(g_pk) + 1, 1)[0] == 2, "l'1 in un'altra galassia: comando io")
    c.write(A(g_pk), bytes(16))


# --------------------------------------------------------------- colpi
KEEPER, INFOS = 0x81035000, 0x81035100
INFO0, INFO1, SENS0, SENS1 = 0x81035200, 0x81035240, 0x81035300, 0x81035340
MARIO_ACT, MY_SENS, OTHER_SENS = 0x81036000, 0x81036100, 0x81036200
ATK_RET = [1]
c.py[ATK_ORIG] = lambda cpu: (calls.append(("atk", cpu.r[3], cpu.r[4], cpu.r[5], cpu.r[6])),
                              cpu.r.__setitem__(3, ATK_RET[0]))
c.py[0x803C2648] = lambda cpu: cpu.r.__setitem__(                       # MR::getSensorWithIndex
    3, c.rd32(c.rd32(c.rd32(c.rd32(cpu.r[3] + 0x54) + 8) + 4 * cpu.r[4]) + 8))
c.py[0x80304204] = lambda cpu: cpu.r.__setitem__(3, MARIO_ACT)          # MarioAccess::getPlayerActor
c.py[0x803DF840] = lambda cpu: cpu.r.__setitem__(3, MY_SENS if cpu.r[3] == MARIO_ACT else 0)


def keeper():
    c.wr32(ACT + 0x54, KEEPER); c.wr32(KEEPER + 4, 2); c.wr32(KEEPER + 8, INFOS)
    c.wr32(INFOS, INFO0); c.wr32(INFOS + 4, INFO1)
    c.wr32(INFO0 + 8, SENS0); c.wr32(INFO1 + 8, SENS1)


def t_hit():
    pk_scene(); keeper()
    c.wr32(A(g_en_trN), 1)
    c.write(A(g_en_tx), bytes(112))
    ATK_RET[0] = 1; del calls[:]
    call("EnAtkHook", r3=ACT, r4=0x10, r5=OTHER_SENS, r6=SENS1)
    check(calls == [("atk", ACT, 0x10, OTHER_SENS, SENS1)] and c.r[3] == 1,
          "colpo: receiveMsgPlayerAttack originale con gli stessi argomenti, risultato restituito")
    e = A(g_en_tr)
    check(c.read(e + 13, 1)[0] == 1 and c.rd16(e + 14) == (NOW + 120) & 0xFFFF, "  a segno: 2 secondi di pausa")
    q = A(g_en_tx) + 16
    check(c.read(A(g_en_tx) + 13, 1)[0] == 1 and c.read(q, 8) == c.read(e + 4, 8) and c.read(q + 8, 2) == bytes([0x10, 1]),
          "  in coda: [nemico, messaggio 0x10, sensore 1]")
    c.r[3], c.r[4], c.r[5] = pos, buf, 124
    c.pc = A(0x2E78); c.step(); c.run(c.pc, A(0xAAC))
    check(c.read(buf + 80, 8) == c.read(e + 4, 8) and c.read(buf + 90, 2) == bytes([0x10, 1]),
          "T2: nel pacchetto, byte 90..91 = messaggio e sensore")
    c.write(A(g_en_tx), bytes(112)); c.write(e + 13, bytes(3))
    ATK_RET[0] = 0; del calls[:]
    call("EnAtkHook", r3=ACT, r4=0x10, r5=OTHER_SENS, r6=SENS1)
    check(c.r[3] == 0 and c.read(A(g_en_tx) + 13, 1)[0] == 0 and c.read(e + 13, 1)[0] == 0,
          "colpo non a segno: niente coda, niente pausa")
    ATK_RET[0] = 1
    # pausa: chi comanda non tocca quel nemico
    c.write(e + 13, bytes([1])); c.wr16(e + 14, (NOW + 120) & 0xFFFF)
    c.write(A(g_pk), bytes([2])); c.wr32(A(L["g_pk_seen"]) + 4, NOW); c.wr16(A(L["g_pk_stage"]) + 2, MYHASH)
    for i, v in enumerate([key_of(5, POS), f2w(1.0), f2w(2.0), f2w(3.0), NRV_B, key_of(5, POS), NRV_B, 0]):
        c.wr32(A(g_pk_rx) + 32 + 4 * i, v)
    c.write(A(L["g_pk_new"]) + 1, bytes([1])); del calls[:]
    call("PosTick")
    check(c.rd32(ACT + 0x0C) == POS[0] and not calls, "in pausa: niente posizione ne' stato da chi comanda")
    c.wr32(A(g_en_st), NOW + 121); c.wr32(A(L["g_pk_seen"]) + 4, NOW + 121)
    c.write(A(L["g_pk_new"]) + 1, bytes([1])); del calls[:]
    call("PosTick")
    check(c.rd32(ACT + 0x0C) == f2w(1.0) and ("nerve", ACT, NRV_B) in calls and c.read(e + 13, 1)[0] == 0,
          "pausa finita: si torna a seguire chi comanda")
    c.wr32(A(g_en_st), NOW)


def t_replay():
    pk_scene(); keeper()
    c.wr32(A(g_en_trN), 1)
    e = A(g_en_tr)
    ev = c.read(e + 4, 8)
    c.write(A(g_en_last), bytes(16))
    c.write(A(g_pk), bytes([0, 0]))             # comando io
    c.write(A(g_en_rx) + 24, ev + b"\x00\x21" + bytes([0x10, 1]))
    del calls[:]
    call("EnemyTick")
    check(calls == [("atk", ACT, 0x10, MY_SENS, SENS1)], "chi comanda ripete il colpo: mio Mario -> sensore 1 del nemico")
    check(c.read(A(g_en_st) + 5, 1)[0] == 5 and c.read(ACT + 0x68, 1)[0] == 0, "  esito 5, niente kill")
    c.write(A(g_pk), bytes([2, 1]))             # non comando
    c.write(A(g_en_rx) + 24, ev + b"\x00\x22" + bytes([0x10, 1])); del calls[:]
    call("EnemyTick")
    check(not calls and c.read(A(g_en_st) + 5, 1)[0] == 6, "non comando: il colpo non si ripete (esito 6)")
    c.write(A(g_pk), bytes([0, 0]))
    c.write(A(g_en_rx) + 24, ev + b"\x00\x23" + bytes([0x10, 7])); del calls[:]
    call("EnemyTick")
    check(not calls and c.read(A(g_en_st) + 5, 1)[0] == 6, "sensore 7 che non esiste: ignorato")
    c.write(A(g_en_rx), bytes(96)); c.write(A(g_pk), bytes(16))


# --------------------------------------------------------------- teletrasporto
TP_CALLS = []
c.py[0x803F1F80] = lambda cpu: TP_CALLS.append([c.rd32(cpu.r[3] + 4 * i) for i in range(3)])


def t_tp():
    pk_scene()
    g_tp = A(L["g_tp"])
    c.write(g_tp, bytes(20))
    TPOS = [f2w(10.0), f2w(20.0), f2w(30.0)]
    def packet(flags, stage):
        c.write(pkt, bytes([3, flags]) + bytes(126))
        for i, v in enumerate(TPOS): c.wr32(pkt + 8 + 4 * i, v)
        c.wr16(pkt + 78, stage)
        c.r[3], c.r[4], c.r[5], c.r[1], c.lr = pos, pkt, 124, SP, SENT
        c.run(A(0xB78), A(0xB7C))
    packet(0x00, MYHASH)
    check(c.read(g_tp, 1)[0] == 0, "senza il bit 0x04: niente richiesta")
    packet(0x04, MYHASH)
    check(c.read(g_tp, 2) == bytes([1, 3]) and c.rd16(g_tp + 2) == MYHASH, "bit 0x04 dal giocatore 3: richiesta annotata")
    del TP_CALLS[:]
    call("PosTick")
    check(TP_CALLS == [TPOS], "PosTick: MR::setPlayerPos sulla sua posizione")
    check(c.rd16(g_tp + 16) == 180 and c.read(g_tp, 1)[0] == 0, "  poi 3 secondi di pausa")
    packet(0x04, MYHASH); del TP_CALLS[:]
    call("PosTick")
    check(not TP_CALLS and c.rd16(g_tp + 16) == 179, "stesso comando ripetuto nei pacchetti dopo: una volta sola")
    c.wr16(g_tp + 16, 0)
    packet(0x04, MYHASH ^ 1); del TP_CALLS[:]
    call("PosTick")
    check(not TP_CALLS, "lui in un'altra galassia: niente")
    c.write(g_tp, bytes(20)); c.write(A(g_pk), bytes(16))


# --------------------------------------------------------------- cutscene
DEMO = [0]
MOV_CALLS = []
c.py[0x803C9E84] = lambda cpu: cpu.r.__setitem__(3, DEMO[0])            # MR::isDemoActive
c.py[MOV_ORIG] = lambda cpu: MOV_CALLS.append(cpu.r[3])


def t_demo():
    pk_scene()
    gd = A(L["g_demo"])
    c.write(gd, bytes(4)); c.write(A(L["g_pk_demo"]), bytes(8))
    call("PosTick")                             # prima volta: annota la galassia
    check(c.rd16(gd + 2) == MYHASH and c.read(gd + 1, 1)[0] == 0, "galassia annotata, 0 cutscene")
    del MOV_CALLS[:]
    DEMO[0] = 0
    call("EnMoveHook", r3=ACT)
    check(MOV_CALLS == [ACT] and c.read(gd, 1)[0] == 0, "movement originale; niente cutscene: niente segno")
    DEMO[0] = 1
    call("EnMoveHook", r3=ACT)
    check(c.read(gd, 1)[0] == 1, "movement durante una cutscene: segnata")
    call("PosTick")
    check(c.read(gd + 1, 1)[0] == 0 and c.read(gd, 1)[0] == 1, "cutscene ancora in corso: si aspetta a contare")
    DEMO[0] = 0
    call("PosTick")
    check(c.read(gd + 1, 1)[0] == 1 and c.read(gd, 1)[0] == 0, "cutscene finita: 1")
    c.r[3], c.r[4], c.r[5] = pos, buf, 124
    c.pc = A(0x2E78); c.step(); c.run(c.pc, A(0xAAC))
    check(c.read(buf + 76, 1)[0] == 1, "T2: byte 76 = le mie cutscene")
    # un altro (slot 1) con 2 cutscene nella mia galassia: comanda lui
    c.write(A(g_pk), bytes([0])); c.write(A(g_pk) + 2, struct.pack(">H", MYHASH))
    c.write(pkt, bytes([1]) + bytes(127)); c.wr16(pkt + 78, MYHASH); c.write(pkt + 76, bytes([2]))
    for i in range(8): c.wr32(pkt + 92 + 4 * i, 0xFFFFFFFF)
    c.r[3], c.r[4], c.r[5], c.r[1], c.lr = pos, pkt, 124, SP, SENT
    c.run(A(0xB78), A(0xB7C))
    check(c.read(A(L["g_pk_demo"]) + 1, 1)[0] == 2, "T3: le sue cutscene (2) annotate")
    call("PosTick")
    check(c.read(A(g_pk) + 1, 1)[0] == 1, "lui ne ha viste 2, io 1: comanda lui anche se ha lo slot piu' alto")
    c.write(A(g_pk), bytes([2]))                # io slot 2, lui 1, pari
    c.write(gd + 1, bytes([2]))
    call("PosTick")
    check(c.read(A(g_pk) + 1, 1)[0] == 1, "pari: lo slot piu' basso")
    c.write(gd + 1, bytes([3]))
    call("PosTick")
    check(c.read(A(g_pk) + 1, 1)[0] == 2, "io 3, lui 2: comando io")
    c.write(gd + 2, struct.pack(">H", MYHASH ^ 1))
    call("PosTick")
    check(c.read(gd + 1, 1)[0] == 0 and c.rd16(gd + 2) == MYHASH, "galassia nuova: si ricomincia da 0")
    c.write(gd, bytes(4)); c.write(A(L["g_pk_demo"]), bytes(8)); c.write(A(g_pk), bytes(16))


for title, fn in (("2. T1: pesi del proprio Mario", t1),
                  ("3. T2: pesi e stella nel pacchetto", t2),
                  ("4. T3: pesi e stella ricevuti", t3),
                  ("5. T4: pesi nel pupazzo", t4_active),
                  ("6. giocatore inattivo con r22 spazzatura", t4_inactive),
                  ("7. S1: piroetta, dopo StarTick", ts1),
                  ("8. V1/V2: friendly fire", tv),
                  ("9. ricerca della vtable di PowerStar", t_scan),
                  ("10. PS_recv: chi prende la stella", t_psrecv),
                  ("11. StarTick: gli altri", t_tick),
                  ("12. nemici: installazione all'avvio", t_en_install),
                  ("13. nemici: init annota", t_en_init),
                  ("14. nemici: kill annuncia", t_en_kill),
                  ("15. nemici: l'annuncio nel pacchetto", t_en_send),
                  ("16. nemici: l'annuncio ricevuto", t_en_recv),
                  ("17. nemici: EnemyTick uccide", t_en_tick),
                  ("18. posizioni e stati: chi comanda manda", t_pk_master),
                  ("19. posizioni e stati: gli altri seguono", t_pk_recv),
                  ("20. colpi: pausa e coda", t_hit),
                  ("21. colpi: chi comanda li ripete", t_replay),
                  ("22. teletrasporto", t_tp),
                  ("23. cutscene: comanda chi e' piu' avanti", t_demo)):
    print("\n=== %s ===" % title)
    attempt(title, fn)

print("\n%s" % ("TUTTO A POSTO" if fails == 0 else "%d CONTROLLI FALLITI" % fails))
sys.exit(1 if fails else 0)
