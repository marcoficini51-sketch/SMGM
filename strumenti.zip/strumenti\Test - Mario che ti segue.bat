@echo off
cd /d "%~dp0"
title Test - Mario che ti segue
echo.
echo  ============================================
echo   TEST: un Mario che ripete i tuoi movimenti
echo  ============================================
echo.
echo  Serve che il server sia acceso e che tu sia
echo  in gioco, dentro una galassia.
echo.
echo  Sotto i 50 ms il Mario finisce dentro di te
echo  e non lo vedi: prova 500, oppure tieni 10 e
echo  metti un offset di 200.
echo.
set /p RIT=  Ritardo in millisecondi [invio = 10]:
if "%RIT%"=="" set RIT=10
set /p OFF=  Offset laterale [invio = 0]:
if "%OFF%"=="" set OFF=0
echo.
Follow.exe 5029 %RIT% %OFF% 0 0
echo.
pause
